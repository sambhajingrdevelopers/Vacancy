"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useRef, useState } from "react";

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

type ProjectPlan = {
  businessType?: string;
  stack?: string;
  pages?: string[];
  features?: string[];
  adminPanel?: string[];
  nextSteps?: string[];
};

type GeneratedProject = {
  success: boolean;
  source?: string;
  projectId: string;
  projectName: string;
  stack?: string;
  summary?: string;
  files?: string[];
  previewUrl?: string;
  downloadUrl?: string;
  frontendPreviewUrl?: string;
  frontendDownloadUrl?: string;
  projectPlan?: ProjectPlan;
  model?: string;
  tokenCost?: number;
  zipLocked?: boolean;
};

type UserProfile = {
  userId?: string;
  name?: string;
  email?: string;
};

type WalletSummary = {
  userId?: string;
  plan?: string;
  model?: string;
  modelTier?: string;
  messagesRemaining?: number;
  projectPassesRemaining?: number;
  zipUnlocked?: boolean;
  creditsTotal?: number;
  creditsUsed?: number;
  creditsRemaining?: number;
  tokensTotal?: number;
  tokensUsed?: number;
  tokensRemaining?: number;
  freeProjectsUsed?: number;
  projectsGeneratedCount?: number;
};

type AuthMeResponse = {
  success?: boolean;
  user?: UserProfile;
  wallet?: WalletSummary;
  error?: string;
  detail?: string;
};

type ChatSession = {
  id: string;
  title: string;
  messages: ChatMessage[];
  lastRequirement: string;
  selectedStack: string;
  generatedProject: GeneratedProject | null;
  updatedAt: number;
};

type ApiJson = Record<string, unknown>;

const STORAGE_KEY_PREFIX = "sambhajingr_project_pass_autodev_chats_v1";

function getStorageKey(userId?: string) {
  return `${STORAGE_KEY_PREFIX}_${userId || "guest"}`;
}

const starterPrompts = [
  "Create a small school admission website with enquiry form, admin panel, and WhatsApp button.",
  "Create a grocery store website with products, enquiry form, offers, and admin panel.",
  "Create a restaurant website with menu, table booking, gallery, and WhatsApp enquiry.",
  "Create a hospital website with appointment booking, doctor list, contact page, and admin panel.",
];

const requirementChips = [
  "Business website",
  "E-commerce",
  "Booking system",
  "Admin panel",
  "Payment gateway",
  "Mobile responsive",
  "SEO ready",
  "WhatsApp enquiry",
];

const stackOptions = [
  { label: "Auto", value: "" },
  { label: "Next.js", value: "nextjs" },
  { label: "Python Flask", value: "python-flask" },
  { label: "Java Spring", value: "java-spring-boot" },
  { label: "PHP", value: "php" },
  { label: "Static HTML", value: "static-html" },
];

function createId() {
  return `${Date.now()}_${Math.random().toString(16).slice(2)}`;
}

function getDefaultMessages(): ChatMessage[] {
  return [
    {
      role: "assistant",
      content:
        "Welcome! Describe the website or app you want. Every Project Pass includes 5 AI messages, 1 project generation, preview, and ZIP download.",
    },
  ];
}

function createNewSession(): ChatSession {
  return {
    id: createId(),
    title: "New Project Chat",
    messages: getDefaultMessages(),
    lastRequirement: "",
    selectedStack: "",
    generatedProject: null,
    updatedAt: Date.now(),
  };
}

function createTitle(requirement: string) {
  const clean = requirement.replace(/\s+/g, " ").trim();
  return clean ? clean.slice(0, 52) : "New Project Chat";
}

function formatError(error: unknown) {
  if (error instanceof Error) return error.message;
  return "Unknown error";
}

function cleanPassError(message: string) {
  const lower = message.toLowerCase();

  if (
    lower.includes("insufficient wallet tokens") ||
    lower.includes("not enough tokens") ||
    lower.includes("not enough credits") ||
    lower.includes("no project pass")
  ) {
    return "No Project Pass is available. Please buy a Project Pass to generate another project.";
  }

  return message;
}

function buildFrontendPreviewUrl(project?: GeneratedProject | null) {
  if (!project?.projectId) return "";

  return `/api/generated-project-preview?projectId=${encodeURIComponent(
    project.projectId
  )}`;
}

function buildFrontendDownloadUrl(project?: GeneratedProject | null) {
  if (!project?.projectId) return "";

  return `/api/generated-project-download?projectId=${encodeURIComponent(
    project.projectId
  )}`;
}

function normalizeProject(project: GeneratedProject): GeneratedProject {
  return {
    ...project,
    zipLocked: false,
    frontendPreviewUrl: buildFrontendPreviewUrl(project),
    frontendDownloadUrl: buildFrontendDownloadUrl(project),
  };
}

function withCacheBust(url: string, key: number) {
  if (!url) return "";
  return `${url}${url.includes("?") ? "&" : "?"}v=${key}`;
}

function withUserId(url: string, userId: string) {
  if (!url) return "";
  return `${url}${url.includes("?") ? "&" : "?"}userId=${encodeURIComponent(
    userId
  )}`;
}

function loadSessions(userId?: string): ChatSession[] {
  if (typeof window === "undefined") return [];

  try {
    const raw = window.localStorage.getItem(getStorageKey(userId));
    if (!raw) return [];

    const parsed = JSON.parse(raw) as ChatSession[];
    if (!Array.isArray(parsed)) return [];

    return parsed.map((session) => ({
      ...session,
      generatedProject: session.generatedProject
        ? normalizeProject(session.generatedProject)
        : null,
    }));
  } catch {
    return [];
  }
}

function saveSessions(userId: string | undefined, sessions: ChatSession[]) {
  if (typeof window === "undefined") return;
  if (!userId) return;

  window.localStorage.setItem(
    getStorageKey(userId),
    JSON.stringify(sessions.slice(0, 30))
  );
}

async function readJsonSafely(response: Response): Promise<ApiJson> {
  const text = await response.text();

  try {
    return JSON.parse(text) as ApiJson;
  } catch {
    throw new Error(
      `Server returned non-JSON response. Status: ${response.status}. Text: ${text.slice(
        0,
        300
      )}`
    );
  }
}

async function readAuthMe(response: Response): Promise<AuthMeResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as AuthMeResponse;
  } catch {
    return {
      success: false,
      error: `Auth returned non-JSON: ${text.slice(0, 300)}`,
    };
  }
}

function getApiErrorMessage(data: ApiJson, fallback: string) {
  if (typeof data.error === "string") return cleanPassError(data.error);
  if (typeof data.message === "string") return cleanPassError(data.message);

  if (
    typeof data.detail === "object" &&
    data.detail !== null &&
    "message" in data.detail
  ) {
    const detail = data.detail as { message?: unknown };
    if (typeof detail.message === "string") return cleanPassError(detail.message);
  }

  if (typeof data.detail === "string") return cleanPassError(data.detail);

  return cleanPassError(fallback);
}

function getPlanName(plan?: string) {
  const value = String(plan || "free").toLowerCase();

  if (value === "starter") return "Starter Project Pass";
  if (value === "premium") return "Premium Project Pass";
  if (value === "advanced") return "Advanced Project Pass";
  if (value === "enterprise") return "Enterprise Project Pass";
  if (value === "admin") return "Admin Access";

  return "Free Demo";
}

export default function WebsiteRequirementChat() {
  const [sessions, setSessions] = useState<ChatSession[]>([]);
  const [activeSessionId, setActiveSessionId] = useState("");
  const [input, setInput] = useState("");
  const [selectedChips, setSelectedChips] = useState<string[]>([]);
  const [selectedStack, setSelectedStack] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [isGeneratingProject, setIsGeneratingProject] = useState(false);
  const [isPublishingTemplate, setIsPublishingTemplate] = useState(false);
  const [projectError, setProjectError] = useState("");
  const [previewKey, setPreviewKey] = useState(1);

  const [authLoading, setAuthLoading] = useState(true);
  const [authError, setAuthError] = useState("");
  const [authUser, setAuthUser] = useState<UserProfile | null>(null);
  const [walletSummary, setWalletSummary] = useState<WalletSummary | null>(null);

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);

  const activeSession = useMemo(() => {
    return sessions.find((session) => session.id === activeSessionId) || null;
  }, [sessions, activeSessionId]);

  const messages = activeSession?.messages || getDefaultMessages();
  const lastRequirement = activeSession?.lastRequirement || "";
  const generatedProject = activeSession?.generatedProject
    ? normalizeProject(activeSession.generatedProject)
    : null;

  const previewUrl = buildFrontendPreviewUrl(generatedProject);
  const downloadUrl = buildFrontendDownloadUrl(generatedProject);
  const userId = authUser?.userId || "";

  const currentRequirement = useMemo(() => {
    const chips = selectedChips.length
      ? `Required features: ${selectedChips.join(", ")}`
      : "";

    const stackText = selectedStack ? `Technology stack: ${selectedStack}` : "";

    return [input.trim(), chips, stackText].filter(Boolean).join("\n");
  }, [input, selectedChips, selectedStack]);

  const activeRequirement = currentRequirement || lastRequirement;

  async function loadAuth() {
    try {
      setAuthLoading(true);
      setAuthError("");

      const response = await fetch("/api/auth/me", {
        cache: "no-store",
      });

      const data = await readAuthMe(response);

      if (!response.ok || !data.success || !data.user?.userId) {
        throw new Error(data.error || data.detail || "Login required.");
      }

      setAuthUser(data.user);
      setWalletSummary(data.wallet || null);

      if (typeof window !== "undefined") {
        window.localStorage.setItem("sambhajingr_wallet_user_id", data.user.userId);
      }
    } catch (error) {
      setAuthUser(null);
      setWalletSummary(null);
      setAuthError(error instanceof Error ? error.message : "Login required.");
    } finally {
      setAuthLoading(false);
    }
  }

  useEffect(() => {
    void loadAuth();
  }, []);

  useEffect(() => {
    if (authLoading) return;

    if (!authUser?.userId) {
      const first = createNewSession();
      setSessions([first]);
      setActiveSessionId(first.id);
      setSelectedStack("");
      return;
    }

    const stored = loadSessions(authUser.userId);

    if (stored.length) {
      setSessions(stored);
      setActiveSessionId(stored[0].id);
      setSelectedStack(stored[0].selectedStack || "");
      return;
    }

    const first = createNewSession();
    setSessions([first]);
    setActiveSessionId(first.id);
    setSelectedStack("");
  }, [authLoading, authUser?.userId]);

  useEffect(() => {
    if (sessions.length && authUser?.userId) {
      saveSessions(authUser.userId, sessions);
    }
  }, [sessions, authUser?.userId]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isLoading, isGeneratingProject, isPublishingTemplate]);

  function updateActiveSession(updater: (session: ChatSession) => ChatSession) {
    setSessions((current) =>
      current.map((session) =>
        session.id === activeSessionId
          ? updater({ ...session, updatedAt: Date.now() })
          : session
      )
    );
  }

  function startNewChat() {
    const session = createNewSession();
    setSessions((current) => [session, ...current].slice(0, 30));
    setActiveSessionId(session.id);
    setSelectedStack("");
    setInput("");
    setSelectedChips([]);
    setProjectError("");
    setPreviewKey((current) => current + 1);
  }

  function selectSession(session: ChatSession) {
    setActiveSessionId(session.id);
    setSelectedStack(session.selectedStack || "");
    setInput("");
    setSelectedChips([]);
    setProjectError("");
    setPreviewKey((current) => current + 1);
  }

  function deleteSession(sessionId: string) {
    setSessions((current) => {
      const next = current.filter((session) => session.id !== sessionId);

      if (!next.length) {
        const fresh = createNewSession();
        setActiveSessionId(fresh.id);
        setSelectedStack("");
        return [fresh];
      }

      if (sessionId === activeSessionId) {
        setActiveSessionId(next[0].id);
        setSelectedStack(next[0].selectedStack || "");
      }

      return next;
    });
  }

  function clearHistory() {
    const fresh = createNewSession();
    setSessions([fresh]);
    setActiveSessionId(fresh.id);
    setSelectedStack("");
    setInput("");
    setSelectedChips([]);
    setProjectError("");
    setPreviewKey((current) => current + 1);

    if (typeof window !== "undefined") {
      window.localStorage.removeItem(getStorageKey(userId));
    }
  }

  function toggleChip(chip: string) {
    setSelectedChips((current) =>
      current.includes(chip)
        ? current.filter((item) => item !== chip)
        : [...current, chip]
    );
  }

  function requireLogin() {
    if (!userId) {
      setProjectError("Please login first. After login, AI chat and project generation will work.");
      return false;
    }

    return true;
  }

  async function sendMessage(customMessage?: string) {
    if (!requireLogin()) return;

    const messageText = (customMessage || currentRequirement).trim();

    if (!messageText || isLoading || !activeSession) return;

    const userMessage: ChatMessage = {
      role: "user",
      content: messageText,
    };

    const nextMessages = [...messages, userMessage];

    updateActiveSession((session) => ({
      ...session,
      title: createTitle(messageText),
      messages: nextMessages,
      lastRequirement: messageText,
      selectedStack,
    }));

    setInput("");
    setSelectedChips([]);
    setIsLoading(true);
    setProjectError("");

    try {
      const response = await fetch("/api/ai", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-user-id": userId,
        },
        body: JSON.stringify({
          message: messageText,
          history: messages.slice(-10),
          sessionId: activeSession.id,
          userId,
        }),
      });

      const data = await readJsonSafely(response);

      if (!response.ok) {
        throw new Error(
          getApiErrorMessage(
            data,
            `AI chat failed with status ${response.status}`
          )
        );
      }

      const reply = String(data.reply || data.assistant_reply || "");

      if (!reply) {
        throw new Error("AI chat returned empty reply.");
      }

      updateActiveSession((session) => ({
        ...session,
        messages: [
          ...nextMessages,
          {
            role: "assistant",
            content: reply,
          },
        ],
      }));

      await loadAuth();
    } catch (error) {
      updateActiveSession((session) => ({
        ...session,
        messages: [
          ...nextMessages,
          {
            role: "assistant",
            content: `AI chat failed.\n\n${formatError(error)}`,
          },
        ],
      }));
    } finally {
      setIsLoading(false);
      requestAnimationFrame(() => textareaRef.current?.focus());
    }
  }

  async function generateProject() {
    if (!requireLogin()) return;

    const requirement = activeRequirement.trim();

    if (!requirement || isGeneratingProject || !activeSession) return;

    setIsGeneratingProject(true);
    setProjectError("");

    try {
      const response = await fetch("/api/generate-project", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-user-id": userId,
        },
        body: JSON.stringify({
          message: requirement,
          stack: selectedStack || undefined,
          history: messages.slice(-10),
          sessionId: activeSession.id,
          userId,
        }),
      });

      const data = await readJsonSafely(response);

      if (!response.ok) {
        throw new Error(
          getApiErrorMessage(
            data,
            `Project generator failed with status ${response.status}`
          )
        );
      }

      if (!data.success || !data.projectId) {
        throw new Error("Project generator returned invalid response.");
      }

      const generated = normalizeProject(data as unknown as GeneratedProject);

      updateActiveSession((session) => ({
        ...session,
        title: createTitle(requirement),
        lastRequirement: requirement,
        selectedStack,
        generatedProject: generated,
        messages: [
          ...session.messages,
          {
            role: "assistant",
            content: `Project generated successfully.

Project Name: ${generated.projectName}
Project ID: ${generated.projectId}
Stack: ${generated.stack || "auto"}
Model: ${generated.model || walletSummary?.model || "wallet model"}
Preview: Included
ZIP Download: Included`,
          },
        ],
      }));

      setPreviewKey((current) => current + 1);
      await loadAuth();
    } catch (error) {
      const message = cleanPassError(formatError(error));
      setProjectError(message);

      updateActiveSession((session) => ({
        ...session,
        messages: [
          ...session.messages,
          {
            role: "assistant",
            content: `Project generation failed.\n\n${message}`,
          },
        ],
      }));
    } finally {
      setIsGeneratingProject(false);
    }
  }

  async function downloadGeneratedProject() {
    if (!requireLogin()) return;

    if (!downloadUrl || !generatedProject?.projectId) {
      setProjectError("Download URL missing.");
      return;
    }

    try {
      setProjectError("");

      const response = await fetch(withUserId(downloadUrl, userId), {
        cache: "no-store",
        headers: {
          "x-user-id": userId,
        },
      });

      if (!response.ok) {
        const data = await readJsonSafely(response);
        throw new Error(getApiErrorMessage(data, `Download failed: ${response.status}`));
      }

      const blob = await response.blob();

      if (!blob.size) {
        throw new Error("Downloaded ZIP is empty.");
      }

      const objectUrl = window.URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = objectUrl;
      link.download = `${generatedProject.projectId}.zip`;
      document.body.appendChild(link);
      link.click();
      link.remove();

      window.URL.revokeObjectURL(objectUrl);
    } catch (error) {
      setProjectError(
        error instanceof Error ? cleanPassError(error.message) : "Download ZIP failed."
      );
    }
  }

  async function publishGeneratedProjectToTemplates() {
    if (!requireLogin()) return;

    if (!generatedProject?.projectId) {
      setProjectError("Project missing. Generate project first.");
      return;
    }

    if (isPublishingTemplate) return;

    try {
      setIsPublishingTemplate(true);
      setProjectError("");

      const response = await fetch("/api/templates/publish", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-user-id": userId,
        },
        body: JSON.stringify({
          userId,
          projectId: generatedProject.projectId,
          title: generatedProject.projectName || "AI Generated Template",
          category: generatedProject.projectPlan?.businessType || "Generated",
          stack:
            generatedProject.stack ||
            generatedProject.projectPlan?.stack ||
            "Auto",
          price: 499,
          description:
            generatedProject.summary ||
            "AI generated project template with live preview and ZIP download.",
          sellerName: "Sambhajingr Developers",
          tags: [
            "AI Generated",
            generatedProject.stack || "AutoDev",
            generatedProject.projectPlan?.businessType || "Template",
          ],
          features: generatedProject.files?.length
            ? generatedProject.files.slice(0, 12)
            : ["preview.html", "source files", "download zip"],
          status: "published",
        }),
      });

      const data = await readJsonSafely(response);

      if (!response.ok || !data.success) {
        throw new Error(getApiErrorMessage(data, "Template publish failed"));
      }

      updateActiveSession((session) => ({
        ...session,
        messages: [
          ...session.messages,
          {
            role: "assistant",
            content:
              "Project has been published to the template marketplace. Open the Templates page to check it.",
          },
        ],
      }));
    } catch (error) {
      setProjectError(
        error instanceof Error ? error.message : "Publish template failed."
      );
    } finally {
      setIsPublishingTemplate(false);
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void sendMessage();
  }

  return (
    <main className="aiWindowPage">
      <style>{`
        html, body { overflow: hidden; }

        .aiWindowPage {
          height: 100dvh;
          width: 100%;
          overflow: hidden;
          display: grid;
          grid-template-columns: 300px minmax(0, 1fr) 430px;
          color: #f8fbff;
          background:
            radial-gradient(circle at top left, rgba(103,232,249,0.14), transparent 30%),
            radial-gradient(circle at bottom right, rgba(192,132,252,0.14), transparent 34%),
            #030712;
        }

        .aiWindowSidebar, .projectPanel {
          height: 100dvh;
          overflow-y: auto;
          padding: 16px;
          background: rgba(255,255,255,0.045);
          backdrop-filter: blur(18px);
        }

        .aiWindowSidebar { border-right: 1px solid rgba(255,255,255,0.10); }
        .projectPanel { border-left: 1px solid rgba(255,255,255,0.10); }

        .aiWindowBrand {
          display: flex;
          align-items: center;
          gap: 12px;
          padding: 12px;
          border-radius: 20px;
          color: #f8fbff;
          text-decoration: none;
          background: rgba(255,255,255,0.055);
          border: 1px solid rgba(255,255,255,0.08);
        }

        .aiWindowLogo, .aiChatAvatar {
          display: grid;
          place-items: center;
          color: #04111f;
          font-weight: 950;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa, #c084fc);
        }

        .aiWindowLogo { width: 44px; height: 44px; border-radius: 16px; }
        .aiChatAvatar { width: 44px; height: 44px; border-radius: 16px; flex: 0 0 auto; }

        .aiWindowBrand strong { display: block; font-size: 15px; line-height: 1.2; }
        .aiWindowBrand span { display: block; margin-top: 4px; color: #8ea0b8; font-size: 12px; line-height: 1.35; }

        .primaryAction, .dangerAction, .generateProjectBtn, .downloadBtn, .templatePublishBtn {
          width: 100%;
          cursor: pointer;
          border: 0;
          border-radius: 18px;
          padding: 14px 16px;
          font-weight: 950;
          font-size: 16px;
        }

        .primaryAction, .generateProjectBtn, .downloadBtn {
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
          box-shadow: 0 14px 36px rgba(34,211,238,0.20);
        }

        .templatePublishBtn {
          margin-top: 10px;
          color: #eafcff;
          background: rgba(255,255,255,0.08);
          border: 1px solid rgba(255,255,255,0.14);
        }

        .dangerAction {
          margin-top: 10px;
          color: #fecaca;
          background: rgba(239,68,68,0.13);
          border: 1px solid rgba(239,68,68,0.25);
        }

        .primaryAction { margin-top: 14px; }
        .generateProjectBtn { margin-top: 12px; }

        .generateProjectBtn:disabled, .templatePublishBtn:disabled {
          cursor: not-allowed;
          opacity: 0.55;
        }

        .backLink, .previewBtn {
          display: flex;
          justify-content: center;
          align-items: center;
          margin-top: 10px;
          text-align: center;
          text-decoration: none;
          border-radius: 18px;
          padding: 13px 16px;
          color: #eafcff;
          font-weight: 800;
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.10);
        }

        .sideTitle, .projectPanelTitle {
          margin: 22px 0 10px;
          color: #67e8f9;
          font-size: 12px;
          font-weight: 900;
          letter-spacing: 0.14em;
          text-transform: uppercase;
        }

        .chipRow { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 10px; }

        .chip {
          cursor: pointer;
          border: 1px solid rgba(255,255,255,0.10);
          color: #dffbff;
          border-radius: 999px;
          background: rgba(255,255,255,0.055);
          padding: 8px 11px;
          font-size: 12px;
          font-weight: 800;
        }

        .chip.active {
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee);
          border-color: transparent;
        }

        .sessionList, .examples, .projectBlocks { display: grid; gap: 10px; }

        .sessionItem, .projectBlock, .generatedProjectCard, .secureCard, .passCard {
          padding: 12px;
          border-radius: 18px;
          background: rgba(255,255,255,0.055);
          border: 1px solid rgba(255,255,255,0.08);
        }

        .passCard {
          border-color: rgba(34,211,238,0.20);
          background: rgba(34,211,238,0.08);
        }

        .sessionItem.active {
          border-color: rgba(103,232,249,0.34);
          background: rgba(103,232,249,0.08);
        }

        .sessionTop { display: flex; align-items: flex-start; justify-content: space-between; gap: 8px; }

        .sessionTitle {
          cursor: pointer;
          color: #f8fbff;
          font-size: 13px;
          font-weight: 900;
          line-height: 1.35;
          text-align: left;
          background: transparent;
          border: 0;
          padding: 0;
        }

        .sessionDelete {
          cursor: pointer;
          border: 0;
          color: #fecaca;
          background: rgba(239,68,68,0.12);
          border-radius: 8px;
          padding: 4px 7px;
        }

        .sessionMeta { margin-top: 6px; color: #8ea0b8; font-size: 11px; }

        .examples button {
          cursor: pointer;
          text-align: left;
          border-radius: 16px;
          border: 1px solid rgba(255,255,255,0.08);
          padding: 12px;
          color: #dffbff;
          background: rgba(255,255,255,0.055);
          line-height: 1.45;
        }

        .examples button:disabled { opacity: 0.45; cursor: not-allowed; }

        .aiChatArea {
          height: 100dvh;
          min-width: 0;
          display: flex;
          flex-direction: column;
          overflow: hidden;
        }

        .aiChatTopbar {
          height: 72px;
          flex: 0 0 auto;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          padding: 14px 22px;
          border-bottom: 1px solid rgba(255,255,255,0.10);
          background: rgba(3,7,18,0.74);
          backdrop-filter: blur(18px);
        }

        .aiChatTitle { display: flex; align-items: center; gap: 12px; min-width: 0; }
        .aiChatTitle h1 { margin: 0; font-size: 18px; line-height: 1.2; }
        .aiChatTitle p { margin: 4px 0 0; color: #8ea0b8; font-size: 13px; }

        .aiChatStatus {
          flex: 0 0 auto;
          color: #67e8f9;
          font-size: 13px;
          font-weight: 900;
          padding: 8px 12px;
          border-radius: 999px;
          background: rgba(34,211,238,0.10);
          border: 1px solid rgba(34,211,238,0.18);
        }

        .messagesScroll { flex: 1; min-height: 0; overflow-y: auto; padding: 24px 22px; }
        .messagesInner { width: min(920px, 100%); margin: 0 auto; display: flex; flex-direction: column; gap: 16px; }

        .messageRow { display: flex; width: 100%; }
        .messageRow.user { justify-content: flex-end; }
        .messageRow.assistant { justify-content: flex-start; }

        .bubble {
          max-width: min(760px, 88%);
          padding: 15px 17px;
          border-radius: 22px;
          white-space: pre-wrap;
          line-height: 1.75;
          font-size: 15px;
        }

        .bubble.user {
          color: #04111f;
          font-weight: 760;
          background: linear-gradient(135deg, #67e8f9, #22d3ee);
          border-bottom-right-radius: 7px;
        }

        .bubble.assistant {
          color: #f8fbff;
          background: rgba(255,255,255,0.07);
          border: 1px solid rgba(255,255,255,0.10);
          border-bottom-left-radius: 7px;
        }

        .composerWrap {
          flex: 0 0 auto;
          border-top: 1px solid rgba(255,255,255,0.10);
          background: rgba(3,7,18,0.82);
          backdrop-filter: blur(18px);
          padding: 12px 22px 18px;
        }

        .composerInner { width: min(920px, 100%); margin: 0 auto; }

        .inputBox {
          display: grid;
          grid-template-columns: 1fr auto;
          gap: 10px;
          align-items: end;
          border-radius: 24px;
          padding: 10px;
          background: rgba(255,255,255,0.07);
          border: 1px solid rgba(255,255,255,0.12);
        }

        .textarea {
          width: 100%;
          min-height: 54px;
          max-height: 160px;
          resize: none;
          outline: none;
          border: 0;
          color: #ffffff;
          background: transparent;
          padding: 8px 10px;
          line-height: 1.6;
          font-size: 15px;
        }

        .textarea::placeholder { color: #7f91a8; }

        .sendBtn {
          min-width: 104px;
          min-height: 50px;
          cursor: pointer;
          border: 0;
          border-radius: 18px;
          color: #04111f;
          font-weight: 950;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        }

        .sendBtn:disabled { cursor: not-allowed; opacity: 0.55; }

        .errorBox {
          margin-top: 12px;
          padding: 12px;
          border-radius: 16px;
          color: #fecaca;
          background: rgba(239,68,68,0.12);
          border: 1px solid rgba(239,68,68,0.24);
          font-size: 13px;
          line-height: 1.6;
          white-space: pre-wrap;
        }

        .secureCard p, .passCard p {
          color: #9fb0c5;
          line-height: 1.55;
          font-size: 13px;
          word-break: break-all;
        }

        .fileList { margin: 8px 0 0; padding-left: 18px; }

        .projectBlock strong, .generatedProjectCard strong, .passCard strong {
          display: block;
          font-size: 14px;
          color: #f8fbff;
        }

        .projectBlock span, .projectBlock li, .projectPanel p {
          display: block;
          margin-top: 5px;
          color: #9fb0c5;
          font-size: 13px;
          line-height: 1.55;
        }

        .previewFrame {
          width: 100%;
          height: 390px;
          border: 1px solid rgba(255,255,255,0.12);
          border-radius: 18px;
          background: #ffffff;
        }

        @media (max-width: 1040px) {
          html, body { overflow: auto; }
          .aiWindowPage { height: auto; min-height: 100dvh; overflow: visible; grid-template-columns: 1fr; }
          .aiWindowSidebar { height: auto; border-right: 0; border-bottom: 1px solid rgba(255,255,255,0.10); }
          .aiChatArea { height: 76dvh; min-height: 620px; }
          .projectPanel { height: auto; min-height: 420px; border-left: 0; border-top: 1px solid rgba(255,255,255,0.10); }
          .previewFrame { height: 420px; }
        }

        @media (max-width: 760px) {
          .inputBox { grid-template-columns: 1fr; }
          .sendBtn { width: 100%; }
          .bubble { max-width: 94%; font-size: 14px; }
          .previewFrame { height: 360px; }
        }
      `}</style>

      <aside className="aiWindowSidebar">
        <Link href="/" className="aiWindowBrand">
          <div className="aiWindowLogo">SD</div>
          <div>
            <strong>Sambhajingr Developers</strong>
            <span>Project Pass AutoDev AI</span>
          </div>
        </Link>

        <button type="button" className="primaryAction" onClick={startNewChat}>
          + New Chat
        </button>

        <button type="button" className="dangerAction" onClick={clearHistory}>
          Clear History
        </button>

        <Link href="/" className="backLink">← Back to Website</Link>

        <div className="sideTitle">User Wallet</div>

        <div className="secureCard">
          {authLoading ? (
            <p>Checking login...</p>
          ) : authUser ? (
            <>
              <strong>{authUser.name || "User"}</strong>
              <p>{authUser.email}</p>
              <p>User ID: {authUser.userId}</p>
              <p>Plan: {getPlanName(walletSummary?.plan)}</p>
              <p>Model: {walletSummary?.model || "gpt-4.1-mini"}</p>
              <p>Messages Left: {walletSummary?.messagesRemaining ?? 0}</p>
              <p>Project Passes Left: {walletSummary?.projectPassesRemaining ?? 0}</p>
              <p>ZIP Download: Included</p>
              <Link className="previewBtn" href="/wallet">Buy Project Pass</Link>
              <Link className="previewBtn" href="/profile">Open Profile</Link>
            </>
          ) : (
            <>
              <strong>Login Required</strong>
              <p>{authError}</p>
              <Link className="previewBtn" href="/login">Login</Link>
              <Link className="previewBtn" href="/register">Register</Link>
            </>
          )}
        </div>

        <div className="sideTitle">Project Pass Rule</div>

        <div className="passCard">
          <strong>Every pass includes</strong>
          <p>5 AI messages</p>
          <p>1 project generation</p>
          <p>Preview included</p>
          <p>ZIP download included</p>
        </div>

        <div className="sideTitle">Chat History</div>

        <div className="sessionList">
          {sessions.map((session) => (
            <div
              key={session.id}
              className={`sessionItem ${
                session.id === activeSessionId ? "active" : ""
              }`}
            >
              <div className="sessionTop">
                <button
                  type="button"
                  className="sessionTitle"
                  onClick={() => selectSession(session)}
                >
                  {session.title}
                </button>

                <button
                  type="button"
                  className="sessionDelete"
                  onClick={() => deleteSession(session.id)}
                  aria-label="Delete chat"
                >
                  ×
                </button>
              </div>

              <div className="sessionMeta">
                {session.generatedProject
                  ? `Project: ${session.generatedProject.projectName}`
                  : "No project yet"}
              </div>
            </div>
          ))}
        </div>

        <div className="sideTitle">Technology Stack</div>

        <div className="chipRow">
          {stackOptions.map((stack) => (
            <button
              key={stack.label}
              type="button"
              className={`chip ${selectedStack === stack.value ? "active" : ""}`}
              onClick={() => setSelectedStack(stack.value)}
            >
              {stack.label}
            </button>
          ))}
        </div>

        <div className="sideTitle">Examples</div>

        <div className="examples">
          {starterPrompts.map((prompt) => (
            <button
              key={prompt}
              type="button"
              disabled={isLoading || !userId}
              onClick={() => void sendMessage(prompt)}
            >
              {prompt}
            </button>
          ))}
        </div>
      </aside>

      <section className="aiChatArea">
        <header className="aiChatTopbar">
          <div className="aiChatTitle">
            <div className="aiChatAvatar">AI</div>
            <div>
              <h1>Website Requirement Assistant</h1>
              <p>5 messages + 1 project + preview + ZIP</p>
            </div>
          </div>

          <div className="aiChatStatus">
            {isLoading || isGeneratingProject || isPublishingTemplate
              ? "Working..."
              : authUser
              ? "Online"
              : "Login Required"}
          </div>
        </header>

        <div className="messagesScroll">
          <div className="messagesInner">
            {messages.map((message, index) => (
              <div
                key={`${message.role}-${index}`}
                className={`messageRow ${message.role}`}
              >
                <div className={`bubble ${message.role}`}>{message.content}</div>
              </div>
            ))}

            {isLoading ? (
              <div className="messageRow assistant">
                <div className="bubble assistant">Typing...</div>
              </div>
            ) : null}

            <div ref={messagesEndRef} />
          </div>
        </div>

        <footer className="composerWrap">
          <div className="composerInner">
            <div className="chipRow">
              {requirementChips.map((chip) => (
                <button
                  key={chip}
                  type="button"
                  className={`chip ${
                    selectedChips.includes(chip) ? "active" : ""
                  }`}
                  onClick={() => toggleChip(chip)}
                >
                  {chip}
                </button>
              ))}
            </div>

            <form className="inputBox" onSubmit={handleSubmit}>
              <textarea
                ref={textareaRef}
                className="textarea"
                value={input}
                onChange={(event) => setInput(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" && !event.shiftKey) {
                    event.preventDefault();
                    void sendMessage();
                  }
                }}
                placeholder={
                  authUser
                    ? "Example: Create a school admission website with enquiry form and admin panel..."
                    : "Please login first..."
                }
                disabled={!authUser}
              />

              <button
                type="submit"
                className="sendBtn"
                disabled={isLoading || !currentRequirement || !authUser}
              >
                Send
              </button>
            </form>
          </div>
        </footer>
      </section>

      <aside className="projectPanel">
        <div className="projectPanelTitle">Generated Project</div>

        <button
          type="button"
          className="generateProjectBtn"
          disabled={!activeRequirement || isGeneratingProject || !authUser}
          onClick={() => void generateProject()}
        >
          {isGeneratingProject ? "Generating..." : "Generate Project"}
        </button>

        {projectError ? <div className="errorBox">{projectError}</div> : null}

        {generatedProject ? (
          <div className="projectBlocks" style={{ marginTop: 14 }}>
            <div className="generatedProjectCard">
              <strong>{generatedProject.projectName}</strong>

              {generatedProject.summary ? <p>{generatedProject.summary}</p> : null}

              <span>Project ID:</span>
              <p style={{ wordBreak: "break-all" }}>{generatedProject.projectId}</p>

              <span>Stack:</span>
              <p>{generatedProject.stack || generatedProject.projectPlan?.stack || "auto"}</p>

              <span>Model:</span>
              <p>{generatedProject.model || walletSummary?.model || "wallet model"}</p>

              <span>Preview:</span>
              <p>Included</p>

              <span>ZIP Download:</span>
              <p>Included</p>

              <span>Source:</span>
              <p>{generatedProject.source || "ec2-autodev-ai"}</p>

              {downloadUrl ? (
                <button
                  type="button"
                  className="downloadBtn"
                  onClick={() => void downloadGeneratedProject()}
                >
                  Download ZIP
                </button>
              ) : null}

              <button
                type="button"
                className="templatePublishBtn"
                disabled={isPublishingTemplate}
                onClick={() => void publishGeneratedProjectToTemplates()}
              >
                {isPublishingTemplate ? "Sending..." : "Send to Templates"}
              </button>

              <Link className="previewBtn" href="/templates">
                Open Templates Page
              </Link>
            </div>

            {previewUrl ? (
              <div className="projectBlock">
                <strong>Website Preview</strong>

                <iframe
                  key={`${generatedProject.projectId}-${previewKey}`}
                  className="previewFrame"
                  src={withCacheBust(withUserId(previewUrl, userId), previewKey)}
                  title="Generated Website Preview"
                />

                <a
                  className="previewBtn"
                  href={withCacheBust(withUserId(previewUrl, userId), previewKey)}
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  Open Full Preview
                </a>
              </div>
            ) : null}

            {generatedProject.files?.length ? (
              <div className="projectBlock">
                <strong>Generated Files</strong>
                <ul className="fileList">
                  {generatedProject.files.map((file) => (
                    <li key={file}>{file}</li>
                  ))}
                </ul>
              </div>
            ) : null}
          </div>
        ) : (
          <div className="projectBlock" style={{ marginTop: 14 }}>
            <strong>No project generated yet</strong>
            <span>
              Login, describe your requirement, then click Generate Project.
            </span>
          </div>
        )}
      </aside>
    </main>
  );
}
