import SectionContainer from "../layout/SectionContainer";
import PrimaryButton from "../layout/PrimaryButton";
import SecondaryButton from "../layout/SecondaryButton";
import HeroStats from "./HeroStats";
import HeroPreviewCard from "./HeroPreviewCard";

export default function HeroSection() {
  return (
    <SectionContainer id="home">
      <section className="hero heroPremium">
        <div className="heroContent">
          <span className="heroBadge">
            Futuristic Web, App, Software & AI Solutions
          </span>

          <h1>
            Build your
            <span className="gradientText"> premium digital future </span>
            with Sambhangr Developers
          </h1>

          <p>
            Hum modern websites, scalable software, mobile apps aur AI-powered
            business systems ke liye premium digital experiences create karte
            hain. Structure future-ready hai, design trust-building hai, aur
            overall feel high-end tech brand jaisi rakhi gayi hai.
          </p>

          <div className="heroHighlights">
            <span>Premium UI</span>
            <span>Smart Architecture</span>
            <span>Future-Ready Systems</span>
          </div>

          <div className="heroActions">
            <PrimaryButton href="#services">Explore Services</PrimaryButton>
            <SecondaryButton href="#portfolio">View Portfolio</SecondaryButton>
          </div>

          <HeroStats />
        </div>

        <HeroPreviewCard />
      </section>
    </SectionContainer>
  );
}
