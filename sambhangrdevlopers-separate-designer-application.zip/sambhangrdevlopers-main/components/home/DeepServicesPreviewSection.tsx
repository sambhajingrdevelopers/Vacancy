import Link from "next/link";
import { services, servicePackages } from "../data/services";
import { company } from "../data/company";

export default function DeepServicesPreviewSection() {
  const enquiryMessage = [
    "Hello Sambhajingr Developers,",
    "",
    "I want to know about your services and project setup offers.",
    "Please contact me.",
  ].join("\n");

  const whatsappUrl = `https://wa.me/919637705868?text=${encodeURIComponent(
    enquiryMessage
  )}`;

  const emailUrl = `mailto:${company.email}?subject=${encodeURIComponent(
    "Service Enquiry - Sambhajingr Developers"
  )}&body=${encodeURIComponent(enquiryMessage)}`;

  return (
    <section className="deepHomeServices" id="deep-services">
      <style>{`
        .deepHomeServices {
          position: relative;
          overflow: hidden;
          border-radius: 34px;
          padding: 28px;
          border: 1px solid rgba(255,255,255,0.10);
          background:
            radial-gradient(circle at 10% 12%, rgba(103,232,249,0.16), transparent 26%),
            radial-gradient(circle at 90% 10%, rgba(251,191,36,0.12), transparent 24%),
            linear-gradient(180deg, rgba(255,255,255,0.075), rgba(255,255,255,0.03));
          box-shadow: 0 28px 90px rgba(0,0,0,0.32);
        }

        .deepHomeTop {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 18px;
          align-items: end;
          margin-bottom: 22px;
        }

        .deepHomeTop h2 {
          margin: 10px 0 0;
          font-size: clamp(32px, 5vw, 56px);
          line-height: 1.04;
          letter-spacing: -0.045em;
          max-width: 900px;
        }

        .deepHomeTop h2 span {
          color: #67e8f9;
        }

        .deepHomeTop p {
          margin: 14px 0 0;
          color: #b7c2d0;
          line-height: 1.8;
          max-width: 860px;
        }

        .deepHomeActions {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
          justify-content: flex-end;
        }

        .deepServiceGrid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
          gap: 16px;
        }

        .deepServiceCard {
          display: flex;
          flex-direction: column;
          gap: 14px;
          min-height: 360px;
          border-radius: 26px;
          padding: 20px;
          background: rgba(15,23,42,0.72);
          border: 1px solid rgba(255,255,255,0.10);
        }

        .deepServiceCard h3 {
          margin: 0;
          font-size: 25px;
          line-height: 1.12;
        }

        .deepServiceCard p {
          margin: 0;
          color: #b7c2d0;
          line-height: 1.7;
        }

        .deepBadgeRow {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .deepBadge {
          display: inline-flex;
          width: fit-content;
          padding: 7px 10px;
          border-radius: 999px;
          color: #dffbff;
          background: rgba(34,211,238,0.10);
          border: 1px solid rgba(34,211,238,0.18);
          font-size: 12px;
          font-weight: 900;
        }

        .deepServiceList {
          display: grid;
          gap: 8px;
          padding: 0;
          margin: 0;
          list-style: none;
        }

        .deepServiceList li {
          display: grid;
          grid-template-columns: 18px 1fr;
          gap: 8px;
          color: #dbeafe;
          line-height: 1.5;
          font-size: 14px;
        }

        .deepServiceList li::before {
          content: "✓";
          color: #67e8f9;
          font-weight: 950;
        }

        .deepServiceCardActions {
          margin-top: auto;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }

        .deepOfferStrip {
          margin-top: 22px;
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
          gap: 12px;
        }

        .deepOfferBox {
          border-radius: 22px;
          padding: 16px;
          background: rgba(255,255,255,0.055);
          border: 1px solid rgba(255,255,255,0.10);
        }

        .deepOfferBox strong {
          display: block;
          color: #f8fbff;
          font-size: 18px;
          line-height: 1.25;
        }

        .deepOfferBox span {
          display: block;
          margin-top: 8px;
          color: #67e8f9;
          font-size: 26px;
          font-weight: 950;
          letter-spacing: -0.04em;
        }

        .deepOfferBox small {
          display: block;
          margin-top: 8px;
          color: #9fb0c5;
          line-height: 1.5;
        }

        @media (max-width: 760px) {
          .deepHomeTop {
            grid-template-columns: 1fr;
          }

          .deepHomeActions {
            justify-content: stretch;
          }

          .deepHomeActions a,
          .deepServiceCardActions a {
            width: 100%;
            justify-content: center;
          }

          .deepServiceCardActions {
            grid-template-columns: 1fr;
          }

          .deepHomeServices {
            padding: 20px;
            border-radius: 26px;
          }
        }
      `}</style>

      <div className="deepHomeTop">
        <div>
          <div className="eyebrow">Deep Services</div>

          <h2>
            Complete digital services for <span>website, app, software, AI</span>{" "}
            and launch setup
          </h2>

          <p>
            From simple business website to advanced payment gateway, AI,
            dashboard, hosting and domain setup — every service has a dedicated
            detail page with deliverables, process and support.
          </p>
        </div>

        <div className="deepHomeActions">
          <Link href="/services" className="primaryBtn">
            View All Services
          </Link>

          <a
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="secondaryBtn"
          >
            WhatsApp
          </a>
        </div>
      </div>

      <div className="deepServiceGrid">
        {services.slice(0, 6).map((service) => (
          <article className="deepServiceCard premiumHover" key={service.slug}>
            <div className="deepBadgeRow">
              <span className="deepBadge">{service.category}</span>
              <span className="deepBadge">{service.badge}</span>
            </div>

            <h3>{service.title}</h3>

            <p>{service.summary}</p>

            <div className="deepBadgeRow">
              <span className="deepBadge">{service.priceLabel}</span>
              <span className="deepBadge">{service.tools[0]}</span>
            </div>

            <ul className="deepServiceList">
              {service.deliverables.slice(0, 3).map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>

            <div className="deepServiceCardActions">
              <Link href={`/services/${service.slug}`} className="primaryBtn">
                Details
              </Link>

              <a
                href={whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="secondaryBtn"
              >
                Enquiry
              </a>
            </div>
          </article>
        ))}
      </div>

      <div className="deepOfferStrip">
        {servicePackages.map((offer) => (
          <div className="deepOfferBox" key={offer.name}>
            <strong>{offer.name}</strong>
            <span>{offer.price}</span>
            <small>{offer.badge}</small>
          </div>
        ))}
      </div>

      <div className="deepHomeActions" style={{ marginTop: 20 }}>
        <Link href="/services" className="primaryBtn">
          Open Deep Services Page
        </Link>

        <a href={emailUrl} className="secondaryBtn">
          Email Enquiry
        </a>
      </div>
    </section>
  );
}
