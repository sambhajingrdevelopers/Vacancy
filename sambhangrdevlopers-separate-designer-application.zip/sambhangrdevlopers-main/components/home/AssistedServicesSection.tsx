import SectionContainer from "../layout/SectionContainer";
import SectionHeading from "../layout/SectionHeading";
import ServiceCard from "../cards/ServiceCard";
import { assistedServices } from "../data/services";

export default function AssistedServicesSection() {
  return (
    <SectionContainer>
      <div className="sectionBlock">
        <SectionHeading
          eyebrow="Startup Launch Support"
          title="Assisted services jo client value ko expand karti hain"
          description="Ye direct software development ke bahar wali services hain, isliye inhe separate assisted bucket me rakha gaya hai. Structure same card system par based hai taaki future edits controlled rahein."
        />

        <div className="grid threeCols">
          {assistedServices.map((item) => (
            <ServiceCard key={item.title} item={item} status="assisted" />
          ))}
        </div>
      </div>
    </SectionContainer>
  );
}