import SectionContainer from "../layout/SectionContainer";
import SectionHeading from "../layout/SectionHeading";
import PortfolioCard from "../cards/PortfolioCard";
import { portfolioItems } from "../data/portfolio";

export default function PortfolioSection() {
  return (
    <SectionContainer id="portfolio">
      <div className="sectionBlock">
        <SectionHeading
          eyebrow="Portfolio"
          title="Project showcase jo company ko credible aur premium banata hai"
          description="Ye cards abhi structured showcase format me hain. Future me real screenshots, client work aur full case studies isi block me deep tareeke se add kiye ja sakte hain."
        />

        <div className="grid threeCols">
          {portfolioItems.map((item) => (
            <PortfolioCard key={item.title} item={item} />
          ))}
        </div>
      </div>
    </SectionContainer>
  );
}