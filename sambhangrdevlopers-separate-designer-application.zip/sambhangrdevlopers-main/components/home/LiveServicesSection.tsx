import SectionContainer from "../layout/SectionContainer";
import SectionHeading from "../layout/SectionHeading";
import ServiceCard from "../cards/ServiceCard";
import { liveServices } from "../data/services";

export default function LiveServicesSection() {
  return (
    <SectionContainer id="services">
      <div className="sectionBlock">
        <SectionHeading
          eyebrow="Live Services"
          title="Core IT services jo company abhi strongly present kar sakti hai"
          description="Ye live service layer brand ki real working capability ko premium tareeke se show karti hai. Har card independently editable hai, isliye future me section tootega nahi."
        />

        <div className="grid fourCols">
          {liveServices.map((item) => (
            <ServiceCard key={item.title} item={item} status="live" />
          ))}
        </div>
      </div>
    </SectionContainer>
  );
}
