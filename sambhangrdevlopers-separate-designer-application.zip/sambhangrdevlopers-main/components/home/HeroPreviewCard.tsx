export default function HeroPreviewCard() {
  return (
    <div className="heroPanel glassCard premiumHover">
      <div className="panelWindowDots">
        <span />
        <span />
        <span />
      </div>

      <div className="panelGrid">
        <div className="miniPanel big">
          <div className="miniTitle">Brand Position</div>
          <div className="bigTitle">Premium Tech Identity</div>

          <div className="heroMockLogo">
            <div className="heroMockSymbol">S</div>
            <div className="heroMockText">
              <strong>Sambhangr</strong>
              <span>Developers</span>
            </div>
          </div>

          <div className="chartMock">
            <div className="bar a" />
            <div className="bar b" />
            <div className="bar c" />
            <div className="bar d" />
          </div>
        </div>

        <div className="miniSide">
          <div className="miniPanel">
            <div className="miniTitle">Core Focus</div>
            <div className="chipWrap">
              <span>Web</span>
              <span>Apps</span>
              <span>Software</span>
              <span>AI</span>
              <span>Growth</span>
            </div>
          </div>

          <div className="miniPanel">
            <div className="miniTitle">Experience</div>
            <div className="bigSmall">
              Glow, depth, motion feel and premium structure
            </div>
          </div>

          <div className="miniPanel">
            <div className="miniTitle">Brand Feel</div>
            <div className="energyLine" />
            <div className="energyDots">
              <span />
              <span />
              <span />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
