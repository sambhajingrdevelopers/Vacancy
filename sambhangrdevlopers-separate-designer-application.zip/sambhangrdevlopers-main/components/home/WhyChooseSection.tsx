import SectionContainer from "../layout/SectionContainer";
import SectionHeading from "../layout/SectionHeading";
import FeatureCard from "../cards/FeatureCard";

const items = [
  {
    title: "Business-first planning",
    desc: "Har project ko sirf design ke hisab se nahi, business result aur practical growth ke hisab se structure kiya jata hai.",
    icon: "✦",
  },
  {
    title: "Premium modern UI",
    desc: "Clean, glowing aur trust-building interface jo brand ko high-end tech company jaisa impression deta hai.",
    icon: "◈",
  },
  {
    title: "Scalable structure",
    desc: "Aaj ki zarurat ke saath future expansion ko dhyan me rakhkar architecture ready kiya jata hai.",
    icon: "◎",
  },
  {
    title: "Support mindset",
    desc: "Launch ke baad bhi updates, maintenance aur long-term improvement ko importance di jati hai.",
    icon: "✶",
  },
];

export default function WhyChooseSection() {
  return (
    <SectionContainer>
      <div className="sectionBlock whyChooseWrap">
        <SectionHeading
          eyebrow="Why Choose Us"
          title="Sirf design nahi, ek premium execution mindset"
          description="Sambhangr Developers ko is tarah position kiya gaya hai ki brand trust, premium visuals, scalable systems aur business clarity ek saath feel ho."
        />

        <div className="grid fourCols">
          {items.map((item) => (
            <FeatureCard
              key={item.title}
              title={item.title}
              desc={item.desc}
              icon={item.icon}
            />
          ))}
        </div>
      </div>
    </SectionContainer>
  );
}
