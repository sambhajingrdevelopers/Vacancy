import SectionContainer from "../layout/SectionContainer";
import SectionHeading from "../layout/SectionHeading";
import ServiceCard from "../cards/ServiceCard";
import { comingSoonServices } from "../data/services";

export default function ComingSoonSection() {
  return (
    <SectionContainer>
      <div className="sectionBlock">
        <SectionHeading
          eyebrow="Coming Soon"
          title="Future roadmap services jo company ki growth direction dikhati hain"
          description="In services ko roadmap ke roop me dikhaya gaya hai taaki future expansion clear lage aur brand ka long-term vision visitor ko samajh aaye."
        />

        <div className="grid threeCols">
          {comingSoonServices.map((item) => (
            <ServiceCard key={item.title} item={item} status="soon" />
          ))}
        </div>
      </div>
    </SectionContainer>
  );
}