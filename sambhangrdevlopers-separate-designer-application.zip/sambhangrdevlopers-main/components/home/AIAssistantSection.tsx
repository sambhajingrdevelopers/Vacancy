"use client";

import { FormEvent, useMemo, useRef, useState } from "react";

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
};

const starterQuestions = [
  "Mujhe website development package ke baare me batao",
  "Sambhangr Developers app aur software kaise banata hai?",
  "Mere business ke liye best digital solution suggest karo",
];

function createFallbackReply(message: string) {
  const clean = message.trim();

  if (!clean) {
    return "Please apna question likhiye. Main Sambhangr Developers ki services, website, app, software aur AI solutions ke baare me help kar sakta hoon.";
  }

  return `Aapka question mila: "${clean}". Abhi live Python AI backend connect nahi hai, isliye demo response show ho raha hai. Backend connect karne ke liye .env.local me AI_BACKEND_URL=http://127.0.0.1:8000/chat set kijiye, phir aapki banayi hui Python AI ka real response yahan dikhega.`;
}

export default function AIAssistantSection() {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      role: "assistant",
      content:
        "Namaste! Main Sambhangr Developers AI assistant hoon. Aap website, app, software, digital marketing, vacancies ya custom IT solution ke baare me question pooch sakte hain.",
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const inputRef = useRef<HTMLTextAreaElement | null>(null);

  const lastUserMessage = useMemo(
    () => [...messages].reverse().find((message) => message.role === "user"),
    [messages]
  );

  async function sendMessage(messageText?: string) {
    const text = (messageText ?? input).trim();

    if (!text || isLoading) return;

    const userMessage: ChatMessage = { role: "user", content: text };
    const nextMessages = [...messages, userMessage];

    setMessages(nextMessages);
    setInput("");
    setIsLoading(true);

    try {
      const response = await fetch("/api/ai", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: text,
          history: messages.slice(-8),
          pageContext: "Sambhangr Developers homepage AI assistant",
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data?.error || "AI response failed");
      }

      setMessages([
        ...nextMessages,
        {
          role: "assistant",
          content: data?.reply || createFallbackReply(text),
        },
      ]);
    } catch (error) {
      console.error(error);
      setMessages([
        ...nextMessages,
        {
          role: "assistant",
          content: createFallbackReply(text),
        },
      ]);
    } finally {
      setIsLoading(false);
      requestAnimationFrame(() => inputRef.current?.focus());
    }
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    void sendMessage();
  }

  return (
    <section id="ai-assistant" className="aiAssistantSection">
      <div className="aiAssistantGlow aiAssistantGlowOne" />
      <div className="aiAssistantGlow aiAssistantGlowTwo" />

      <div className="aiAssistantIntro">
        <div className="eyebrow">AI Assistant</div>
        <h2>Sambhangr Developers ki homepage par ab AI chatbot ready hai</h2>
        <p>
          Ye section frontend se Next.js API route ko call karta hai. API route
          aapki Python AI backend se connect ho sakta hai, isliye customer ko
          website par hi instant guidance milegi.
        </p>

        <div className="aiFeatureGrid">
          <div>
            <span>01</span>
            <strong>Customer Questions</strong>
            <p>Services, pricing, app, website aur software queries.</p>
          </div>
          <div>
            <span>02</span>
            <strong>Backend Connected</strong>
            <p>Next.js API route se Python AI backend bridge.</p>
          </div>
          <div>
            <span>03</span>
            <strong>Lead Support</strong>
            <p>Customer ko contact form tak guide karne ke liye ready.</p>
          </div>
        </div>
      </div>

      <div className="aiChatCard">
        <div className="aiChatHeader">
          <div className="aiBotAvatar">AI</div>
          <div>
            <h3>Sambhangr AI Help Desk</h3>
            <p>{isLoading ? "AI typing..." : "Online • Homepage assistant"}</p>
          </div>
        </div>

        <div className="aiChatMessages" aria-live="polite">
          {messages.map((message, index) => (
            <div
              key={`${message.role}-${index}-${message.content.slice(0, 12)}`}
              className={`aiMessage ${
                message.role === "user" ? "aiMessageUser" : "aiMessageBot"
              }`}
            >
              {message.content}
            </div>
          ))}

          {isLoading ? (
            <div className="aiMessage aiMessageBot aiTypingBubble">
              <span />
              <span />
              <span />
            </div>
          ) : null}
        </div>

        <div className="aiSuggestionRow">
          {starterQuestions.map((question) => (
            <button
              key={question}
              type="button"
              onClick={() => void sendMessage(question)}
              disabled={isLoading}
            >
              {question}
            </button>
          ))}
        </div>

        <form className="aiChatForm" onSubmit={handleSubmit}>
          <textarea
            ref={inputRef}
            value={input}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault();
                void sendMessage();
              }
            }}
            rows={2}
            placeholder="AI se question poochiye..."
          />
          <button type="submit" disabled={isLoading || !input.trim()}>
            Send
          </button>
        </form>

        <div className="aiChatFootnote">
          {lastUserMessage
            ? `Last query: ${lastUserMessage.content}`
            : "Python backend connect karne ke baad real AI answer yahan show hoga."}
        </div>
      </div>
    </section>
  );
}
