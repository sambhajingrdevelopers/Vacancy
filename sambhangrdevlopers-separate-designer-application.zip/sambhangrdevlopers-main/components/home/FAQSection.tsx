import SectionContainer from "../layout/SectionContainer";
import SectionHeading from "../layout/SectionHeading";
import FAQCard from "../cards/FAQCard";
import { faqs } from "../data/faqs";

export default function FAQSection() {
  return (
    <SectionContainer>
      <div className="sectionBlock">
        <SectionHeading
          eyebrow="FAQ"
          title="Quick answers"
          description="Ye block enquiry hesitation kam karta hai aur visitor ko clear expectation deta hai."
        />

        <div className="stack">
          {faqs.map((item) => (
            <FAQCard key={item.q} item={item} />
          ))}
        </div>
      </div>
    </SectionContainer>
  );
}