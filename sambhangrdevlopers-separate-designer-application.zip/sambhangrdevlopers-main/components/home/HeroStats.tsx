import StatCard from "../cards/StatCard";

const stats = [
  { value: "50+", label: "Project-ready Solutions" },
  { value: "10+", label: "Core Service Categories" },
  { value: "24/7", label: "Support Direction" },
  { value: "100%", label: "Business-first Approach" },
];

export default function HeroStats() {
  return (
    <div className="statsGrid">
      {stats.map((item) => (
        <StatCard key={item.label} value={item.value} label={item.label} />
      ))}
    </div>
  );
}
