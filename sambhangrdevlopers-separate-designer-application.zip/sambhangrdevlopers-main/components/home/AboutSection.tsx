import SectionContainer from "../layout/SectionContainer";
import SectionHeading from "../layout/SectionHeading";
import FeatureCard from "../cards/FeatureCard";

export default function AboutSection() {
  return (
    <SectionContainer id="about">
      <div className="aboutWrap">
        <div className="card aboutMainCard premiumHover">
          <div className="aboutGlow" />
          <SectionHeading
            eyebrow="About Sambhangr Developers"
            title="Technology ko practical business value me convert karne wali company"
            description="Sambhangr Developers ka positioning ek aisi IT company ke roop me kiya gaya hai jo websites, software, apps aur automation solutions ke through modern digital presence aur business growth support kare. Structure future-ready hai, isliye aage scale karna easy rahega."
          />
        </div>

        <div className="stack">
          <FeatureCard
            title="Vision"
            desc="Businesses ko strong, modern aur future-ready digital systems dena."
            icon="◈"
          />
          <FeatureCard
            title="Mission"
            desc="Clarity, trust aur scalable execution ke saath premium solutions provide karna."
            icon="◎"
          />
          <FeatureCard
            title="Approach"
            desc="Business requirement samajhkar design, development aur support aligned rakhna."
            icon="✦"
          />
        </div>
      </div>
    </SectionContainer>
  );
}