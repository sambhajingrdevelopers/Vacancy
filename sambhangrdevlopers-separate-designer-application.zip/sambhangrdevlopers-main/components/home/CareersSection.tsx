import SectionContainer from "../layout/SectionContainer";
import SectionHeading from "../layout/SectionHeading";
import FeatureCard from "../cards/FeatureCard";

const solutions = [
  {
    title: "Startup Launch Systems",
    desc: "Website, business setup support, payment integration aur digital launch flow ek jagah.",
    icon: "◈",
  },
  {
    title: "Business Automation",
    desc: "Internal dashboards, workflow systems, admin control aur operational efficiency tools.",
    icon: "✦",
  },
  {
    title: "E-commerce Growth",
    desc: "Product showcase, online selling, trust-building UI aur smooth order experience.",
    icon: "◎",
  },
  {
    title: "AI-Powered Support",
    desc: "Smart enquiry handling, chatbot flows aur automation-based customer interaction tools.",
    icon: "✶",
  },
];

export default function SolutionsSection() {
  return (
    <SectionContainer id="solutions">
      <div className="sectionBlock">
        <SectionHeading
          eyebrow="Solutions"
          title="Business problems ke liye ready-made solution direction"
          description="Sirf services hi nahi, balki complete business use-cases ko solve karne wale structured solution blocks bhi yahan dikhaye gaye hain."
        />

        <div className="grid fourCols">
          {solutions.map((item) => (
            <FeatureCard
              key={item.title}
              title={item.title}
              desc={item.desc}
              icon={item.icon}
            />
          ))}
        </div>
      </div>
    </SectionContainer>
  );
}
