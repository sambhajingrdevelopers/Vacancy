import SectionContainer from "../layout/SectionContainer";
import ContactInfoList from "../contact/ContactInfoList";
import MapPlaceholder from "../contact/MapPlaceholder";
import ContactForm from "../contact/ContactForm";
import SectionHeading from "../layout/SectionHeading";

export default function ContactSection() {
  return (
    <SectionContainer id="contact">
      <SectionHeading
        eyebrow="Contact"
        title="Let’s build your next digital project"
        description="Call, WhatsApp, visit location, or send a quick project enquiry directly from this section."
      />

      <div className="contactPremiumGrid">
        <div className="stack">
          <ContactInfoList />
          <MapPlaceholder />
        </div>

        <ContactForm />
      </div>
    </SectionContainer>
  );
}
