import SectionContainer from "../layout/SectionContainer";
import SectionHeading from "../layout/SectionHeading";
import VacancyCard from "../cards/VacancyCard";
import { vacancies } from "../data/vacancies";

export default function VacanciesSection() {
  return (
    <SectionContainer id="vacancies">
      <div className="sectionBlock">
        <SectionHeading
          eyebrow="Vacancies"
          title="Current job openings and hiring opportunities"
          description="Job name ke baad company ko proper hiring details dikhani chahiye — type, location, experience, mode, department, required skills aur apply button."
        />

        <div className="grid twoCols">
          {vacancies.map((item) => (
            <VacancyCard key={item.title} item={item} />
          ))}
        </div>
      </div>
    </SectionContainer>
  );
}
