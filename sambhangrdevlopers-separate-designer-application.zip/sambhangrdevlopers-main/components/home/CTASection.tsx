import SectionContainer from "../layout/SectionContainer";
import PrimaryButton from "../layout/PrimaryButton";
import SecondaryButton from "../layout/SecondaryButton";

export default function CTASection() {
  return (
    <SectionContainer>
      <div className="ctaBox ctaPremium premiumHover">
        <div className="ctaGlow" />

        <div className="ctaContent">
          <div className="eyebrow">Let’s Build</div>
          <h2>
            Ready to create a
            <span className="gradientText"> wow-feel digital presence</span>?
          </h2>
          <p>
            Ye homepage premium design language, deep component structure aur
            future-ready expansion ko dhyan me rakhkar build kiya gaya hai. Ab
            isi base par aur advanced pages, animations aur business features
            add kiye ja sakte hain.
          </p>

          <div className="ctaMiniPoints">
            <span>Premium Visual Feel</span>
            <span>Scalable Structure</span>
            <span>Future-Ready Build</span>
          </div>
        </div>

        <div className="ctaActions ctaActionsPremium">
          <PrimaryButton href="#contact">Start Project</PrimaryButton>
          <SecondaryButton href="#portfolio">View Work</SecondaryButton>
        </div>
      </div>
    </SectionContainer>
  );
}
