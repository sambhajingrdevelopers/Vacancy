export type ServicePackage = {
  name: string;
  price: string;
  badge: string;
  description: string;
  bestFor: string;
  features: string[];
};

export type ServiceItem = {
  slug: string;
  icon: string;
  title: string;
  name?: string;
  shortTitle: string;
  category: string;
  priceLabel: string;
  badge: string;
  status?: string;
  href?: string;
  cta?: string;
  desc: string;
  summary: string;
  description: string;
  deepDescription: string[];
  deliverables: string[];
  process: string[];
  features: string[];
  tools: string[];
  support: string[];
};

export const servicePackages: ServicePackage[] = [
  {
    name: "Complete Website Setup",
    price: "₹4,799",
    badge: "Small Business Launch",
    bestFor: "Simple business website, shop, profile, portfolio, service website",
    description:
      "Complete website setup with hosting guidance, domain setup support, responsive design and business enquiry flow.",
    features: [
      "Website setup",
      "Hosting setup guidance",
      "Domain connection support",
      "Contact / WhatsApp enquiry",
      "Basic SEO-ready structure",
      "Business-ready launch support",
    ],
  },
  {
    name: "Advanced Business Website",
    price: "₹7,999",
    badge: "Growing Business",
    bestFor: "Bigger website, more sections, professional business presentation",
    description:
      "For bigger business websites with more pages, stronger UI, service sections, portfolio, enquiry flow and proper business presentation.",
    features: [
      "Advanced website pages",
      "Premium UI sections",
      "Service and portfolio structure",
      "Lead generation flow",
      "Professional launch support",
      "Better business presentation",
    ],
  },
  {
    name: "Smart Web System",
    price: "₹11,999",
    badge: "Payment / AI / Dashboard",
    bestFor: "Payment gateway, AI features, admin panel, dashboard, many functions",
    description:
      "For advanced projects with payment gateway, AI usage, dashboards, automation flow, API integration or business software features.",
    features: [
      "Payment gateway scope",
      "Admin panel / dashboard flow",
      "AI feature integration scope",
      "API and automation planning",
      "Multi-function project structure",
      "Team-guided setup",
    ],
  },
  {
    name: "Custom Project",
    price: "Team Discussion",
    badge: "Final Deal After Requirement",
    bestFor: "Large website, app, custom software, automation, business platform",
    description:
      "For custom software, mobile app, automation, large website or special business requirement. Team will discuss and finalize the deal.",
    features: [
      "Requirement analysis",
      "Custom scope planning",
      "Manual team discussion",
      "Final price decision",
      "Professional guidance",
      "Complete project support",
    ],
  },
];

export const services: ServiceItem[] = [
  {
    slug: "website-development",
    icon: "🌐",
    title: "Website Development",
    name: "Website Development",
    shortTitle: "Website",
    category: "Development",
    priceLabel: "From ₹4,799",
    badge: "Most Popular",
    status: "Live Service",
    href: "/services/website-development",
    cta: "View Details",
    desc: "Professional business websites with responsive UI, WhatsApp enquiry, contact flow and launch support.",
    summary:
      "Professional business websites with responsive UI, contact flow, WhatsApp enquiry, SEO-ready structure and launch support.",
    description:
      "We build clean, modern and business-ready websites that help customers understand your services and contact you quickly.",
    deepDescription: [
      "A website is not only a design page. It should explain your business, build trust, show services clearly and convert visitors into enquiries.",
      "We create hero area, service sections, contact flow, WhatsApp enquiry, portfolio, about section, FAQ and launch-ready structure.",
      "For simple websites, the basic setup is enough. For bigger websites, we plan advanced pages, sections and future growth structure.",
    ],
    deliverables: [
      "Home page",
      "About section",
      "Services section",
      "Portfolio / work section",
      "Contact form",
      "WhatsApp enquiry button",
      "Mobile responsive layout",
      "Hosting/domain setup guidance",
    ],
    process: [
      "Requirement collection",
      "Website structure planning",
      "UI design and content flow",
      "Development setup",
      "Responsive testing",
      "Launch support",
    ],
    features: [
      "Fast loading layout",
      "Modern premium UI",
      "SEO-ready page structure",
      "Lead capture flow",
      "Contact and enquiry setup",
      "Business branding",
    ],
    tools: ["Next.js", "React", "HTML", "CSS", "Tailwind", "Vercel"],
    support: [
      "Domain connection guidance",
      "Hosting setup guidance",
      "Basic update guidance",
      "Launch support",
    ],
  },
  {
    slug: "mobile-app-development",
    icon: "📱",
    title: "Mobile App Development",
    name: "Mobile App Development",
    shortTitle: "Mobile App",
    category: "App Development",
    priceLabel: "Custom Quote",
    badge: "Android / iOS",
    status: "Live Service",
    href: "/services/mobile-app-development",
    cta: "View Details",
    desc: "Mobile app planning and development for booking, e-commerce, education, chat and service platforms.",
    summary:
      "Mobile app planning and development for business, booking, e-commerce, education, chat and service-based platforms.",
    description:
      "We help convert business ideas into app screens, user flows, dashboards and functional app structure.",
    deepDescription: [
      "A mobile app must be easy for users to understand. Every screen should have clear navigation, strong UI and proper action flow.",
      "We plan login, profile, home, categories, product/service details, booking, payment, order/status, notification and admin control.",
      "For large apps, we divide the project into phases so development stays stable and future-ready.",
    ],
    deliverables: [
      "App screen flow",
      "Login/register flow",
      "Home page structure",
      "Profile section",
      "Service/product pages",
      "Admin panel planning",
      "API structure guidance",
      "Future update planning",
    ],
    process: [
      "App idea analysis",
      "User flow planning",
      "Screen structure",
      "Backend/API planning",
      "Development phase planning",
      "Testing and improvement",
    ],
    features: [
      "Mobile-first UI",
      "Secure login flow",
      "Admin control concept",
      "Notification-ready flow",
      "Payment-ready planning",
      "Scalable structure",
    ],
    tools: ["React Native", "Flutter", "Next.js API", "Python", "Firebase"],
    support: [
      "Feature planning",
      "Admin panel planning",
      "Deployment guidance",
      "Future upgrade support",
    ],
  },
  {
    slug: "software-development",
    icon: "💻",
    title: "Software Development",
    name: "Software Development",
    shortTitle: "Software",
    category: "Business Software",
    priceLabel: "Custom Quote",
    badge: "Business Automation",
    status: "Live Service",
    href: "/services/software-development",
    cta: "View Details",
    desc: "Custom software for billing, customers, staff, reports, workflow and business operations.",
    summary:
      "Custom software for business management, billing, customers, staff, reports, workflow and internal operations.",
    description:
      "We design software that helps businesses reduce manual work and manage operations in one system.",
    deepDescription: [
      "Business software should match real daily work. It should not be confusing or overloaded.",
      "We plan dashboard, users, billing, reports, customer records, product/service management and role-based access.",
      "For advanced businesses, we can plan automation, analytics, reminders, reports and integrations.",
    ],
    deliverables: [
      "Dashboard structure",
      "User management",
      "Customer management",
      "Billing / invoice flow",
      "Reports section",
      "Role-based access planning",
      "Data management flow",
      "Admin panel",
    ],
    process: [
      "Business process study",
      "Software module planning",
      "Database planning",
      "Admin/user flow",
      "Development and testing",
      "Deployment support",
    ],
    features: [
      "Role-based access",
      "Reports and analytics",
      "Customer records",
      "Billing flow",
      "Data security planning",
      "Scalable modules",
    ],
    tools: ["Python", "FastAPI", "Next.js", "PostgreSQL", "MongoDB"],
    support: [
      "Module planning",
      "Data flow guidance",
      "Deployment support",
      "Future module support",
    ],
  },
  {
    slug: "ecommerce-development",
    icon: "🛒",
    title: "E-commerce Development",
    name: "E-commerce Development",
    shortTitle: "E-commerce",
    category: "Online Selling",
    priceLabel: "From ₹7,999",
    badge: "Store System",
    status: "Live Service",
    href: "/services/ecommerce-development",
    cta: "View Details",
    desc: "Online store setup with categories, products, cart, checkout and admin product control.",
    summary:
      "Online store setup with categories, products, cart, checkout flow, payment scope and admin product control.",
    description:
      "We build e-commerce experiences where customers can browse products, understand details and place orders easily.",
    deepDescription: [
      "An e-commerce website needs proper product organization, clear pricing, cart flow and trust-building design.",
      "We plan category pages, product listing, product details, cart, checkout, payment, order tracking and admin management.",
      "For advanced stores, payment gateway, stock management, coupons and customer dashboard can also be added.",
    ],
    deliverables: [
      "Home page",
      "Category pages",
      "Product listing",
      "Product detail page",
      "Cart flow",
      "Checkout flow",
      "Payment gateway scope",
      "Admin product management",
    ],
    process: [
      "Product/category planning",
      "Store UI planning",
      "Cart and checkout flow",
      "Payment scope",
      "Admin planning",
      "Launch support",
    ],
    features: [
      "Product cards",
      "Category filters",
      "Cart system",
      "Order enquiry",
      "Payment-ready structure",
      "Admin control",
    ],
    tools: ["Next.js", "React", "Razorpay", "FastAPI", "Database"],
    support: [
      "Product upload guidance",
      "Payment setup guidance",
      "Order flow support",
      "Admin usage guidance",
    ],
  },
  {
    slug: "payment-gateway-integration",
    icon: "💳",
    title: "Payment Gateway Integration",
    name: "Payment Gateway Integration",
    shortTitle: "Payment Gateway",
    category: "Payments",
    priceLabel: "From ₹11,999 project scope",
    badge: "Razorpay / UPI",
    status: "Assisted Service",
    href: "/services/payment-gateway-integration",
    cta: "Get Support",
    desc: "Payment gateway setup for Razorpay, UPI, order creation, verification and webhook flow.",
    summary:
      "Payment gateway setup planning for Razorpay, UPI, order creation, verification, webhook and payment status flow.",
    description:
      "We help add payment flow properly so users can pay and the system can verify payment securely.",
    deepDescription: [
      "Payment integration needs correct order creation, secure verification and proper success/failure handling.",
      "We plan frontend checkout, backend order creation, Razorpay verification, webhook handling and user unlock/payment status.",
      "For business platforms, payment history, invoice and admin payment dashboard can also be planned.",
    ],
    deliverables: [
      "Payment flow planning",
      "Razorpay order route",
      "Payment verification route",
      "Webhook planning",
      "Success/failure UI",
      "Admin payment status",
      "Wallet/unlock logic",
    ],
    process: [
      "Payment requirement check",
      "Razorpay account setup guidance",
      "Backend route planning",
      "Frontend checkout planning",
      "Webhook testing",
      "Final verification",
    ],
    features: [
      "Secure verification",
      "Webhook support",
      "Order status",
      "Payment history",
      "Unlock after payment",
      "Admin tracking",
    ],
    tools: ["Razorpay", "Next.js", "FastAPI", "Python", "Webhook"],
    support: [
      "Razorpay setup guidance",
      "Webhook guidance",
      "Test/live key guidance",
      "Payment issue debugging",
    ],
  },
  {
    slug: "ai-automation",
    icon: "🤖",
    title: "AI Automation",
    name: "AI Automation",
    shortTitle: "AI Automation",
    category: "AI",
    priceLabel: "Custom Quote",
    badge: "Smart Systems",
    status: "Assisted Service",
    href: "/services/ai-automation",
    cta: "Get Support",
    desc: "AI-based chat assistant, project generator, content creation and business workflow automation.",
    summary:
      "AI-based features for chat assistant, project generator, content creation, automation and business workflow support.",
    description:
      "We help add AI features that can guide users, answer questions, generate project ideas and automate business tasks.",
    deepDescription: [
      "AI automation should solve a clear business problem. It can answer users, generate content, plan projects or automate internal work.",
      "We plan AI chat, project generator, template creation, business enquiry assistant, support assistant and dashboard integration.",
      "For bigger AI systems, usage limits, wallet system, model selection and admin monitoring are planned carefully.",
    ],
    deliverables: [
      "AI assistant flow",
      "Prompt structure",
      "Backend AI route",
      "Model planning",
      "Usage control concept",
      "Admin monitoring concept",
      "Wallet/pass logic planning",
    ],
    process: [
      "AI use-case planning",
      "Prompt and flow design",
      "Backend route setup",
      "Frontend chat UI",
      "Testing and tuning",
      "Launch support",
    ],
    features: [
      "AI chat",
      "Project generation",
      "Content generation",
      "Usage limits",
      "Admin controls",
      "Smart automation",
    ],
    tools: ["OpenAI API", "Python", "FastAPI", "Next.js", "Automation"],
    support: [
      "Prompt improvement",
      "Usage monitoring guidance",
      "Model selection guidance",
      "AI feature expansion",
    ],
  },
  {
    slug: "admin-dashboard",
    icon: "📊",
    title: "Admin Dashboard Development",
    name: "Admin Dashboard Development",
    shortTitle: "Admin Dashboard",
    category: "Control Panel",
    priceLabel: "Custom Quote",
    badge: "Management Panel",
    status: "Assisted Service",
    href: "/services/admin-dashboard",
    cta: "Get Support",
    desc: "Admin panels for users, orders, products, enquiries, payments, templates and reports.",
    summary:
      "Admin panels for managing users, orders, products, enquiries, payments, templates, reports and business settings.",
    description:
      "We build admin dashboard structures that help owners control important parts of their digital business.",
    deepDescription: [
      "Admin dashboard is the control center of a project. It should be clear, secure and easy to use.",
      "We plan user list, profile view, orders, payments, product/service management, templates, reports and settings.",
      "For advanced systems, roles, permissions, logs and analytics can also be added.",
    ],
    deliverables: [
      "Admin home dashboard",
      "User management",
      "Enquiry management",
      "Order/payment management",
      "Reports section",
      "Settings panel",
      "Role-based access planning",
    ],
    process: [
      "Admin requirement planning",
      "Module grouping",
      "Role access planning",
      "Dashboard UI",
      "Backend/API planning",
      "Testing",
    ],
    features: [
      "User search",
      "Profile view",
      "Payment status",
      "Reports",
      "Admin roles",
      "Control actions",
    ],
    tools: ["Next.js", "React", "FastAPI", "Database", "Charts"],
    support: [
      "Admin usage guidance",
      "Module planning",
      "Security guidance",
      "Future feature support",
    ],
  },
  {
    slug: "hosting-domain-setup",
    icon: "🚀",
    title: "Hosting & Domain Setup",
    name: "Hosting & Domain Setup",
    shortTitle: "Hosting & Domain",
    category: "Launch Support",
    priceLabel: "Included in offers",
    badge: "Launch Ready",
    status: "Assisted Service",
    href: "/services/hosting-domain-setup",
    cta: "Get Support",
    desc: "Hosting guidance, domain connection, deployment support and final project launch assistance.",
    summary:
      "Hosting guidance, domain connection, deployment support and final project launch assistance.",
    description:
      "We help connect your project with hosting and domain so your website can be used professionally.",
    deepDescription: [
      "A project becomes useful only after proper launch. Hosting, domain, SSL, environment variables and deployment must be handled carefully.",
      "We guide or support domain connection, hosting setup, Vercel deployment, backend hosting, environment setup and final testing.",
      "For bigger projects, server setup, backend deployment and payment gateway live configuration can be handled after requirement discussion.",
    ],
    deliverables: [
      "Hosting setup guidance",
      "Domain connection support",
      "SSL-ready setup",
      "Vercel deployment guidance",
      "Backend hosting scope",
      "Environment variable guidance",
      "Final testing support",
    ],
    process: [
      "Project launch check",
      "Hosting platform selection",
      "Domain DNS setup",
      "Environment setup",
      "Deployment",
      "Final testing",
    ],
    features: [
      "Domain connection",
      "Hosting guidance",
      "Deployment support",
      "SSL support",
      "Environment setup",
      "Launch testing",
    ],
    tools: ["Vercel", "AWS EC2", "Domain DNS", "GitHub", "Environment Variables"],
    support: [
      "Deployment help",
      "Domain setup help",
      "Live testing",
      "Final launch support",
    ],
  },
];

export const liveServices: ServiceItem[] = services.slice(0, 4);

export const assistedServices: ServiceItem[] = services.slice(4, 8);

export const comingSoonServices: ServiceItem[] = [
  {
    slug: "cloud-server-automation",
    icon: "☁️",
    title: "Cloud Server Automation",
    name: "Cloud Server Automation",
    shortTitle: "Cloud Automation",
    category: "Cloud",
    priceLabel: "Team Discussion",
    badge: "Coming Soon",
    status: "Coming Soon",
    href: "/services",
    cta: "Contact Team",
    desc: "Advanced cloud deployment, monitoring and server automation support.",
    summary:
      "Advanced cloud deployment, monitoring and server automation support for future business platforms.",
    description:
      "Advanced cloud deployment, monitoring and server automation support for future business platforms.",
    deepDescription: [
      "Cloud automation helps businesses deploy and manage systems more safely.",
      "This service is planned for server setup, deployment monitoring and infrastructure guidance.",
      "For advanced projects, our team will discuss server requirement before final planning.",
    ],
    deliverables: ["Cloud scope planning", "Deployment guidance", "Server structure"],
    process: ["Requirement check", "Cloud planning", "Deployment guidance"],
    features: ["Cloud planning", "Server setup", "Monitoring flow", "Deployment support"],
    tools: ["AWS", "Vercel", "Docker"],
    support: ["Cloud guidance", "Deployment help", "Server planning"],
  },
  {
    slug: "advanced-crm-system",
    icon: "👥",
    title: "Advanced CRM System",
    name: "Advanced CRM System",
    shortTitle: "CRM System",
    category: "CRM",
    priceLabel: "Custom Quote",
    badge: "Coming Soon",
    status: "Coming Soon",
    href: "/services",
    cta: "Contact Team",
    desc: "Customer management, follow-up tracking, enquiry pipeline and business reporting system.",
    summary:
      "Customer management, follow-up tracking, enquiry pipeline and business reporting system.",
    description:
      "Customer management, follow-up tracking, enquiry pipeline and business reporting system.",
    deepDescription: [
      "CRM helps businesses manage customers and leads in a single system.",
      "It can include enquiry tracking, follow-up reminders, status pipeline and reports.",
      "The final scope depends on business size and daily workflow.",
    ],
    deliverables: ["CRM planning", "Dashboard scope", "Customer records"],
    process: ["Workflow study", "CRM module planning", "Dashboard planning"],
    features: ["Customer tracking", "Follow-up flow", "Reports", "Admin control"],
    tools: ["Next.js", "FastAPI", "Database"],
    support: ["CRM guidance", "Module planning", "Report planning"],
  },
  {
    slug: "business-analytics-dashboard",
    icon: "📈",
    title: "Business Analytics Dashboard",
    name: "Business Analytics Dashboard",
    shortTitle: "Analytics",
    category: "Analytics",
    priceLabel: "Custom Quote",
    badge: "Coming Soon",
    status: "Coming Soon",
    href: "/services",
    cta: "Contact Team",
    desc: "Reports, charts, business insights and owner-side decision support.",
    summary:
      "Reports, charts, business insights, performance tracking and owner-side decision support.",
    description:
      "Reports, charts, business insights, performance tracking and owner-side decision support.",
    deepDescription: [
      "Analytics dashboard helps owners understand business performance clearly.",
      "It can include charts, sales reports, customer reports and performance insights.",
      "For advanced systems, analytics can connect with admin data and payment/order data.",
    ],
    deliverables: ["Analytics planning", "Dashboard design", "Report structure"],
    process: ["Data check", "Report planning", "Dashboard planning"],
    features: ["Charts", "Reports", "Business insights", "Admin analytics"],
    tools: ["React", "Charts", "Database"],
    support: ["Report guidance", "Dashboard support", "Data planning"],
  },
];

export function getServiceBySlug(slug: string) {
  return services.find((service) => service.slug === slug);
}
