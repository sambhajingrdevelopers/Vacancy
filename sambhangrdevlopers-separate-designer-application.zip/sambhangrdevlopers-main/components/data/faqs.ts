export type FAQItem = {
  q: string;
  a: string;
};

export const faqs: FAQItem[] = [
  {
    q: "Kya Sambhajingr Developers sirf websites banata hai?",
    a: "Nahi, website ke saath web apps, mobile apps, custom software, AI automation aur support services bhi include ki gayi hain.",
  },
  {
    q: "Company registration feature ka kya status hai?",
    a: "Ye assisted service bucket me rakha gaya hai taaki visitor ko clearly status samajh aaye.",
  },
  {
    q: "Coming Soon services website par kyun dikhai gayi hain?",
    a: "Future roadmap aur company expansion direction dikhane ke liye.",
  },
  {
    q: "Kya future me aur pages add kiye ja sakte hain?",
    a: "Haan, structure isi tarah design kiya gaya hai ki baad me service detail pages aur blog easily add ho sakein.",
  },
];
