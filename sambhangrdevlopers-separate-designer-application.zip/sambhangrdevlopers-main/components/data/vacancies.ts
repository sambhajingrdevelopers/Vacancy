export type VacancyItem = {
  title: string;
  type: string;
  location: string;
  experience: string;
  mode: string;
  department: string;
  salary: string;
  status: string;
  summary: string;
  skills: string[];
  applyHref?: string;
};

export const designerApplicationUrl =
  process.env.NEXT_PUBLIC_DESIGNER_APPLICATION_URL?.trim() ||
  "/designer-application";

export const vacancies: VacancyItem[] = [
  {
    title: "Creative Designer",
    type: "Full Time / Internship",
    location: "Sambhaji Nagar / Remote",
    experience: "Fresher - 2 Years",
    mode: "Office / Remote Friendly",
    department: "Design Team",
    salary: "Based on Skill & Interview",
    status: "Urgent Hiring",
    summary:
      "We are hiring a creative designer for social media posts, website UI, app screens, banners, branding, and client project visuals.",
    skills: [
      "Canva",
      "Figma",
      "Photoshop",
      "UI Design",
      "Social Media Design",
      "Creative Thinking",
    ],
    applyHref: designerApplicationUrl,
  },
  {
    title: "Frontend Developer",
    type: "Full Time",
    location: "Remote / Hybrid",
    experience: "1-3 Years",
    mode: "Remote Friendly",
    department: "Web Engineering",
    salary: "Competitive Package",
    status: "Open",
    summary:
      "Developer required to build modern UI, responsive pages, and premium frontend experiences.",
    skills: ["React", "Next.js", "TypeScript", "CSS", "UI/UX Sense"],
    applyHref: designerApplicationUrl,
  },
  {
    title: "Backend Developer",
    type: "Full Time",
    location: "Remote / Hybrid",
    experience: "2-4 Years",
    mode: "Remote Friendly",
    department: "Backend Systems",
    salary: "Performance Based",
    status: "Open",
    summary:
      "Role open for designing and maintaining scalable APIs, business logic, and secure backend services.",
    skills: ["Node.js", "API", "Database", "Auth", "Architecture"],
    applyHref: designerApplicationUrl,
  },
  {
    title: "UI/UX Designer",
    type: "Contract / Full Time",
    location: "Remote",
    experience: "0-3 Years",
    mode: "Remote",
    department: "Design",
    salary: "Project / Monthly",
    status: "Open",
    summary:
      "Creative role open for premium visual systems, modern layouts, and product experience design.",
    skills: ["Figma", "UI Design", "UX Flow", "Branding", "Prototyping"],
    applyHref: designerApplicationUrl,
  },
  {
    title: "AI Automation Engineer",
    type: "Special Role",
    location: "Remote",
    experience: "2+ Years",
    mode: "Remote",
    department: "AI Solutions",
    salary: "High Impact Role",
    status: "Coming Soon",
    summary:
      "Future expansion role for automation, smart workflows, and AI-based business tools.",
    skills: ["Python", "Automation", "LLM Tools", "APIs", "Problem Solving"],
    applyHref: designerApplicationUrl,
  },
];
