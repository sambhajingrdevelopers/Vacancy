export type PortfolioItem = {
  title: string;
  category: string;
  problem: string;
  solution: string;
};

export const portfolioItems: PortfolioItem[] = [
  {
    title: "Corporate IT Website",
    category: "Website",
    problem: "Professional online presence aur trust build karna tha.",
    solution:
      "Premium service-led website with strong content flow and enquiry sections.",
  },
  {
    title: "Business Booking Platform",
    category: "Web App",
    problem: "Manual booking aur tracking process slow tha.",
    solution:
      "Custom dashboard with booking workflow, status tracking aur admin control.",
  },
  {
    title: "Service Mobile App",
    category: "Mobile App",
    problem: "Customers ko mobile-based access chahiye tha.",
    solution:
      "Clean app experience with account flow aur service usage support.",
  },
  {
    title: "Inventory Management Tool",
    category: "Software",
    problem: "Stock records aur operations fragmented the.",
    solution:
      "Centralized internal software with better control and visibility.",
  },
  {
    title: "E-commerce Product Site",
    category: "E-commerce",
    problem: "Online sales ke liye modern storefront chahiye tha.",
    solution:
      "Conversion-first shopping flow aur premium product presentation.",
  },
  {
    title: "AI Enquiry Assistant",
    category: "AI Automation",
    problem: "Manual lead response slow tha.",
    solution:
      "Smart response flow aur automated enquiry qualification support.",
  },
];
