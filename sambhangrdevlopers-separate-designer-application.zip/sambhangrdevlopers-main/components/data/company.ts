export const company = {
  name: "Sambhajingr Developers",
  tagline: "Smart IT Solutions for Modern Business",
  email: "sambhajingrdevelopers@gmail.com",
  phone: "+91 9637705868",
  whatsappPhone: "919637705868",
  address: "Sambhaji Nagar",
  mapUrl: "https://maps.app.goo.gl/ikjhpJYXEJVBAtoY6",
  mapEmbedUrl:
    "https://www.google.com/maps?q=Sambhaji%20Nagar%20near%20CIDCO%20Main%20Road%20Jalna&output=embed",
};
