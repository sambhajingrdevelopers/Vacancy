export type TemplateTier =
  | "Free"
  | "Starter"
  | "Premium"
  | "Advanced"
  | "Enterprise";

export type TemplateTierConfig = {
  label: TemplateTier;
  model: string;
  passPriceInr: number;
  zipPriceInr: number;
  badge: string;
  description: string;
};

export type TemplateItem = {
  templateId: string;
  projectId?: string;
  title: string;
  category: TemplateTier;
  planTier?: TemplateTier;
  description: string;
  demoUrl?: string;
  previewUrl?: string;
  downloadUrl?: string;
  frontendPreviewUrl?: string;
  frontendDownloadUrl?: string;
  livePreviewUrl?: string;
  zipPreviewUrl?: string;
  externalPreviewUrl?: string;
  liveProjectUrl?: string;
  hasZip?: boolean;
  stack?: string;
  price?: number;
  zipPriceInr?: number;
  passPriceInr?: number;
  creationPassPriceInr?: number;
  model?: string;
  sellerName?: string;
  tags: string[];
  features?: string[];
  source?: "static" | "generated";
  status?: string;
  marketplaceVisible?: boolean;
  isPrivate?: boolean;
  isOwner?: boolean;
};

export const templateTierConfig: Record<TemplateTier, TemplateTierConfig> = {
  Free: {
    label: "Free",
    model: "gpt-4.1-mini",
    passPriceInr: 0,
    zipPriceInr: 0,
    badge: "Free Source Code",
    description: "Free template with preview and source ZIP download.",
  },
  Starter: {
    label: "Starter",
    model: "gpt-5-mini",
    passPriceInr: 149,
    zipPriceInr: 75,
    badge: "Small Project",
    description: "Simple starter website or app project.",
  },
  Premium: {
    label: "Premium",
    model: "gpt-5.4-mini",
    passPriceInr: 499,
    zipPriceInr: 249,
    badge: "Business Project",
    description: "Professional business website or app project.",
  },
  Advanced: {
    label: "Advanced",
    model: "gpt-5",
    passPriceInr: 1249,
    zipPriceInr: 625,
    badge: "Advanced Project",
    description: "Advanced project with admin, API, booking or payment flow.",
  },
  Enterprise: {
    label: "Enterprise",
    model: "gpt-5.5",
    passPriceInr: 2499,
    zipPriceInr: 1250,
    badge: "Full Suite",
    description: "Large professional project with complete workflow.",
  },
};

export const templates: TemplateItem[] = [];
