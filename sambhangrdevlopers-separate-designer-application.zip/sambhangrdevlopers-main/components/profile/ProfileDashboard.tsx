"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

type UserProfile = {
  userId?: string;
  name?: string;
  email?: string;
  role?: string;
  status?: string;
  createdAt?: string;
  updatedAt?: string;
  lastLoginAt?: string | null;
  profile?: {
    phone?: string;
    company?: string;
    city?: string;
  };
};

type WalletSummary = {
  userId?: string;
  plan?: string;
  tokensTotal?: number;
  tokensUsed?: number;
  tokensRemaining?: number;
  freeProjectsUsed?: number;
  projectsGeneratedCount?: number;
  purchasedProjectsCount?: number;
  purchasedTemplatesCount?: number;
  updatedAt?: string;
};

type MeResponse = {
  success?: boolean;
  user?: UserProfile;
  wallet?: WalletSummary;
  error?: string;
};

async function readJsonSafely(response: Response): Promise<MeResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as MeResponse;
  } catch {
    return {
      success: false,
      error: `Server returned non-JSON: ${text.slice(0, 300)}`,
    };
  }
}

export default function ProfileDashboard() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [wallet, setWallet] = useState<WalletSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [loggingOut, setLoggingOut] = useState(false);
  const [error, setError] = useState("");

  async function loadProfile() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/auth/me", {
        cache: "no-store",
      });

      const data = await readJsonSafely(response);

      if (!response.ok || !data.success || !data.user) {
        throw new Error(data.error || "Login required.");
      }

      setUser(data.user);
      setWallet(data.wallet || null);

      if (typeof window !== "undefined" && data.user.userId) {
        window.localStorage.setItem("sambhajingr_wallet_user_id", data.user.userId);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Profile load failed.");
    } finally {
      setLoading(false);
    }
  }

  async function logout() {
    try {
      setLoggingOut(true);
      await fetch("/api/auth/logout", { method: "POST" });

      if (typeof window !== "undefined") {
        window.localStorage.removeItem("sambhajingr_wallet_user_id");
      }

      window.location.href = "/login";
    } finally {
      setLoggingOut(false);
    }
  }

  useEffect(() => {
    void loadProfile();
  }, []);

  if (loading) {
    return (
      <section className="profileBox">
        <ProfileStyles />
        <h1>Loading Profile...</h1>
        <p>Please wait, tumcha secure profile open hot aahe.</p>
      </section>
    );
  }

  if (error || !user) {
    return (
      <section className="profileBox">
        <ProfileStyles />
        <h1>Login Required</h1>
        <p>{error || "Please login first."}</p>

        <div className="profileActions">
          <Link href="/login" className="profileBtn primary">
            Login
          </Link>
          <Link href="/register" className="profileBtn">
            Register
          </Link>
        </div>
      </section>
    );
  }

  return (
    <section className="profileBox">
      <ProfileStyles />

      <div className="profileTop">
        <div>
          <div className="profileBadge">Secure Profile</div>
          <h1>{user.name || "User Profile"}</h1>
          <p>{user.email}</p>
        </div>

        <button
          type="button"
          className="profileBtn danger"
          disabled={loggingOut}
          onClick={() => void logout()}
        >
          {loggingOut ? "Logging out..." : "Logout"}
        </button>
      </div>

      <div className="profileGrid">
        <div className="profileCard">
          <strong>User ID</strong>
          <span>{user.userId}</span>
        </div>

        <div className="profileCard">
          <strong>Role</strong>
          <span>{user.role || "user"}</span>
        </div>

        <div className="profileCard">
          <strong>Status</strong>
          <span>{user.status || "active"}</span>
        </div>

        <div className="profileCard">
          <strong>Joined</strong>
          <span>{user.createdAt || "-"}</span>
        </div>
      </div>

      <div className="profileSectionTitle">Wallet Summary</div>

      <div className="profileGrid">
        <div className="profileCard">
          <strong>Plan</strong>
          <span>{wallet?.plan || "free"}</span>
        </div>

        <div className="profileCard">
          <strong>Tokens Remaining</strong>
          <span>{(wallet?.tokensRemaining || 0).toLocaleString()}</span>
        </div>

        <div className="profileCard">
          <strong>Tokens Used</strong>
          <span>{(wallet?.tokensUsed || 0).toLocaleString()}</span>
        </div>

        <div className="profileCard">
          <strong>Total Tokens</strong>
          <span>{(wallet?.tokensTotal || 0).toLocaleString()}</span>
        </div>

        <div className="profileCard">
          <strong>Free Projects Used</strong>
          <span>{wallet?.freeProjectsUsed || 0}</span>
        </div>

        <div className="profileCard">
          <strong>Generated Projects</strong>
          <span>{wallet?.projectsGeneratedCount || 0}</span>
        </div>

        <div className="profileCard">
          <strong>Purchased Projects</strong>
          <span>{wallet?.purchasedProjectsCount || 0}</span>
        </div>

        <div className="profileCard">
          <strong>Purchased Templates</strong>
          <span>{wallet?.purchasedTemplatesCount || 0}</span>
        </div>
      </div>

      <div className="profileActions">
        <Link href="/wallet" className="profileBtn primary">
          Open Wallet
        </Link>

        <Link href="/ai" className="profileBtn">
          Generate Project
        </Link>

        <Link href="/templates" className="profileBtn">
          Templates
        </Link>

        <Link href="/" className="profileBtn">
          Home
        </Link>
      </div>
    </section>
  );
}

function ProfileStyles() {
  return (
    <style>{`
      .profileBox {
        width: min(1100px, 100%);
        margin: 0 auto;
        padding: 24px;
        border-radius: 30px;
        background: rgba(255,255,255,0.065);
        border: 1px solid rgba(255,255,255,0.12);
        color: #f8fbff;
        box-shadow: 0 24px 80px rgba(0,0,0,0.30);
      }

      .profileTop {
        display: flex;
        justify-content: space-between;
        align-items: flex-start;
        gap: 18px;
        flex-wrap: wrap;
      }

      .profileBadge {
        display: inline-flex;
        width: fit-content;
        color: #04111f;
        font-weight: 950;
        border-radius: 999px;
        padding: 8px 12px;
        background: linear-gradient(135deg, #67e8f9, #22d3ee);
      }

      .profileBox h1 {
        margin: 14px 0 0;
        font-size: clamp(32px, 5vw, 54px);
        line-height: 1.05;
      }

      .profileBox p {
        margin-top: 10px;
        color: #9fb0c5;
        line-height: 1.7;
        word-break: break-all;
      }

      .profileSectionTitle {
        margin: 28px 0 12px;
        color: #67e8f9;
        font-size: 13px;
        font-weight: 950;
        letter-spacing: 0.12em;
        text-transform: uppercase;
      }

      .profileGrid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(210px, 1fr));
        gap: 14px;
        margin-top: 18px;
      }

      .profileCard {
        padding: 16px;
        border-radius: 20px;
        background: rgba(255,255,255,0.055);
        border: 1px solid rgba(255,255,255,0.10);
      }

      .profileCard strong {
        display: block;
        color: #f8fbff;
        font-size: 14px;
      }

      .profileCard span {
        display: block;
        margin-top: 8px;
        color: #9fb0c5;
        line-height: 1.55;
        word-break: break-all;
      }

      .profileActions {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin-top: 24px;
      }

      .profileBtn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 46px;
        padding: 11px 16px;
        border-radius: 16px;
        text-decoration: none;
        font-weight: 950;
        color: #eafcff;
        background: rgba(255,255,255,0.08);
        border: 1px solid rgba(255,255,255,0.12);
        cursor: pointer;
      }

      .profileBtn.primary {
        color: #04111f;
        border: 0;
        background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
      }

      .profileBtn.danger {
        color: #fecaca;
        background: rgba(239,68,68,0.12);
        border: 1px solid rgba(239,68,68,0.24);
      }

      .profileBtn:disabled {
        opacity: .6;
        cursor: not-allowed;
      }
    `}</style>
  );
}
