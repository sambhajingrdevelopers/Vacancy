"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import {
  TemplateItem,
  templateTierConfig,
  TemplateTier,
} from "@/components/data/templates";

type UserProfile = {
  userId?: string;
  name?: string;
  email?: string;
};

type WalletSummary = {
  userId?: string;
  plan?: string;
  planTier?: string;
  tokensRemaining?: number;
  projectPassesRemaining?: number;
};

type AuthMeResponse = {
  success?: boolean;
  user?: UserProfile;
  wallet?: WalletSummary;
  error?: string;
};

type ApiTemplate = Omit<TemplateItem, "category" | "planTier"> & {
  category?: string;
  planTier?: string;
  frontendPreviewUrl?: string;
  frontendDownloadUrl?: string;
  projectId?: string;
  templateId: string;
  source?: "static" | "generated";
};

type MarketplaceTemplate = ApiTemplate & {
  category: TemplateTier;
  planTier: TemplateTier;
  originalCategory?: string;
  price: number;
  zipPriceInr: number;
  passPriceInr: number;
  model: string;
};

type TemplatesApiResponse = {
  success?: boolean;
  error?: string;
  templates?: ApiTemplate[];
  count?: number;
};

type CreateOrderResponse = {
  success?: boolean;
  alreadyUnlocked?: boolean;
  keyId?: string;
  order?: {
    localOrderId?: string;
    razorpayOrderId?: string;
    amountInr?: number;
    amountPaise?: number;
    currency?: string;
    purpose?: string;
    projectId?: string;
    templateId?: string;
  };
  message?: string;
  error?: string;
  detail?: unknown;
};

type RazorpaySuccessResponse = {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
};

type RazorpayOptions = {
  key: string;
  amount?: number;
  currency?: string;
  name: string;
  description: string;
  order_id?: string;
  handler: (response: RazorpaySuccessResponse) => void;
  theme?: { color?: string };
  modal?: { ondismiss?: () => void };
};

type RazorpayInstance = {
  open: () => void;
};

type RazorpayConstructor = new (options: RazorpayOptions) => RazorpayInstance;

const categories: Array<"All" | TemplateTier> = [
  "All",
  "Free",
  "Starter",
  "Premium",
  "Advanced",
  "Enterprise",
];

function getRazorpayFromWindow() {
  if (typeof window === "undefined") return undefined;
  return (window as unknown as { Razorpay?: RazorpayConstructor }).Razorpay;
}

function isTier(value?: string): value is TemplateTier {
  return (
    value === "Free" ||
    value === "Starter" ||
    value === "Premium" ||
    value === "Advanced" ||
    value === "Enterprise"
  );
}

function normalizeTier(category?: string, planTier?: string): TemplateTier {
  const direct = String(planTier || category || "").trim();

  if (isTier(direct)) return direct;

  const lower = direct.toLowerCase();

  if (lower.includes("free") || lower.includes("student") || lower.includes("trial")) {
    return "Free";
  }

  if (lower.includes("starter") || lower.includes("portfolio")) return "Starter";

  if (
    lower.includes("advanced") ||
    lower.includes("e-commerce") ||
    lower.includes("ecommerce") ||
    lower.includes("commerce") ||
    lower.includes("admin") ||
    lower.includes("payment") ||
    lower.includes("booking") ||
    lower.includes("dashboard")
  ) {
    return "Advanced";
  }

  if (
    lower.includes("enterprise") ||
    lower.includes("large") ||
    lower.includes("suite")
  ) {
    return "Enterprise";
  }

  return "Premium";
}

function getPreviewUrl(item: MarketplaceTemplate) {
  return (
    item.frontendPreviewUrl ||
    item.livePreviewUrl ||
    item.previewUrl ||
    item.demoUrl ||
    ""
  );
}

function getDownloadUrl(item: MarketplaceTemplate) {
  return item.frontendDownloadUrl || item.downloadUrl || "";
}

function withUserId(url: string, userId: string) {
  if (!url) return "";
  if (!userId) return url;

  return `${url}${url.includes("?") ? "&" : "?"}userId=${encodeURIComponent(
    userId
  )}`;
}

function cleanVisibleText(value: string) {
  return String(value || "")
    .replace(/\bAI\s*Generated\b/gi, "Premium")
    .replace(/\bChatGPT\b/gi, "")
    .replace(/\bAutoDev\b/gi, "")
    .replace(/\bGenerated Template\b/gi, "Project Template")
    .replace(/\s+/g, " ")
    .trim();
}

function numberOrFallback(value: unknown, fallback: number) {
  if (typeof value === "number" && Number.isFinite(value) && value >= 0) {
    return value;
  }

  const parsed = Number(value);

  if (Number.isFinite(parsed) && parsed >= 0) {
    return parsed;
  }

  return fallback;
}

function normalizeTemplate(item: ApiTemplate): MarketplaceTemplate {
  const tier = normalizeTier(item.category, item.planTier);
  const config = templateTierConfig[tier];

  const zipPrice = numberOrFallback(
    item.zipPriceInr ?? item.price,
    config.zipPriceInr
  );

  const passPrice = numberOrFallback(
    item.creationPassPriceInr ?? item.passPriceInr,
    config.passPriceInr
  );

  const model = cleanVisibleText(String(item.model || config.model));

  const title =
    cleanVisibleText(item.title) || `${config.label} Project Template`;

  const description =
    cleanVisibleText(item.description) || config.description;

  const tags = Array.isArray(item.tags)
    ? item.tags.map((tag) => cleanVisibleText(tag)).filter(Boolean)
    : [];

  return {
    ...item,
    title,
    description,
    category: tier,
    planTier: tier,
    originalCategory: item.category,
    price: zipPrice,
    zipPriceInr: zipPrice,
    passPriceInr: passPrice,
    model,
    tags: tags.length ? tags : [config.label, config.badge, "Ready Project"],
    features: Array.isArray(item.features)
      ? item.features.map((feature) => cleanVisibleText(feature)).filter(Boolean)
      : ["Free preview", "Responsive layout", "Source files", "ZIP package"],
    sellerName: item.sellerName || "Sambhajingr Developers",
    source: item.source || "generated",
    status: item.status || "published",
  };
}

function getSafeTags(item: MarketplaceTemplate) {
  return Array.isArray(item.tags)
    ? item.tags.map((tag) => cleanVisibleText(tag)).filter(Boolean)
    : [];
}

function getSafeFeatures(item: MarketplaceTemplate) {
  return Array.isArray(item.features)
    ? item.features.map((feature) => cleanVisibleText(feature)).filter(Boolean)
    : [];
}

function getErrorMessage(value: unknown, fallback: string) {
  if (typeof value === "string") return value;

  if (typeof value === "object" && value !== null && "error" in value) {
    const record = value as { error?: unknown };
    if (typeof record.error === "string") return record.error;
  }

  if (typeof value === "object" && value !== null && "detail" in value) {
    const record = value as { detail?: unknown };

    if (typeof record.detail === "string") return record.detail;

    if (
      typeof record.detail === "object" &&
      record.detail !== null &&
      "message" in record.detail
    ) {
      const detail = record.detail as { message?: unknown };
      if (typeof detail.message === "string") return detail.message;
    }
  }

  if (typeof value === "object" && value !== null && "message" in value) {
    const record = value as { message?: unknown };
    if (typeof record.message === "string") return record.message;
  }

  return fallback;
}

function loadRazorpayScript() {
  return new Promise<boolean>((resolve) => {
    if (typeof window === "undefined") {
      resolve(false);
      return;
    }

    if (getRazorpayFromWindow()) {
      resolve(true);
      return;
    }

    const existing = document.querySelector<HTMLScriptElement>(
      'script[src="https://checkout.razorpay.com/v1/checkout.js"]'
    );

    if (existing) {
      existing.onload = () => resolve(true);
      existing.onerror = () => resolve(false);
      return;
    }

    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.async = true;
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

async function readTemplatesJson(
  response: Response
): Promise<TemplatesApiResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as TemplatesApiResponse;
  } catch {
    return {
      success: false,
      error: `Templates API returned non-JSON: ${text.slice(0, 250)}`,
    };
  }
}

async function readOrderJson(response: Response): Promise<CreateOrderResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as CreateOrderResponse;
  } catch {
    return {
      success: false,
      error: `Payment API returned non-JSON: ${text.slice(0, 250)}`,
    };
  }
}

async function readAuthMe(response: Response): Promise<AuthMeResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as AuthMeResponse;
  } catch {
    return {
      success: false,
      error: `Auth API returned non-JSON: ${text.slice(0, 250)}`,
    };
  }
}

export default function TemplateMarketplace() {
  const [generatedTemplates, setGeneratedTemplates] = useState<ApiTemplate[]>(
    []
  );
  const [selectedCategory, setSelectedCategory] = useState<
    "All" | TemplateTier
  >("All");
  const [search, setSearch] = useState("");
  const [loading, setLoading] = useState(true);
  const [authLoading, setAuthLoading] = useState(true);
  const [busyTemplateId, setBusyTemplateId] = useState("");
  const [user, setUser] = useState<UserProfile | null>(null);
  const [wallet, setWallet] = useState<WalletSummary | null>(null);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  const userId = user?.userId || "";

  async function loadAuth() {
    try {
      setAuthLoading(true);
      setError("");

      const response = await fetch("/api/auth/me", {
        cache: "no-store",
      });

      const data = await readAuthMe(response);

      if (!response.ok || !data.success || !data.user?.userId) {
        throw new Error(data.error || "Login required.");
      }

      setUser(data.user);
      setWallet(data.wallet || null);

      if (typeof window !== "undefined") {
        window.localStorage.setItem(
          "sambhajingr_wallet_user_id",
          data.user.userId
        );
      }
    } catch (err) {
      setUser(null);
      setWallet(null);
      setError(err instanceof Error ? err.message : "Login required.");
    } finally {
      setAuthLoading(false);
    }
  }

  async function loadTemplates() {
    try {
      setLoading(true);

      const [generatedResponse, manualResponse] = await Promise.all([
        fetch("/api/templates", {
          cache: "no-store",
        }),
        fetch("/api/manual-templates", {
          cache: "no-store",
        }),
      ]);

      const generatedData = await readTemplatesJson(generatedResponse);
      const manualData = await readTemplatesJson(manualResponse);

      const generatedList =
        generatedResponse.ok &&
        generatedData.success &&
        Array.isArray(generatedData.templates)
          ? generatedData.templates
          : [];

      const manualList =
        manualResponse.ok &&
        manualData.success &&
        Array.isArray(manualData.templates)
          ? manualData.templates
          : [];

      if (!generatedResponse.ok && !manualResponse.ok) {
        throw new Error(
          generatedData.error || manualData.error || "Templates API failed"
        );
      }

      setGeneratedTemplates([...manualList, ...generatedList]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Templates load failed");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadAuth();
    void loadTemplates();
  }, []);

  const allTemplates = useMemo<MarketplaceTemplate[]>(() => {
    const mapped = generatedTemplates
      .filter((item) => item.status !== "draft")
      .filter((item) => item.marketplaceVisible !== false)
      .map((item) =>
        normalizeTemplate({
          ...item,
          source: "generated",
        })
      );

    const byId = new Map<string, MarketplaceTemplate>();

    mapped.forEach((item) => {
      byId.set(item.templateId, item);
    });

    return Array.from(byId.values());
  }, [generatedTemplates]);

  const filteredTemplates = useMemo(() => {
    const q = search.trim().toLowerCase();

    return allTemplates.filter((item) => {
      const categoryOk =
        selectedCategory === "All" || item.category === selectedCategory;

      const text = [
        item.title,
        item.category,
        item.planTier,
        item.model,
        item.stack,
        item.description,
        ...getSafeTags(item),
        ...getSafeFeatures(item),
      ]
        .join(" ")
        .toLowerCase();

      return categoryOk && (!q || text.includes(q));
    });
  }, [allTemplates, selectedCategory, search]);

  const marketplaceStats = useMemo(() => {
    const liveCount = allTemplates.filter((item) => getPreviewUrl(item)).length;
    const zipCount = allTemplates.filter((item) => getDownloadUrl(item)).length;
    const freeCount = allTemplates.filter(
      (item) => item.category === "Free" || Number(item.zipPriceInr || 0) <= 0
    ).length;

    return {
      total: allTemplates.length,
      liveCount,
      zipCount,
      freeCount,
    };
  }, [allTemplates]);

  function requireLogin() {
    if (!userId) {
      setError("Please login first for paid ZIP purchase.");
      return false;
    }

    return true;
  }

  async function verifyZipPayment(response: RazorpaySuccessResponse) {
    if (!requireLogin()) return;

    const verifyResponse = await fetch("/api/project-zip/verify", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        razorpay_order_id: response.razorpay_order_id,
        razorpay_payment_id: response.razorpay_payment_id,
        razorpay_signature: response.razorpay_signature,
      }),
    });

    const text = await verifyResponse.text();

    let data: {
      success?: boolean;
      error?: string;
      detail?: unknown;
      message?: string;
    };

    try {
      data = JSON.parse(text) as {
        success?: boolean;
        error?: string;
        detail?: unknown;
        message?: string;
      };
    } catch {
      throw new Error(`Payment verify returned non-JSON: ${text.slice(0, 250)}`);
    }

    if (!verifyResponse.ok || !data.success) {
      throw new Error(getErrorMessage(data, "Payment verify failed"));
    }

    await loadAuth();
  }

  async function buyZip(template: MarketplaceTemplate) {
    const isStudentFree =
      template.category === "Free" || Number(template.zipPriceInr || 0) <= 0;

    if (isStudentFree) {
      await downloadZip(template);
      return;
    }

    if (!requireLogin()) return;

    if (!template.projectId) {
      setError("Project ID missing for this template.");
      return;
    }

    try {
      setError("");
      setSuccessMessage("");
      setBusyTemplateId(template.templateId);

      const loaded = await loadRazorpayScript();
      const Razorpay = getRazorpayFromWindow();

      if (!loaded || !Razorpay) {
        throw new Error("Razorpay checkout script failed to load.");
      }

      const response = await fetch("/api/project-zip/create-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          projectId: template.projectId,
          templateId: template.templateId,
        }),
      });

      const data = await readOrderJson(response);

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Create ZIP payment order failed");
      }

      if (data.alreadyUnlocked) {
        setSuccessMessage(
          data.message || "ZIP is already unlocked. Click Download ZIP."
        );
        setBusyTemplateId("");
        return;
      }

      if (!data.keyId || !data.order?.razorpayOrderId) {
        throw new Error("Razorpay order details missing.");
      }

      const options: RazorpayOptions = {
        key: data.keyId,
        amount: data.order.amountPaise,
        currency: data.order.currency || "INR",
        name: "Sambhajingr Developers",
        description: `${template.title} ZIP Purchase`,
        order_id: data.order.razorpayOrderId,
        handler: (paymentResponse) => {
          void verifyZipPayment(paymentResponse)
            .then(() => {
              setSuccessMessage(
                "Payment successful. ZIP is unlocked for this account."
              );
            })
            .catch((err: unknown) => {
              setError(
                err instanceof Error ? err.message : "Payment verify failed"
              );
            })
            .finally(() => {
              setBusyTemplateId("");
            });
        },
        theme: {
          color: "#22d3ee",
        },
        modal: {
          ondismiss: () => {
            setBusyTemplateId("");
          },
        },
      };

      const razorpay = new Razorpay(options);
      razorpay.open();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Payment failed");
      setBusyTemplateId("");
    }
  }

  async function downloadZip(template: MarketplaceTemplate) {
    const downloadUrl = getDownloadUrl(template);
    const isStudentFree =
      template.category === "Free" || Number(template.zipPriceInr || 0) <= 0;

    if (!downloadUrl) {
      setError("ZIP URL missing. Please contact the team for this template.");
      return;
    }

    if (!isStudentFree && !requireLogin()) return;

    try {
      setError("");
      setSuccessMessage("");
      setBusyTemplateId(template.templateId);

      const response = await fetch(withUserId(downloadUrl, userId), {
        cache: "no-store",
        headers: userId
          ? {
              "x-user-id": userId,
            }
          : {},
      });

      if (!response.ok) {
        const text = await response.text();

        let parsed: unknown = text;

        try {
          parsed = JSON.parse(text) as unknown;
        } catch {
          parsed = text;
        }

        const message = getErrorMessage(
          parsed,
          `ZIP download failed: ${response.status}`
        );

        if (response.status === 402) {
          setError(
            `${message}\n\nComplete ZIP payment once, then this ZIP will unlock only for your account.`
          );
          return;
        }

        throw new Error(message);
      }

      const blob = await response.blob();

      if (!blob.size) {
        throw new Error("Downloaded ZIP is empty.");
      }

      const objectUrl = window.URL.createObjectURL(blob);
      const link = document.createElement("a");

      link.href = objectUrl;
      link.download = `${template.projectId || template.templateId}.zip`;

      document.body.appendChild(link);
      link.click();
      link.remove();

      window.URL.revokeObjectURL(objectUrl);

      setSuccessMessage(
        isStudentFree
          ? "Free student ZIP download started."
          : "ZIP download started."
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "ZIP download failed");
    } finally {
      setBusyTemplateId("");
    }
  }

  return (
    <section>
      <style>{`
        .templateHero {
          position: relative;
          overflow: hidden;
          border-radius: 34px;
          border: 1px solid rgba(255,255,255,0.10);
          background:
            radial-gradient(circle at 10% 12%, rgba(103,232,249,0.16), transparent 24%),
            radial-gradient(circle at 90% 10%, rgba(192,132,252,0.14), transparent 22%),
            linear-gradient(180deg, rgba(255,255,255,0.075), rgba(255,255,255,0.028));
          box-shadow: 0 24px 80px rgba(0,0,0,0.30);
          padding: 34px 24px;
        }

        .templateHeroGrid {
          position: relative;
          z-index: 1;
          display: grid;
          grid-template-columns: minmax(0, 1.25fr) minmax(280px, 0.75fr);
          gap: 22px;
          align-items: stretch;
        }

        .templateHeroPanel {
          border: 1px solid rgba(255,255,255,0.10);
          background: rgba(15,23,42,0.55);
          border-radius: 26px;
          padding: 18px;
        }

        .templateStatsGrid {
          display: grid;
          grid-template-columns: repeat(2, minmax(0, 1fr));
          gap: 10px;
        }

        .templateStatBox {
          border: 1px solid rgba(255,255,255,0.10);
          background: rgba(255,255,255,0.055);
          border-radius: 20px;
          padding: 15px;
        }

        .templateStatBox strong {
          display: block;
          color: #67e8f9;
          font-size: 28px;
          line-height: 1;
        }

        .templateStatBox span {
          display: block;
          margin-top: 7px;
          color: #b7c2d0;
          font-size: 13px;
          line-height: 1.45;
        }

        .templateFlowList {
          display: grid;
          gap: 10px;
          margin-top: 16px;
        }

        .templateFlowItem {
          display: grid;
          grid-template-columns: 34px 1fr;
          gap: 10px;
          align-items: start;
          color: #b7c2d0;
          line-height: 1.55;
        }

        .templateFlowItem b {
          display: grid;
          place-items: center;
          width: 34px;
          height: 34px;
          border-radius: 12px;
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee);
          font-size: 13px;
        }

        .templateTools {
          display: grid;
          grid-template-columns: minmax(0, 1fr) auto;
          gap: 12px;
          margin-top: 22px;
          align-items: center;
        }

        .templateSearch {
          width: 100%;
          border: 1px solid rgba(255,255,255,0.12);
          background: rgba(255,255,255,0.06);
          color: white;
          border-radius: 18px;
          padding: 14px 16px;
          outline: none;
        }

        .templateSearch::placeholder {
          color: rgba(255,255,255,0.48);
        }

        .templateGrid {
          margin-top: 28px;
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 18px;
        }

        .templateCard {
          display: flex;
          flex-direction: column;
          gap: 14px;
          min-height: 420px;
        }

        .templateTagRow {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
        }

        .templateTag,
        .templateCategoryBtn {
          border: 1px solid rgba(255,255,255,0.10);
          background: rgba(255,255,255,0.06);
          color: #dffbff;
          border-radius: 999px;
          padding: 7px 10px;
          font-size: 12px;
          font-weight: 800;
        }

        .templateCategoryBtn {
          cursor: pointer;
        }

        .templateActions {
          margin-top: auto;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
        }

        .templateFull {
          grid-column: 1 / -1;
        }

        .templateBtn {
          display: inline-flex;
          justify-content: center;
          align-items: center;
          min-height: 44px;
          padding: 10px 12px;
          border-radius: 14px;
          text-decoration: none;
          font-weight: 900;
          border: 1px solid rgba(255,255,255,0.12);
          color: #eafcff;
          background: rgba(255,255,255,0.07);
          cursor: pointer;
        }

        .templateBtn:disabled {
          opacity: .55;
          cursor: not-allowed;
        }

        .templateBtnPrimary {
          color: #04111f;
          border: 0;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        }

        .templateBtnBuy {
          color: #04111f;
          border: 0;
          background: linear-gradient(135deg, #fbbf24, #fb7185);
        }

        .templateBtnFree {
          color: #04111f;
          border: 0;
          background: linear-gradient(135deg, #22c55e, #67e8f9);
        }

        .templateStatus {
          display: inline-flex;
          align-items: center;
          width: fit-content;
          border-radius: 999px;
          padding: 7px 10px;
          font-size: 12px;
          font-weight: 900;
          color: #67e8f9;
          background: rgba(34,211,238,0.10);
          border: 1px solid rgba(34,211,238,0.18);
        }

        .templateUser {
          margin-top: 18px;
          padding: 13px;
          border-radius: 18px;
          color: #b7c2d0;
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.09);
          font-size: 13px;
          line-height: 1.6;
          word-break: break-all;
        }

        .templateError,
        .templateSuccess {
          margin-top: 16px;
          padding: 14px;
          border-radius: 16px;
          line-height: 1.6;
          white-space: pre-wrap;
        }

        .templateError {
          color: #fecaca;
          background: rgba(239,68,68,0.12);
          border: 1px solid rgba(239,68,68,0.24);
        }

        .templateSuccess {
          color: #bbf7d0;
          background: rgba(34,197,94,0.12);
          border: 1px solid rgba(34,197,94,0.22);
        }

        .templateEmpty {
          margin-top: 24px;
          padding: 22px;
          border-radius: 22px;
          color: #b7c2d0;
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.10);
          line-height: 1.7;
        }

        @media (max-width: 860px) {
          .templateHeroGrid {
            grid-template-columns: 1fr;
          }
        }

        @media (max-width: 700px) {
          .templateTools,
          .templateActions {
            grid-template-columns: 1fr;
          }

          .templateHero {
            padding: 28px 18px;
          }

          .templateStatsGrid {
            grid-template-columns: 1fr 1fr;
          }
        }
      `}</style>

      <div className="templateHero">
        <div className="templateHeroGrid">
          <div>
            <div className="eyebrow">Dynamic Template Marketplace</div>

            <h1
              style={{
                margin: "10px 0 0",
                fontSize: "clamp(32px, 5vw, 58px)",
                lineHeight: 1.05,
                letterSpacing: "-0.03em",
                maxWidth: 980,
              }}
            >
              Ready projects with live preview, secure ZIP and student free template
            </h1>

            <p
              style={{
                margin: "16px 0 0",
                color: "#b7c2d0",
                lineHeight: 1.85,
                maxWidth: 860,
              }}
            >
              Free category is for students and includes free preview plus free ZIP download.
              Paid categories stay payment locked and work as before.
            </p>

            <div
              style={{
                display: "flex",
                flexWrap: "wrap",
                gap: 12,
                marginTop: 24,
              }}
            >
              <Link href="/ai" className="primaryBtn">
                Create New Project
              </Link>

              <Link href="/wallet" className="secondaryBtn">
                Open Wallet
              </Link>

              <Link href="/admin/templates" className="secondaryBtn">
                Admin Upload Template
              </Link>
            </div>

            <div className="templateUser">
              {authLoading ? (
                <>Checking login...</>
              ) : user ? (
                <>
                  Logged in:{" "}
                  <strong style={{ color: "#67e8f9" }}>
                    {user.name || user.email}
                  </strong>
                  <br />
                  Wallet:{" "}
                  <strong style={{ color: "#67e8f9" }}>
                    {(wallet?.tokensRemaining || 0).toLocaleString()} credits
                  </strong>{" "}
                  • Plan:{" "}
                  <strong>{wallet?.planTier || wallet?.plan || "free"}</strong>
                </>
              ) : (
                <>
                  Login is required for paid ZIP purchase. Student free ZIP can be downloaded directly.
                  <br />
                  <Link
                    href="/login"
                    style={{ color: "#67e8f9", fontWeight: 900 }}
                  >
                    Login
                  </Link>{" "}
                  /{" "}
                  <Link
                    href="/register"
                    style={{ color: "#67e8f9", fontWeight: 900 }}
                  >
                    Register
                  </Link>
                </>
              )}
            </div>
          </div>

          <aside className="templateHeroPanel">
            <div className="templateStatsGrid">
              <div className="templateStatBox">
                <strong>{marketplaceStats.total}</strong>
                <span>Total projects</span>
              </div>

              <div className="templateStatBox">
                <strong>{marketplaceStats.liveCount}</strong>
                <span>Live previews</span>
              </div>

              <div className="templateStatBox">
                <strong>{marketplaceStats.zipCount}</strong>
                <span>ZIP packages</span>
              </div>

              <div className="templateStatBox">
                <strong>{marketplaceStats.freeCount}</strong>
                <span>Student free</span>
              </div>
            </div>

            <div className="templateFlowList">
              <div className="templateFlowItem">
                <b>1</b>
                <span>Open free preview and check the full project.</span>
              </div>

              <div className="templateFlowItem">
                <b>2</b>
                <span>Free category gives student ZIP without payment.</span>
              </div>

              <div className="templateFlowItem">
                <b>3</b>
                <span>Paid ZIP unlocks only after payment.</span>
              </div>

              <div className="templateFlowItem">
                <b>4</b>
                <span>For hosting/domain setup, contact the team.</span>
              </div>
            </div>
          </aside>
        </div>
      </div>

      <div className="templateTools">
        <input
          className="templateSearch"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search by template, model, tier, stack..."
        />

        <button
          type="button"
          className="secondaryBtn"
          onClick={() => {
            void loadAuth();
            void loadTemplates();
          }}
        >
          {loading ? "Loading..." : "Refresh"}
        </button>
      </div>

      <div className="templateTagRow" style={{ marginTop: 16 }}>
        {categories.map((category) => {
          const active = selectedCategory === category;

          return (
            <button
              key={category}
              type="button"
              className="templateCategoryBtn"
              onClick={() => setSelectedCategory(category)}
              style={{
                color: active ? "#04111f" : "#dffbff",
                background: active
                  ? "linear-gradient(135deg, #67e8f9, #22d3ee)"
                  : "rgba(255,255,255,0.06)",
              }}
            >
              {category}
            </button>
          );
        })}
      </div>

      {error ? <div className="templateError">{error}</div> : null}

      {successMessage ? (
        <div className="templateSuccess">{successMessage}</div>
      ) : null}

      {!loading && !filteredTemplates.length ? (
        <div className="templateEmpty">
          No templates found. Admin can upload templates from{" "}
          <Link href="/admin/templates" style={{ color: "#67e8f9" }}>
            Admin Template Upload
          </Link>
          .
        </div>
      ) : null}

      <div className="templateGrid">
        {filteredTemplates.map((template) => {
          const previewUrl = getPreviewUrl(template);
          const downloadUrl = getDownloadUrl(template);
          const tags = getSafeTags(template);
          const features = getSafeFeatures(template);
          const isBusy = busyTemplateId === template.templateId;
          const isStudentFree =
            template.category === "Free" || Number(template.zipPriceInr || 0) <= 0;

          return (
            <article
              key={template.templateId}
              className="card premiumHover templateCard"
            >
              <div>
                <div className="eyebrow">
                  {isStudentFree ? "Student Free Template" : `${template.category} Project`}
                </div>

                <h2
                  style={{
                    margin: "8px 0 0",
                    fontSize: 25,
                    lineHeight: 1.15,
                  }}
                >
                  {template.title}
                </h2>

                <p
                  style={{
                    marginTop: 12,
                    color: "#b7c2d0",
                    lineHeight: 1.75,
                  }}
                >
                  {template.description}
                </p>
              </div>

              <div className="templateTagRow">
                <span className="templateTag">{template.stack || "Auto"}</span>
                <span className="templateTag">Model: {template.model}</span>
                <span className="templateTag">
                  {previewUrl ? "Preview available" : "Preview on request"}
                </span>
                <span className="templateTag">
                  {downloadUrl
                    ? isStudentFree
                      ? "Free student ZIP"
                      : "ZIP available"
                    : "ZIP on request"}
                </span>
              </div>

              <span className="templateStatus">
                {isStudentFree
                  ? "Free preview • Free student ZIP"
                  : "Free preview • Account secured • Payment unlock"}
              </span>

              {features.length ? (
                <ul
                  style={{
                    color: "#b7c2d0",
                    lineHeight: 1.8,
                    paddingLeft: 18,
                  }}
                >
                  {features.slice(0, 4).map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
              ) : null}

              {tags.length ? (
                <div className="templateTagRow">
                  {tags.slice(0, 5).map((tag) => (
                    <span className="templateTag" key={tag}>
                      {tag}
                    </span>
                  ))}
                </div>
              ) : null}

              <div className="templateActions">
                {previewUrl ? (
                  <a
                    className="templateBtn templateBtnPrimary"
                    href={withUserId(previewUrl, userId)}
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    Free Preview
                  </a>
                ) : (
                  <Link className="templateBtn templateBtnPrimary" href="/#contact">
                    Enquiry
                  </Link>
                )}

                {downloadUrl ? (
                  <button
                    type="button"
                    className={isStudentFree ? "templateBtn templateBtnFree" : "templateBtn"}
                    disabled={isBusy}
                    onClick={() => void downloadZip(template)}
                  >
                    {isBusy
                      ? "Preparing..."
                      : isStudentFree
                        ? "Free Student ZIP"
                        : "Download ZIP"}
                  </button>
                ) : (
                  <Link className="templateBtn" href="/#contact">
                    Details
                  </Link>
                )}

                {!isStudentFree && template.projectId ? (
                  <button
                    type="button"
                    className="templateBtn templateBtnBuy templateFull"
                    disabled={isBusy}
                    onClick={() => void buyZip(template)}
                  >
                    {isBusy
                      ? "Opening Payment..."
                      : `Buy ZIP • ₹${template.zipPriceInr.toLocaleString("en-IN")}`}
                  </button>
                ) : null}
              </div>
            </article>
          );
        })}
      </div>
    </section>
  );
}
