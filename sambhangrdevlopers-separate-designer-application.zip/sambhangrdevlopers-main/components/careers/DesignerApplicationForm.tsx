"use client";

import { FormEvent, useState } from "react";
import { company } from "../data/company";

type ApplicationFormState = {
  name: string;
  phone: string;
  email: string;
  city: string;
  role: string;
  experience: string;
  workMode: string;
  tools: string;
  portfolio: string;
  expectedSalary: string;
  availability: string;
  message: string;
};

const initialState: ApplicationFormState = {
  name: "",
  phone: "",
  email: "",
  city: "",
  role: "Creative Designer",
  experience: "",
  workMode: "",
  tools: "",
  portfolio: "",
  expectedSalary: "",
  availability: "",
  message: "",
};

const roleOptions = [
  "Creative Designer",
  "UI/UX Designer",
  "Social Media Designer",
  "Graphic Designer Intern",
  "Frontend Developer",
  "Backend Developer",
  "AI Automation Engineer",
];

export default function DesignerApplicationForm() {
  const [form, setForm] = useState<ApplicationFormState>(initialState);
  const [status, setStatus] = useState("");

  function updateField(key: keyof ApplicationFormState, value: string) {
    setForm((current) => ({
      ...current,
      [key]: value,
    }));
  }

  function buildApplicationText() {
    return [
      "New Job Application - Sambhajingr Developers",
      "",
      `Applied Role: ${form.role}`,
      `Name: ${form.name}`,
      `Phone: ${form.phone}`,
      `Email: ${form.email || "Not provided"}`,
      `City: ${form.city || "Not provided"}`,
      `Experience: ${form.experience || "Not provided"}`,
      `Preferred Work Mode: ${form.workMode || "Not selected"}`,
      `Design Tools / Skills: ${form.tools || "Not provided"}`,
      `Portfolio Link: ${form.portfolio || "Not provided"}`,
      `Expected Salary: ${form.expectedSalary || "Not provided"}`,
      `Joining Availability: ${form.availability || "Not provided"}`,
      "",
      "Candidate Message:",
      form.message || "Not provided",
    ].join("\n");
  }

  function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!form.name.trim() || !form.phone.trim() || !form.role.trim()) {
      setStatus("Please add candidate name, phone number, and applied role.");
      return;
    }

    const whatsappUrl = `https://wa.me/${
      company.whatsappPhone
    }?text=${encodeURIComponent(buildApplicationText())}`;

    window.open(whatsappUrl, "_blank", "noopener,noreferrer");
    setStatus("Application message opened on WhatsApp. Send it to submit the application.");
  }

  const emailHref = `mailto:${company.email}?subject=${encodeURIComponent(
    `Job Application - ${form.role || "Designer"}`
  )}&body=${encodeURIComponent(buildApplicationText())}`;

  return (
    <div id="application-form" className="applicationLayout">
      <div className="card requirementPanel premiumHover">
        <div className="eyebrow">Designer Requirement</div>
        <h3>Creative Designer Vacancy</h3>
        <p>
          Sambhajingr Developers is looking for a creative designer who can create
          premium website UI, mobile app screens, social media posts, banners,
          brand visuals, and client-ready presentation designs.
        </p>

        <div className="requirementList">
          <div>
            <span>Role</span>
            <strong>Creative Designer / UI Designer</strong>
          </div>
          <div>
            <span>Experience</span>
            <strong>Fresher to 2 Years</strong>
          </div>
          <div>
            <span>Tools</span>
            <strong>Canva, Figma, Photoshop, Illustrator</strong>
          </div>
          <div>
            <span>Work</span>
            <strong>Posts, banners, UI screens, branding</strong>
          </div>
        </div>

        <div className="designerNotice">
          Candidate must share sample work or portfolio link. Selection will be
          based on creativity, finishing quality, speed, and learning attitude.
        </div>
      </div>

      <div className="card formCard premiumHover contactFormCard applicationFormCard">
        <div className="contactCardHeader">
          <div>
            <div className="eyebrow">Apply Form</div>
            <h3>Designer application form</h3>
          </div>
          <span className="contactLiveBadge">Hiring Open</span>
        </div>

        <p className="muted">
          Fill candidate details. This separate form page will create a ready WhatsApp message
          for HR with all application details.
        </p>

        {status ? <div className="contactStatus">{status}</div> : null}

        <form className="formGrid" onSubmit={submitForm}>
          <input
            value={form.name}
            onChange={(event) => updateField("name", event.target.value)}
            placeholder="Candidate Full Name *"
          />

          <input
            value={form.phone}
            onChange={(event) => updateField("phone", event.target.value)}
            placeholder="Phone / WhatsApp Number *"
            type="tel"
          />

          <input
            value={form.email}
            onChange={(event) => updateField("email", event.target.value)}
            placeholder="Email Address"
            type="email"
          />

          <input
            value={form.city}
            onChange={(event) => updateField("city", event.target.value)}
            placeholder="City / Location"
          />

          <select
            value={form.role}
            onChange={(event) => updateField("role", event.target.value)}
          >
            {roleOptions.map((role) => (
              <option key={role} value={role}>
                {role}
              </option>
            ))}
          </select>

          <select
            value={form.experience}
            onChange={(event) => updateField("experience", event.target.value)}
          >
            <option value="">Select Experience</option>
            <option value="Fresher">Fresher</option>
            <option value="0-6 Months">0-6 Months</option>
            <option value="6 Months - 1 Year">6 Months - 1 Year</option>
            <option value="1-2 Years">1-2 Years</option>
            <option value="2+ Years">2+ Years</option>
          </select>

          <select
            value={form.workMode}
            onChange={(event) => updateField("workMode", event.target.value)}
          >
            <option value="">Preferred Work Mode</option>
            <option value="Office">Office</option>
            <option value="Remote">Remote</option>
            <option value="Hybrid">Hybrid</option>
            <option value="Internship">Internship</option>
          </select>

          <input
            value={form.tools}
            onChange={(event) => updateField("tools", event.target.value)}
            placeholder="Tools / Skills: Canva, Figma, Photoshop..."
          />

          <input
            value={form.portfolio}
            onChange={(event) => updateField("portfolio", event.target.value)}
            placeholder="Portfolio / Instagram / Behance Link"
          />

          <input
            value={form.expectedSalary}
            onChange={(event) => updateField("expectedSalary", event.target.value)}
            placeholder="Expected Salary / Stipend"
          />

          <input
            value={form.availability}
            onChange={(event) => updateField("availability", event.target.value)}
            placeholder="Joining Availability"
          />

          <textarea
            value={form.message}
            onChange={(event) => updateField("message", event.target.value)}
            placeholder="Why should we hire you? Add design strengths or sample project details."
            rows={6}
          />

          <button className="primaryBtn fullBtn" type="submit">
            Send Application on WhatsApp
          </button>

          <a className="secondaryBtn fullBtn contactMailBtn" href={emailHref}>
            Send Application by Email
          </a>
        </form>
      </div>
    </div>
  );
}
