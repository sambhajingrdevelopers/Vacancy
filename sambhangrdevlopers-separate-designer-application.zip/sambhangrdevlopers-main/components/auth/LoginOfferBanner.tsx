"use client";

import { useState } from "react";

const companyPhone = "919637705868";
const companyEmail = "sambhajingrdevelopers@gmail.com";

export default function LoginOfferBanner() {
  const [hidden, setHidden] = useState(false);

  if (hidden) return null;

  const whatsappMessage = [
    "Hello Sambhajingr Developers,",
    "",
    "I am interested in your ₹4,999 complete website offer.",
    "Please share details.",
  ].join("\n");

  const whatsappUrl = `https://wa.me/${companyPhone}?text=${encodeURIComponent(
    whatsappMessage
  )}`;

  const emailUrl = `mailto:${companyEmail}?subject=${encodeURIComponent(
    "₹4,999 Complete Website Offer"
  )}&body=${encodeURIComponent(whatsappMessage)}`;

  return (
    <div className="loginOfferWrap">
      <style>{`
        .loginOfferWrap {
          position: fixed;
          left: 12px;
          right: 12px;
          top: 76px;
          z-index: 999;
          animation: loginOfferSlide 0.75s ease both;
        }

        .loginOfferCard {
          max-width: 680px;
          margin: 0 auto;
          position: relative;
          overflow: hidden;
          border-radius: 22px;
          padding: 14px;
          background:
            radial-gradient(circle at 12% 20%, rgba(103,232,249,0.20), transparent 28%),
            radial-gradient(circle at 92% 10%, rgba(251,191,36,0.18), transparent 26%),
            linear-gradient(135deg, rgba(15,23,42,0.96), rgba(30,41,59,0.92));
          border: 1px solid rgba(103,232,249,0.25);
          box-shadow: 0 22px 70px rgba(0,0,0,0.35);
          backdrop-filter: blur(16px);
        }

        .loginOfferTop {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          gap: 12px;
        }

        .loginOfferBadge {
          display: inline-flex;
          width: fit-content;
          padding: 7px 10px;
          border-radius: 999px;
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
          font-size: 11px;
          font-weight: 950;
          letter-spacing: .06em;
          text-transform: uppercase;
        }

        .loginOfferTitle {
          margin: 8px 0 0;
          color: #f8fbff;
          font-size: clamp(18px, 4vw, 26px);
          line-height: 1.15;
          font-weight: 950;
          letter-spacing: -0.02em;
        }

        .loginOfferTitle span {
          color: #67e8f9;
        }

        .loginOfferText {
          margin: 8px 0 0;
          color: #b7c2d0;
          line-height: 1.55;
          font-size: 14px;
        }

        .loginOfferActions {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 10px;
          margin-top: 12px;
        }

        .loginOfferBtn {
          min-height: 42px;
          border-radius: 14px;
          display: inline-flex;
          justify-content: center;
          align-items: center;
          text-decoration: none;
          font-weight: 950;
          font-size: 14px;
          border: 1px solid rgba(255,255,255,0.12);
        }

        .loginOfferBtnPrimary {
          color: #04111f;
          background: linear-gradient(135deg, #22c55e, #67e8f9);
        }

        .loginOfferBtnSecondary {
          color: #eafcff;
          background: rgba(255,255,255,0.08);
        }

        .loginOfferClose {
          width: 34px;
          height: 34px;
          border-radius: 999px;
          border: 1px solid rgba(255,255,255,0.12);
          color: #eafcff;
          background: rgba(255,255,255,0.08);
          cursor: pointer;
          font-weight: 950;
          flex: 0 0 auto;
        }

        @keyframes loginOfferSlide {
          from {
            opacity: 0;
            transform: translateY(-22px) scale(.98);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }

        @media (max-width: 520px) {
          .loginOfferWrap {
            top: 64px;
            left: 10px;
            right: 10px;
          }

          .loginOfferActions {
            grid-template-columns: 1fr;
          }

          .loginOfferCard {
            border-radius: 18px;
          }
        }
      `}</style>

      <div className="loginOfferCard">
        <div className="loginOfferTop">
          <div>
            <div className="loginOfferBadge">Limited Website Offer</div>

            <h2 className="loginOfferTitle">
              Complete website only <span>₹4,999</span>
            </h2>

            <p className="loginOfferText">
              Sambhajingr Developers will create a professional business website
              with responsive design, contact section, WhatsApp enquiry and
              basic SEO setup.
            </p>
          </div>

          <button
            type="button"
            className="loginOfferClose"
            onClick={() => setHidden(true)}
            aria-label="Close offer"
          >
            ×
          </button>
        </div>

        <div className="loginOfferActions">
          <a
            className="loginOfferBtn loginOfferBtnPrimary"
            href={whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
          >
            WhatsApp Now
          </a>

          <a className="loginOfferBtn loginOfferBtnSecondary" href={emailUrl}>
            Email Enquiry
          </a>
        </div>
      </div>
    </div>
  );
}
