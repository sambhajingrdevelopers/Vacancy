"use client";

import { FormEvent, useState } from "react";

type AuthResponse = {
  success?: boolean;
  error?: string;
  message?: string;
  detail?: string;
  token?: string;
  user?: {
    userId?: string;
    name?: string;
    email?: string;
  };
  wallet?: unknown;
};

async function readJsonSafely(response: Response): Promise<AuthResponse> {
  const text = await response.text();

  if (!text.trim()) {
    return {
      success: false,
      error: `Empty server response. Status: ${response.status}`,
    };
  }

  try {
    return JSON.parse(text) as AuthResponse;
  } catch {
    return {
      success: false,
      error: `Server returned non-JSON. Status: ${response.status}. Response: ${text.slice(
        0,
        500
      )}`,
    };
  }
}

function getErrorMessage(data: AuthResponse, fallback: string) {
  return data.error || data.detail || data.message || fallback;
}

export default function LoginForm() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!email.trim() || !password.trim()) {
      setError("Email and password are required.");
      return;
    }

    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email.trim().toLowerCase(),
          password,
        }),
      });

      const data = await readJsonSafely(response);

      if (!response.ok || !data.success) {
        throw new Error(getErrorMessage(data, "Login failed."));
      }

      if (typeof window !== "undefined" && data.user?.userId) {
        window.localStorage.setItem(
          "sambhajingr_wallet_user_id",
          data.user.userId
        );
      }

      window.location.href = "/profile";
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <section className="authBox">
      <style>{`
        .authBox {
          position: relative;
          z-index: 50;
          width: min(520px, 100%);
          margin: 0 auto;
          padding: 24px;
          border-radius: 28px;
          background: rgba(255,255,255,0.065);
          border: 1px solid rgba(255,255,255,0.12);
          color: #f8fbff;
          box-shadow: 0 24px 80px rgba(0,0,0,0.30);
        }

        .authBox h1 {
          margin: 0;
          font-size: 34px;
          line-height: 1.1;
        }

        .authBox p {
          color: #9fb0c5;
          line-height: 1.7;
        }

        .authForm {
          display: grid;
          gap: 14px;
          margin-top: 20px;
        }

        .authInput {
          width: 100%;
          border: 1px solid rgba(255,255,255,0.12);
          background: rgba(255,255,255,0.07);
          color: white;
          border-radius: 16px;
          padding: 14px 15px;
          outline: none;
        }

        .authInput::placeholder {
          color: #7f91a8;
        }

        .authBtn {
          min-height: 50px;
          border: 0;
          border-radius: 16px;
          cursor: pointer;
          font-weight: 950;
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        }

        .authBtn:disabled {
          opacity: .55;
          cursor: not-allowed;
        }

        .authError {
          margin-top: 14px;
          padding: 12px;
          border-radius: 14px;
          color: #fecaca;
          background: rgba(239,68,68,0.12);
          border: 1px solid rgba(239,68,68,0.24);
          line-height: 1.55;
          white-space: pre-wrap;
          word-break: break-word;
        }

        .registerLink {
          display: inline-flex;
          margin-top: 16px;
          color: #67e8f9;
          font-size: 16px;
          font-weight: 900;
          text-decoration: none;
          cursor: pointer;
          position: relative;
          z-index: 99999;
          pointer-events: auto;
          touch-action: manipulation;
        }

        .registerLink:hover {
          text-decoration: underline;
        }
      `}</style>

      <h1>Login</h1>
      <p>Login to securely access your profile, wallet, and AI project history.</p>

      {error ? <div className="authError">{error}</div> : null}

      <form className="authForm" onSubmit={handleSubmit}>
        <input
          className="authInput"
          value={email}
          onChange={(event) => setEmail(event.target.value)}
          placeholder="Email address"
          type="email"
          autoComplete="email"
        />

        <input
          className="authInput"
          value={password}
          onChange={(event) => setPassword(event.target.value)}
          placeholder="Password"
          type="password"
          autoComplete="current-password"
        />

        <button className="authBtn" type="submit" disabled={loading}>
          {loading ? "Logging in..." : "Login"}
        </button>
      </form>

      <a className="registerLink" href="/register">
        New user? Create an account
      </a>
    </section>
  );
}
