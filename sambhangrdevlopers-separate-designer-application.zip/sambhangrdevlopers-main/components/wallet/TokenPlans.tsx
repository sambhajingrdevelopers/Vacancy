"use client";

import { useState } from "react";

type ProjectPassPackage = {
  packageId: "starter" | "premium" | "advanced" | "enterprise";
  title: string;
  price: number;
  credits: number;
  messages: number;
  projects: number;
  model: string;
  zipResalePrice: number;
  bestFor: string;
};

type RazorpayOrder = {
  razorpayOrderId?: string;
  amountPaise?: number;
  currency?: string;
  title?: string;
  purpose?: string;
  credits?: number;
  tokens?: number;
  packageId?: string;
};

type CreateOrderResponse = {
  success?: boolean;
  keyId?: string;
  order?: RazorpayOrder;
  error?: string;
  detail?: unknown;
};

type VerifyPaymentResponse = {
  success?: boolean;
  error?: string;
  detail?: unknown;
};

type RazorpaySuccessResponse = {
  razorpay_order_id: string;
  razorpay_payment_id: string;
  razorpay_signature: string;
};

type RazorpayOptions = {
  key: string;
  amount?: number;
  currency?: string;
  name: string;
  description: string;
  order_id?: string;
  handler: (response: RazorpaySuccessResponse) => void;
  prefill?: {
    name?: string;
    email?: string;
    contact?: string;
  };
  theme?: {
    color?: string;
  };
  modal?: {
    ondismiss?: () => void;
  };
};

type RazorpayInstance = {
  open: () => void;
};

type RazorpayConstructor = new (options: RazorpayOptions) => RazorpayInstance;

const packages: ProjectPassPackage[] = [
  {
    packageId: "starter",
    title: "Starter Project Pass",
    price: 149,
    credits: 10000,
    messages: 5,
    projects: 1,
    model: "gpt-5-mini",
    zipResalePrice: 75,
    bestFor: "Small website/app + preview + creator ZIP",
  },
  {
    packageId: "premium",
    title: "Premium Project Pass",
    price: 499,
    credits: 25000,
    messages: 5,
    projects: 1,
    model: "gpt-5.4-mini",
    zipResalePrice: 249,
    bestFor: "Business website/app + preview + creator ZIP",
  },
  {
    packageId: "advanced",
    title: "Advanced Project Pass",
    price: 1249,
    credits: 60000,
    messages: 5,
    projects: 1,
    model: "gpt-5",
    zipResalePrice: 625,
    bestFor: "Admin / full-stack / payment project + preview + creator ZIP",
  },
  {
    packageId: "enterprise",
    title: "Enterprise Project Pass",
    price: 2499,
    credits: 120000,
    messages: 5,
    projects: 1,
    model: "gpt-5.5",
    zipResalePrice: 1250,
    bestFor: "Large professional project + preview + creator ZIP",
  },
];

function getRazorpayWindow() {
  return window as unknown as {
    Razorpay?: RazorpayConstructor;
  };
}

function loadRazorpayScript() {
  return new Promise<boolean>((resolve) => {
    if (typeof window === "undefined") {
      resolve(false);
      return;
    }

    if (getRazorpayWindow().Razorpay) {
      resolve(true);
      return;
    }

    const existing = document.querySelector<HTMLScriptElement>(
      'script[src="https://checkout.razorpay.com/v1/checkout.js"]'
    );

    if (existing) {
      existing.onload = () => resolve(true);
      existing.onerror = () => resolve(false);
      return;
    }

    const script = document.createElement("script");
    script.src = "https://checkout.razorpay.com/v1/checkout.js";
    script.async = true;
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

async function readJsonSafely<T>(
  response: Response
): Promise<T & { error?: string }> {
  const text = await response.text();

  try {
    return JSON.parse(text) as T & { error?: string };
  } catch {
    return {
      error: `Server returned non-JSON response: ${text.slice(0, 250)}`,
    } as T & { error?: string };
  }
}

function getReadableError(data: {
  error?: string;
  detail?: unknown;
}): string {
  if (data.error) return data.error;

  if (typeof data.detail === "string") return data.detail;

  if (
    typeof data.detail === "object" &&
    data.detail !== null &&
    "message" in data.detail
  ) {
    const detail = data.detail as { message?: unknown };

    if (typeof detail.message === "string") return detail.message;
  }

  return "Payment request failed.";
}

export default function TokenPlans({
  userId,
  onPaymentSuccess,
}: {
  userId: string;
  onPaymentSuccess?: () => void;
}) {
  const [loadingPackage, setLoadingPackage] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  async function verifyPayment(
    response: RazorpaySuccessResponse,
    item: ProjectPassPackage
  ) {
    const verifyResponse = await fetch("/api/payments/verify", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-user-id": userId,
      },
      body: JSON.stringify({
        userId,
        purpose: "project_pass",
        packageId: item.packageId,
        credits: item.credits,
        tokens: item.credits,
        messages: item.messages,
        projects: item.projects,
        model: item.model,
        zipResalePrice: item.zipResalePrice,
        razorpay_order_id: response.razorpay_order_id,
        razorpay_payment_id: response.razorpay_payment_id,
        razorpay_signature: response.razorpay_signature,
      }),
    });

    const data = await readJsonSafely<VerifyPaymentResponse>(verifyResponse);

    if (!verifyResponse.ok || !data?.success) {
      throw new Error(getReadableError(data));
    }

    setSuccess(
      `${item.title} activated. You can now generate 1 project with ${item.model}.`
    );

    onPaymentSuccess?.();
  }

  async function buyPackage(item: ProjectPassPackage) {
    try {
      setError("");
      setSuccess("");
      setLoadingPackage(item.packageId);

      if (!userId) {
        throw new Error("Login required before buying project pass.");
      }

      const loaded = await loadRazorpayScript();

      if (!loaded || !getRazorpayWindow().Razorpay) {
        throw new Error("Razorpay checkout script failed to load.");
      }

      const response = await fetch("/api/payments/create-order", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-user-id": userId,
        },
        body: JSON.stringify({
          userId,
          purpose: "project_pass",
          packageId: item.packageId,
          title: item.title,
          amountInr: item.price,
          credits: item.credits,
          tokens: item.credits,
          messages: item.messages,
          projects: item.projects,
          model: item.model,
          zipResalePrice: item.zipResalePrice,
        }),
      });

      const data = await readJsonSafely<CreateOrderResponse>(response);

      if (!response.ok || !data.success) {
        throw new Error(getReadableError(data));
      }

      if (!data.keyId || !data.order?.razorpayOrderId) {
        throw new Error("Razorpay order details missing.");
      }

      const Razorpay = getRazorpayWindow().Razorpay;

      if (!Razorpay) {
        throw new Error("Razorpay is not available.");
      }

      const options: RazorpayOptions = {
        key: data.keyId,
        amount: data.order.amountPaise,
        currency: data.order.currency || "INR",
        name: "Sambhajingr Developers",
        description: `${item.title} - ${item.messages} messages + ${item.projects} project`,
        order_id: data.order.razorpayOrderId,
        handler: (paymentResponse) => {
          void verifyPayment(paymentResponse, item)
            .catch((err: unknown) => {
              setError(
                err instanceof Error
                  ? err.message
                  : "Payment verification failed."
              );
            })
            .finally(() => {
              setLoadingPackage("");
            });
        },
        theme: {
          color: "#22d3ee",
        },
        modal: {
          ondismiss: () => setLoadingPackage(""),
        },
      };

      new Razorpay(options).open();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Payment failed.");
      setLoadingPackage("");
    }
  }

  return (
    <div className="projectPassPlans">
      <style>{`
        .projectPassPlans {
          display: grid;
          gap: 18px;
        }

        .passIntro {
          padding: 18px;
          border-radius: 22px;
          background: rgba(34, 211, 238, 0.10);
          border: 1px solid rgba(34, 211, 238, 0.20);
          color: #dff9ff;
          line-height: 1.6;
        }

        .passIntro strong {
          color: #67e8f9;
        }

        .projectPassCard {
          padding: 22px;
          border-radius: 24px;
          background: rgba(255,255,255,0.07);
          border: 1px solid rgba(255,255,255,0.12);
          color: #f8fbff;
        }

        .projectPassCard h3 {
          margin: 0;
          font-size: 22px;
          color: #f8fbff;
        }

        .passPrice {
          margin-top: 12px;
          font-size: 38px;
          font-weight: 950;
          color: #22d3ee;
        }

        .passIncludes {
          display: grid;
          gap: 8px;
          margin-top: 14px;
        }

        .passIncludes div {
          padding: 10px 12px;
          border-radius: 14px;
          background: rgba(255,255,255,0.06);
          color: #b9c8d8;
          font-weight: 800;
        }

        .passBestFor {
          margin-top: 12px;
          color: #91a4b8;
          line-height: 1.5;
        }

        .buyPassBtn {
          width: 100%;
          margin-top: 20px;
          min-height: 52px;
          border: 0;
          border-radius: 16px;
          cursor: pointer;
          font-weight: 950;
          color: #03111f;
          background: linear-gradient(135deg, #22d3ee, #38bdf8, #60a5fa);
        }

        .buyPassBtn:disabled {
          opacity: .55;
          cursor: not-allowed;
        }

        .projectPassError,
        .projectPassSuccess {
          padding: 12px;
          border-radius: 14px;
          line-height: 1.5;
        }

        .projectPassError {
          color: #fecaca;
          background: rgba(239,68,68,0.12);
          border: 1px solid rgba(239,68,68,0.24);
        }

        .projectPassSuccess {
          color: #bbf7d0;
          background: rgba(34,197,94,0.12);
          border: 1px solid rgba(34,197,94,0.24);
        }
      `}</style>

      <div className="passIntro">
        <strong>Project Pass System:</strong> Every pass gives 5 AI messages + 1
        project generation. Creator gets preview and ZIP download included.
        Generated project can be added to templates, where other users buy ZIP
        at the tier-based price.
      </div>

      {error ? <div className="projectPassError">{error}</div> : null}
      {success ? <div className="projectPassSuccess">{success}</div> : null}

      {packages.map((item) => (
        <article className="projectPassCard" key={item.packageId}>
          <h3>{item.title}</h3>

          <div className="passPrice">₹{item.price.toLocaleString("en-IN")}</div>

          <div className="passIncludes">
            <div>{item.messages} AI Messages</div>
            <div>{item.projects} Project Generation</div>
            <div>Creator Preview Included</div>
            <div>Creator ZIP Download Included</div>
            <div>Model: {item.model}</div>
            <div>
              Template ZIP Resale Price: ₹
              {item.zipResalePrice.toLocaleString("en-IN")}
            </div>
          </div>

          <div className="passBestFor">{item.bestFor}</div>

          <button
            className="buyPassBtn"
            type="button"
            disabled={loadingPackage === item.packageId}
            onClick={() => void buyPackage(item)}
          >
            {loadingPackage === item.packageId
              ? "Opening Payment..."
              : "Buy Project Pass"}
          </button>
        </article>
      ))}
    </div>
  );
}
