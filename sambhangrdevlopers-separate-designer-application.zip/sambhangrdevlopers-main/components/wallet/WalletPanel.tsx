"use client";

import { useEffect, useState } from "react";
import TokenPlans from "./TokenPlans";

type WalletSummary = {
  userId?: string;
  plan?: string;
  model?: string | null;
  tokensTotal?: number;
  tokensUsed?: number;
  tokensRemaining?: number;
  freeProjectsUsed?: number;
  projectsGeneratedCount?: number;
  purchasedProjectsCount?: number;
  purchasedTemplatesCount?: number;
  updatedAt?: string;
};

type WalletPolicy = {
  plan?: string;
  model?: string;
  projectLimit?: number;
  tokenLimit?: number;
  zipDownloadRequiresPayment?: boolean;
  premiumGeneration?: boolean;
};

type WalletResponse = {
  success?: boolean;
  wallet?: WalletSummary;
  policy?: WalletPolicy;
  canGenerateProject?: boolean;
  generationMessage?: string;
  error?: string;
  detail?: unknown;
};

function getOrCreateUserId() {
  if (typeof window === "undefined") return "public-user";

  const key = "sambhajingr_wallet_user_id";
  const existing = window.localStorage.getItem(key);

  if (existing) return existing;

  const created = `user_${Date.now()}_${Math.random().toString(16).slice(2)}`;
  window.localStorage.setItem(key, created);
  return created;
}

async function readJsonSafely(response: Response): Promise<WalletResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as WalletResponse;
  } catch {
    return {
      success: false,
      error: `Wallet API returned non-JSON: ${text.slice(0, 250)}`,
    };
  }
}

export default function WalletPanel({
  compact = false,
  onWalletLoaded,
}: {
  compact?: boolean;
  onWalletLoaded?: (wallet: WalletSummary, userId: string) => void;
}) {
  const [userId, setUserId] = useState("public-user");
  const [wallet, setWallet] = useState<WalletSummary | null>(null);
  const [policy, setPolicy] = useState<WalletPolicy | null>(null);
  const [canGenerate, setCanGenerate] = useState<boolean | null>(null);
  const [generationMessage, setGenerationMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadWallet(nextUserId?: string) {
    const activeUserId = nextUserId || userId || getOrCreateUserId();

    try {
      setLoading(true);
      setError("");

      const response = await fetch(
        `/api/wallet?userId=${encodeURIComponent(activeUserId)}`,
        {
          cache: "no-store",
          headers: {
            "x-user-id": activeUserId,
          },
        }
      );

      const data = await readJsonSafely(response);

      if (!response.ok || !data.success || !data.wallet) {
        throw new Error(data.error || "Wallet load failed");
      }

      setWallet(data.wallet);
      setPolicy(data.policy || null);
      setCanGenerate(Boolean(data.canGenerateProject));
      setGenerationMessage(data.generationMessage || "");
      onWalletLoaded?.(data.wallet, activeUserId);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Wallet load failed");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const id = getOrCreateUserId();
    setUserId(id);
    void loadWallet(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const total = wallet?.tokensTotal || 0;
  const remaining = wallet?.tokensRemaining || 0;
  const used = wallet?.tokensUsed || 0;
  const percent = total > 0 ? Math.min(100, Math.round((remaining / total) * 100)) : 0;

  return (
    <section className={compact ? "walletPanel compact" : "walletPanel"}>
      <style>{`
        .walletPanel {
          border: 1px solid rgba(255,255,255,0.10);
          background: rgba(255,255,255,0.055);
          border-radius: 22px;
          padding: 16px;
          color: #f8fbff;
        }

        .walletPanel.compact {
          padding: 12px;
        }

        .walletTop {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 12px;
        }

        .walletTitle {
          margin: 0;
          font-size: 16px;
          line-height: 1.2;
        }

        .walletSub {
          margin-top: 5px;
          color: #9fb0c5;
          font-size: 12px;
          line-height: 1.45;
          word-break: break-all;
        }

        .walletBadge {
          color: #04111f;
          font-size: 12px;
          font-weight: 950;
          border-radius: 999px;
          padding: 7px 10px;
          background: linear-gradient(135deg, #67e8f9, #22d3ee);
          text-transform: uppercase;
        }

        .walletStats {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 10px;
          margin-top: 14px;
        }

        .walletStat {
          border: 1px solid rgba(255,255,255,0.08);
          background: rgba(0,0,0,0.16);
          border-radius: 16px;
          padding: 10px;
        }

        .walletStat strong {
          display: block;
          font-size: 18px;
          color: #67e8f9;
        }

        .walletStat span {
          display: block;
          margin-top: 4px;
          color: #9fb0c5;
          font-size: 11px;
        }

        .walletProgress {
          margin-top: 14px;
          height: 10px;
          border-radius: 999px;
          overflow: hidden;
          background: rgba(255,255,255,0.09);
        }

        .walletProgressFill {
          height: 100%;
          border-radius: 999px;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        }

        .walletMessage {
          margin-top: 12px;
          color: #b7c2d0;
          font-size: 13px;
          line-height: 1.55;
        }

        .walletMessage.ok {
          color: #bbf7d0;
        }

        .walletMessage.lock {
          color: #fecaca;
        }

        .walletActions {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
          margin-top: 12px;
        }

        .walletRefreshBtn {
          cursor: pointer;
          border: 1px solid rgba(255,255,255,0.12);
          color: #eafcff;
          background: rgba(255,255,255,0.07);
          border-radius: 14px;
          min-height: 38px;
          padding: 8px 12px;
          font-weight: 850;
        }

        .walletError {
          padding: 12px;
          border-radius: 14px;
          color: #fecaca;
          background: rgba(239,68,68,0.12);
          border: 1px solid rgba(239,68,68,0.24);
          font-size: 13px;
          line-height: 1.55;
        }

        @media (max-width: 560px) {
          .walletStats {
            grid-template-columns: 1fr;
          }
        }
      `}</style>

      {error ? <div className="walletError">{error}</div> : null}

      <div className="walletTop">
        <div>
          <h3 className="walletTitle">Token Wallet</h3>
          <div className="walletSub">
            {loading ? "Loading wallet..." : `User: ${wallet?.userId || userId}`}
          </div>
        </div>

        <div className="walletBadge">{wallet?.plan || "free"}</div>
      </div>

      <div className="walletStats">
        <div className="walletStat">
          <strong>{remaining.toLocaleString()}</strong>
          <span>Remaining</span>
        </div>

        <div className="walletStat">
          <strong>{used.toLocaleString()}</strong>
          <span>Used</span>
        </div>

        <div className="walletStat">
          <strong>{total.toLocaleString()}</strong>
          <span>Total</span>
        </div>
      </div>

      <div className="walletProgress">
        <div className="walletProgressFill" style={{ width: `${percent}%` }} />
      </div>

      <div className={canGenerate ? "walletMessage ok" : "walletMessage lock"}>
        {generationMessage ||
          (canGenerate ? "Project generation allowed." : "Project generation locked.")}
      </div>

      <div className="walletMessage">
        Model: <strong>{policy?.model || wallet?.model || "auto"}</strong>
        <br />
        Free projects used: <strong>{wallet?.freeProjectsUsed || 0}</strong>
      </div>

      <div className="walletActions">
        <button
          type="button"
          className="walletRefreshBtn"
          onClick={() => void loadWallet()}
        >
          Refresh Wallet
        </button>
      </div>

      {!compact ? (
        <div style={{ marginTop: 16 }}>
          <TokenPlans userId={userId} onPaymentSuccess={() => void loadWallet()} />
        </div>
      ) : null}
    </section>
  );
}
