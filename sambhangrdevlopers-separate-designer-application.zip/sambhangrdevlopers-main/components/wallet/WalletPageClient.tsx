"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import TokenPlans from "@/components/wallet/TokenPlans";

type UserProfile = {
  userId?: string;
  name?: string;
  email?: string;
};

type WalletSummary = {
  userId?: string;
  plan?: string;
  model?: string;
  modelTier?: string;

  messagesRemaining?: number;
  projectPassesRemaining?: number;
  zipUnlocked?: boolean;

  tokensTotal?: number;
  tokensUsed?: number;
  tokensRemaining?: number;

  creditsTotal?: number;
  creditsUsed?: number;
  creditsRemaining?: number;
  creditsReserved?: number;

  freeProjectsUsed?: number;
  projectsGeneratedCount?: number;
  purchasedProjectsCount?: number;
  purchasedTemplatesCount?: number;
  updatedAt?: string;
};

type MeResponse = {
  success?: boolean;
  user?: UserProfile;
  wallet?: WalletSummary;
  error?: string;
  detail?: string;
};

async function readJsonSafely(response: Response): Promise<MeResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as MeResponse;
  } catch {
    return {
      success: false,
      error: `Server returned non-JSON: ${text.slice(0, 300)}`,
    };
  }
}

function getPlanLabel(plan?: string) {
  const value = String(plan || "free").toLowerCase();

  if (value === "starter") return "Starter Project Pass";
  if (value === "premium") return "Premium Project Pass";
  if (value === "advanced") return "Advanced Project Pass";
  if (value === "enterprise") return "Enterprise Project Pass";
  if (value === "admin") return "Admin Access";

  return "Free Demo";
}

function getPlanDescription(plan?: string) {
  const value = String(plan || "free").toLowerCase();

  if (value === "starter") {
    return "5 AI messages + 1 small project + preview + ZIP.";
  }

  if (value === "premium") {
    return "5 AI messages + 1 business project + preview + ZIP.";
  }

  if (value === "advanced") {
    return "5 AI messages + 1 admin/full-stack project + preview + ZIP.";
  }

  if (value === "enterprise") {
    return "5 AI messages + 1 advanced project + preview + ZIP.";
  }

  if (value === "admin") {
    return "Full owner/admin access.";
  }

  return "5 AI messages + 1 free demo project + preview + ZIP.";
}

export default function WalletPageClient() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [wallet, setWallet] = useState<WalletSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  async function loadWallet() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/auth/me", {
        cache: "no-store",
      });

      const data = await readJsonSafely(response);

      if (!response.ok || !data.success || !data.user) {
        throw new Error(data.error || data.detail || "Login required.");
      }

      setUser(data.user);
      setWallet(data.wallet || null);

      if (typeof window !== "undefined" && data.user.userId) {
        window.localStorage.setItem(
          "sambhajingr_wallet_user_id",
          data.user.userId
        );
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Wallet load failed.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadWallet();
  }, []);

  const plan = wallet?.plan || "free";
  const model = wallet?.model || "gpt-4.1-mini";
  const messagesRemaining = wallet?.messagesRemaining ?? 0;
  const projectPassesRemaining = wallet?.projectPassesRemaining ?? 0;
  const zipUnlocked = wallet?.zipUnlocked ?? true;

  const totalCredits = wallet?.creditsTotal ?? wallet?.tokensTotal ?? 0;
  const remainingCredits =
    wallet?.creditsRemaining ?? wallet?.tokensRemaining ?? 0;
  const usedCredits = wallet?.creditsUsed ?? wallet?.tokensUsed ?? 0;

  if (loading) {
    return (
      <section className="walletPageBox">
        <WalletStyles />
        <h1>Loading Wallet...</h1>
        <p>Your Project Pass wallet is opening.</p>
      </section>
    );
  }

  if (error || !user) {
    return (
      <section className="walletPageBox">
        <WalletStyles />

        <h1>Login Required</h1>
        <p>{error || "Please login to view your wallet."}</p>

        <div className="walletActions">
          <Link href="/login" className="walletBtn primary">
            Login
          </Link>

          <Link href="/register" className="walletBtn">
            Register
          </Link>
        </div>
      </section>
    );
  }

  return (
    <section className="walletPageBox">
      <WalletStyles />

      <div className="walletHero">
        <div>
          <div className="walletBadge">{getPlanLabel(plan)}</div>
          <h1>Project Pass Wallet</h1>
          <p>
            {user.name} • {user.email}
          </p>
        </div>

        <Link href="/profile" className="walletBtn">
          Profile
        </Link>
      </div>

      <div className="walletNotice">
        {getPlanDescription(plan)}
      </div>

      <div className="walletStats">
        <div className="walletStat highlight">
          <strong>{messagesRemaining.toLocaleString()}</strong>
          <span>AI Messages Left</span>
        </div>

        <div className="walletStat highlight">
          <strong>{projectPassesRemaining.toLocaleString()}</strong>
          <span>Project Passes Left</span>
        </div>

        <div className="walletStat">
          <strong>{zipUnlocked ? "Yes" : "No"}</strong>
          <span>ZIP Download Included</span>
        </div>

        <div className="walletStat">
          <strong>{model}</strong>
          <span>Active Model</span>
        </div>
      </div>

      <div className="walletDetails">
        <div>
          <strong>User ID</strong>
          <span>{user.userId}</span>
        </div>

        <div>
          <strong>Current Plan</strong>
          <span>{getPlanLabel(plan)}</span>
        </div>

        <div>
          <strong>Credits Added</strong>
          <span>{totalCredits.toLocaleString()}</span>
        </div>

        <div>
          <strong>Credits Remaining</strong>
          <span>{remainingCredits.toLocaleString()}</span>
        </div>

        <div>
          <strong>Credits Used</strong>
          <span>{usedCredits.toLocaleString()}</span>
        </div>

        <div>
          <strong>Generated Projects</strong>
          <span>{wallet?.projectsGeneratedCount || 0}</span>
        </div>
      </div>

      <div className="walletInfoBox">
        <strong>How it works:</strong>
        <br />
        Every Project Pass includes 5 AI messages, 1 project generation, preview, and ZIP download.
        Free users also get 1 demo project with ZIP included.
      </div>

      <div className="walletSectionTitle">Buy Project Pass</div>

      <TokenPlans
        userId={user.userId || "public-user"}
        onPaymentSuccess={() => void loadWallet()}
      />

      <div className="walletActions">
        <button
          type="button"
          className="walletBtn primary"
          onClick={() => void loadWallet()}
        >
          Refresh Wallet
        </button>

        <Link href="/ai" className="walletBtn">
          Generate Project
        </Link>

        <Link href="/templates" className="walletBtn">
          Templates
        </Link>
      </div>
    </section>
  );
}

function WalletStyles() {
  return (
    <style>{`
      .walletPageBox {
        width: min(760px, 100%);
        margin: 0 auto;
        padding: 24px;
        border-radius: 28px;
        background: rgba(255,255,255,0.065);
        border: 1px solid rgba(255,255,255,0.12);
        color: #f8fbff;
        box-shadow: 0 24px 80px rgba(0,0,0,0.30);
      }

      .walletHero {
        display: flex;
        justify-content: space-between;
        gap: 18px;
        align-items: flex-start;
      }

      .walletHero h1 {
        margin: 10px 0 0;
        font-size: 34px;
        line-height: 1.1;
      }

      .walletHero p {
        color: #9fb0c5;
        line-height: 1.6;
      }

      .walletBadge {
        display: inline-flex;
        padding: 8px 12px;
        border-radius: 999px;
        background: rgba(34,211,238,0.12);
        color: #67e8f9;
        font-weight: 900;
        text-transform: uppercase;
        letter-spacing: .08em;
      }

      .walletStats {
        display: grid;
        grid-template-columns: repeat(2, minmax(0, 1fr));
        gap: 14px;
        margin-top: 22px;
      }

      .walletStat {
        padding: 16px;
        border-radius: 18px;
        background: rgba(255,255,255,0.07);
        border: 1px solid rgba(255,255,255,0.10);
        min-height: 104px;
      }

      .walletStat.highlight {
        background: rgba(34,211,238,0.10);
        border-color: rgba(34,211,238,0.22);
      }

      .walletStat strong {
        display: block;
        font-size: 24px;
        color: #22d3ee;
        word-break: break-word;
      }

      .walletStat span {
        display: block;
        margin-top: 6px;
        color: #9fb0c5;
      }

      .walletDetails {
        display: grid;
        gap: 12px;
        margin-top: 20px;
      }

      .walletDetails div {
        display: flex;
        justify-content: space-between;
        gap: 12px;
        padding: 12px 0;
        border-bottom: 1px solid rgba(255,255,255,0.08);
      }

      .walletDetails strong {
        color: #eaf8ff;
      }

      .walletDetails span {
        color: #9fb0c5;
        word-break: break-all;
        text-align: right;
      }

      .walletNotice {
        margin-top: 20px;
        padding: 14px;
        border-radius: 16px;
        color: #bae6fd;
        background: rgba(14,165,233,0.10);
        border: 1px solid rgba(14,165,233,0.18);
        line-height: 1.6;
      }

      .walletInfoBox {
        margin-top: 20px;
        padding: 14px;
        border-radius: 16px;
        color: #dff9ff;
        background: rgba(255,255,255,0.06);
        border: 1px solid rgba(255,255,255,0.10);
        line-height: 1.7;
      }

      .walletInfoBox strong {
        color: #67e8f9;
      }

      .walletSectionTitle {
        margin-top: 28px;
        margin-bottom: 16px;
        font-size: 22px;
        font-weight: 950;
        color: #67e8f9;
        letter-spacing: .08em;
        text-transform: uppercase;
      }

      .walletActions {
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin-top: 22px;
      }

      .walletBtn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        min-height: 46px;
        padding: 0 18px;
        border: 1px solid rgba(255,255,255,0.14);
        border-radius: 16px;
        background: rgba(255,255,255,0.08);
        color: #f8fbff;
        text-decoration: none;
        font-weight: 900;
        cursor: pointer;
      }

      .walletBtn.primary {
        color: #04111f;
        background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        border: 0;
      }

      @media (max-width: 560px) {
        .walletStats {
          grid-template-columns: 1fr;
        }

        .walletHero {
          flex-direction: column;
        }

        .walletHero h1 {
          font-size: 28px;
        }

        .walletDetails div {
          flex-direction: column;
        }

        .walletDetails span {
          text-align: left;
        }
      }
    `}</style>
  );
}
