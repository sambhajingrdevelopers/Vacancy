import { company } from "../data/company";
import InfoCard from "../cards/InfoCard";

export default function ContactInfoList() {
  return (
    <div className="stack">
      <InfoCard title="Email Us" value={company.email} />
      <InfoCard title="Call Us" value={company.phone} />
      <InfoCard title="Visit / Location" value={company.address} />

      <div className="contactActionRow">
        <a className="primaryBtn contactMiniBtn" href={`tel:${company.phone}`}>
          Call Now
        </a>

        <a
          className="secondaryBtn contactMiniBtn"
          href={`https://wa.me/${company.whatsappPhone}`}
          target="_blank"
          rel="noopener noreferrer"
        >
          WhatsApp
        </a>

        <a
          className="secondaryBtn contactMiniBtn"
          href={company.mapUrl}
          target="_blank"
          rel="noopener noreferrer"
        >
          Open Map
        </a>
      </div>
    </div>
  );
}
