"use client";

import { FormEvent, useState } from "react";
import { company } from "../data/company";

type FormState = {
  name: string;
  email: string;
  phone: string;
  projectType: string;
  budget: string;
  message: string;
};

const initialState: FormState = {
  name: "",
  email: "",
  phone: "",
  projectType: "",
  budget: "",
  message: "",
};

export default function ContactForm() {
  const [form, setForm] = useState<FormState>(initialState);
  const [status, setStatus] = useState("");

  function updateField(key: keyof FormState, value: string) {
    setForm((current) => ({
      ...current,
      [key]: value,
    }));
  }

  function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (!form.name.trim() || !form.phone.trim() || !form.message.trim()) {
      setStatus("Please add your name, phone number, and project requirement.");
      return;
    }

    const text = [
      "New Project Enquiry - Sambhajingr Developers",
      "",
      `Name: ${form.name}`,
      `Email: ${form.email || "Not provided"}`,
      `Phone: ${form.phone}`,
      `Project Type: ${form.projectType || "Not selected"}`,
      `Budget: ${form.budget || "Not selected"}`,
      "",
      "Requirement:",
      form.message,
    ].join("\n");

    const whatsappUrl = `https://wa.me/${
      company.whatsappPhone
    }?text=${encodeURIComponent(text)}`;

    window.open(whatsappUrl, "_blank", "noopener,noreferrer");

    setStatus("WhatsApp enquiry opened. Send the message to submit enquiry.");
  }

  return (
    <div className="card formCard premiumHover contactFormCard">
      <div className="contactCardHeader">
        <div>
          <div className="eyebrow">Quick Enquiry</div>
          <h3>Tell us about your project</h3>
        </div>

        <span className="contactLiveBadge">Fast Reply</span>
      </div>

      <p className="muted">
        Share your requirement. We can help with website, mobile app, software,
        AI tools, admin panel, payment gateway, and business automation.
      </p>

      {status ? <div className="contactStatus">{status}</div> : null}

      <form className="formGrid" onSubmit={submitForm}>
        <input
          value={form.name}
          onChange={(event) => updateField("name", event.target.value)}
          placeholder="Your Name"
        />

        <input
          value={form.email}
          onChange={(event) => updateField("email", event.target.value)}
          placeholder="Email Address"
          type="email"
        />

        <input
          value={form.phone}
          onChange={(event) => updateField("phone", event.target.value)}
          placeholder="Phone Number"
          type="tel"
        />

        <select
          value={form.projectType}
          onChange={(event) => updateField("projectType", event.target.value)}
        >
          <option value="">Select Project Type</option>
          <option value="Website">Website</option>
          <option value="Mobile App">Mobile App</option>
          <option value="Software">Software</option>
          <option value="E-commerce">E-commerce</option>
          <option value="Admin Panel">Admin Panel</option>
          <option value="AI Automation">AI Automation</option>
          <option value="Payment Gateway">Payment Gateway</option>
        </select>

        <select
          value={form.budget}
          onChange={(event) => updateField("budget", event.target.value)}
        >
          <option value="">Select Budget Range</option>
          <option value="₹4,999 - Simple Website">₹4,999 - Simple Website</option>
          <option value="₹9,999 - Advanced Website">₹9,999 - Advanced Website</option>
          <option value="₹15,000+ - App / Software">₹15,000+ - App / Software</option>
          <option value="Discuss with team">Discuss with team</option>
        </select>

        <textarea
          value={form.message}
          onChange={(event) => updateField("message", event.target.value)}
          placeholder="Tell us about your project requirement"
          rows={6}
        />

        <button className="primaryBtn fullBtn" type="submit">
          Send Enquiry on WhatsApp
        </button>

        <a
          className="secondaryBtn fullBtn contactMailBtn"
          href={`mailto:${company.email}?subject=Project Enquiry - Sambhajingr Developers`}
        >
          Send Email Instead
        </a>
      </form>
    </div>
  );
}
