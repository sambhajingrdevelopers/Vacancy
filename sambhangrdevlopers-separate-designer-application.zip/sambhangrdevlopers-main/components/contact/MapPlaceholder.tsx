import { company } from "../data/company";

export default function MapPlaceholder() {
  return (
    <div className="card mapCard premiumHover">
      <div className="contactCardHeader">
        <div>
          <div className="eyebrow">Office Location</div>
          <h3>Find us on Google Maps</h3>
        </div>

        <a
          className="secondaryBtn mapOpenBtn"
          href={company.mapUrl}
          target="_blank"
          rel="noopener noreferrer"
        >
          Open Map
        </a>
      </div>

      <p className="muted contactLocationText">{company.address}</p>

      <div className="mapBoxReal">
        <iframe
          title="Sambhajingr Developers Office Location"
          src={company.mapEmbedUrl}
          loading="lazy"
          referrerPolicy="no-referrer-when-downgrade"
          allowFullScreen
        />
      </div>
    </div>
  );
}
