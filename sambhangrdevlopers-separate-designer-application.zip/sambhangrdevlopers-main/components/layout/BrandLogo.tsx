import { useId } from "react";

type BrandLogoProps = {
  size?: number;
  compact?: boolean;
  className?: string;
};

export default function BrandLogo({
  size = 56,
  compact = false,
  className = "",
}: BrandLogoProps) {
  const id = useId().replace(/:/g, "");
  const gradA = `gradA-${id}`;
  const gradB = `gradB-${id}`;
  const glow = `glow-${id}`;
  const softGlow = `softGlow-${id}`;

  const textBlock = !compact ? (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        lineHeight: 1,
      }}
    >
      <span
        style={{
          fontSize: Math.max(20, size * 0.36),
          fontWeight: 800,
          letterSpacing: "0.08em",
          background:
            "linear-gradient(90deg, #bff9ff 0%, #67e8f9 25%, #60a5fa 60%, #c084fc 100%)",
          WebkitBackgroundClip: "text",
          backgroundClip: "text",
          color: "transparent",
          textTransform: "uppercase",
          textShadow: "0 0 18px rgba(103,232,249,0.18)",
        }}
      >
        Sambhajingr
      </span>

      <span
        style={{
          marginTop: 6,
          fontSize: Math.max(10, size * 0.16),
          fontWeight: 600,
          letterSpacing: "0.42em",
          textTransform: "uppercase",
          color: "#a5b4d0",
        }}
      >
        Developers
      </span>
    </div>
  ) : null;

  return (
    <div
      className={className}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: compact ? 0 : Math.max(10, size * 0.18),
      }}
    >
      <svg
        width={size}
        height={size}
        viewBox="0 0 120 120"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-label="Sambhangr Developers Logo"
        role="img"
        style={{
          display: "block",
          filter: "drop-shadow(0 10px 30px rgba(34,211,238,0.18))",
        }}
      >
        <defs>
          <linearGradient
            id={gradA}
            x1="18"
            y1="14"
            x2="95"
            y2="98"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#bff9ff" />
            <stop offset="0.28" stopColor="#67E8F9" />
            <stop offset="0.7" stopColor="#60A5FA" />
            <stop offset="1" stopColor="#C084FC" />
          </linearGradient>

          <linearGradient
            id={gradB}
            x1="89"
            y1="14"
            x2="26"
            y2="104"
            gradientUnits="userSpaceOnUse"
          >
            <stop stopColor="#E9D5FF" />
            <stop offset="0.25" stopColor="#A78BFA" />
            <stop offset="0.55" stopColor="#60A5FA" />
            <stop offset="1" stopColor="#22D3EE" />
          </linearGradient>

          <filter id={glow} x="-40%" y="-40%" width="180%" height="180%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feColorMatrix
              in="blur"
              type="matrix"
              values="
                1 0 0 0 0
                0 1 0 0 0
                0 0 1 0 0
                0 0 0 18 -8
              "
              result="glowStrong"
            />
            <feBlend in="SourceGraphic" in2="glowStrong" mode="screen" />
          </filter>

          <filter id={softGlow} x="-60%" y="-60%" width="220%" height="220%">
            <feGaussianBlur stdDeviation="10" />
          </filter>
        </defs>

        <ellipse
          cx="60"
          cy="60"
          rx="42"
          ry="42"
          fill={`url(#${gradA})`}
          opacity="0.12"
          filter={`url(#${softGlow})`}
        />

        <path
          d="M30 21L67 21L48 42H74C86 42 94 49 94 60C94 66 91 72 86 76L62 99H24L44 79H49H70C74 79 77 77 79 75C81 73 82 70 82 67C82 61 78 57 70 57H44C31 57 24 49 24 38C24 31 26 26 30 21Z"
          fill={`url(#${gradA})`}
          filter={`url(#${glow})`}
        />

        <path
          d="M90 99H53L72 78H46C34 78 26 71 26 60C26 54 29 48 34 44L58 21H96L76 41H71H50C46 41 43 43 41 45C39 47 38 50 38 53C38 59 42 63 50 63H76C89 63 96 71 96 82C96 89 94 94 90 99Z"
          fill={`url(#${gradB})`}
          opacity="0.92"
          filter={`url(#${glow})`}
        />

        <path
          d="M35 25H82"
          stroke="rgba(255,255,255,0.42)"
          strokeWidth="2"
          strokeLinecap="round"
          opacity="0.45"
        />
        <path
          d="M38 95H84"
          stroke="rgba(255,255,255,0.28)"
          strokeWidth="2"
          strokeLinecap="round"
          opacity="0.35"
        />
      </svg>

      {textBlock}
    </div>
  );
}
