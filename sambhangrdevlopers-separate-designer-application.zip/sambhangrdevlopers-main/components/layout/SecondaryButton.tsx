export default function SecondaryButton({
  href,
  children,
}: {
  href: string;
  children: React.ReactNode;
}) {
  return (
    <a href={href} className="secondaryBtn">
      {children}
    </a>
  );
}
