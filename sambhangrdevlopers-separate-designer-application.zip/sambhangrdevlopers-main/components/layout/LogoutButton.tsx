"use client";

import { useState } from "react";

export default function LogoutButton() {
  const [isLoading, setIsLoading] = useState(false);

  async function handleLogout() {
    setIsLoading(true);

    try {
      await fetch("/api/logout", {
        method: "POST",
      });

      window.location.href = "/login";
    } catch (error) {
      console.error("Logout failed:", error);
      window.location.href = "/login";
    }
  }

  return (
    <button
      type="button"
      onClick={handleLogout}
      disabled={isLoading}
      style={{
        cursor: isLoading ? "not-allowed" : "pointer",
        border: "1px solid rgba(255,255,255,0.12)",
        borderRadius: 999,
        padding: "10px 14px",
        color: "#f8fbff",
        fontWeight: 800,
        background: "rgba(255,255,255,0.06)",
        opacity: isLoading ? 0.6 : 1,
      }}
    >
      {isLoading ? "Logout..." : "Logout"}
    </button>
  );
}
