import Link from "next/link";
import PrimaryButton from "./PrimaryButton";
import BrandLogo from "./BrandLogo";
import LogoutButton from "./LogoutButton";

export default function SiteHeader() {
  return (
    <>
      <header className="topbar">
        <Link href="/" className="headerBrandShell">
          <div className="headerBrandGlow" />
          <BrandLogo size={52} compact />
          <div className="headerBrandText">
            <div className="headerBrandName">Sambhajingr Developers</div>
            <div className="headerBrandTag">
              Smart IT Solutions for Modern Business
            </div>
          </div>
        </Link>

        <nav className="desktopNav desktopNavWide">
          <Link href="/">Home</Link>
          <Link href="/#services">Services</Link>
          <Link href="/templates">Templates</Link>
          <Link href="/ai">AI Assistant</Link>
          <Link href="/#solutions">Solutions</Link>
          <Link href="/#portfolio">Portfolio</Link>
          <Link href="/careers">Careers</Link>
          <Link href="/vacancies">Vacancies</Link>
          <Link href="/#about">About</Link>
          <Link href="/#contact">Contact</Link>
        </nav>

        <div className="topBtn">
          <PrimaryButton href="/#contact">Book Call</PrimaryButton>
          <LogoutButton />
        </div>
      </header>

      <nav className="mobileNav">
        <Link href="/">Home</Link>
        <Link href="/#services">Services</Link>
        <Link href="/templates">Templates</Link>
        <Link href="/ai">AI Assistant</Link>
        <Link href="/#solutions">Solutions</Link>
        <Link href="/#portfolio">Portfolio</Link>
        <Link href="/careers">Careers</Link>
        <Link href="/vacancies">Vacancies</Link>
        <Link href="/#about">About</Link>
        <Link href="/#contact">Contact</Link>
      </nav>
    </>
  );
}
