import Link from "next/link";
import { company } from "../data/company";
import BrandLogo from "./BrandLogo";

export default function SiteFooter() {
  return (
    <footer className="footer">
      <div className="footerGrid">
        <div>
          <BrandLogo size={46} />
          <p className="footerText">
            Premium IT company website architecture focused on service clarity,
            trust, conversion, modern visuals and future-ready expansion.
          </p>
        </div>

        <div>
          <h4>Quick Links</h4>
          <div className="footerLinks">
            <Link href="/">Home</Link>
            <Link href="/#services">Services</Link>
            <Link href="/#solutions">Solutions</Link>
            <Link href="/#portfolio">Portfolio</Link>
            <Link href="/careers">Careers</Link>
            <Link href="/vacancies">Vacancies</Link>
            <Link href="/#about">About</Link>
            <Link href="/#contact">Contact</Link>
          </div>
        </div>

        <div>
          <h4>Core Focus</h4>
          <div className="footerTextList">
            <div>Website Development</div>
            <div>Web Apps</div>
            <div>Mobile Apps</div>
            <div>Custom Software</div>
            <div>AI Automation</div>
          </div>
        </div>

        <div>
          <h4>Contact</h4>
          <div className="footerTextList">
            <div>{company.email}</div>
            <div>{company.phone}</div>
            <div>{company.address}</div>
          </div>
        </div>
      </div>

      <div className="copyright">
        © 2026 {company.name} · Premium component foundation
      </div>
    </footer>
  );
}
