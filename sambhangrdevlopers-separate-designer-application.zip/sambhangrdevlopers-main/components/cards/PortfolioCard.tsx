import type { PortfolioItem } from "../data/portfolio";

export default function PortfolioCard({ item }: { item: PortfolioItem }) {
  return (
    <div className="card portfolioCard premiumHover">
      <div className="projectTop">
        <span className="categoryPill">{item.category}</span>
        <div className="projectScreen">
          <div className="projectScreenLine line1" />
          <div className="projectScreenLine line2" />
          <div className="projectBars">
            <span />
            <span />
            <span />
          </div>
        </div>
      </div>

      <h3>{item.title}</h3>

      <div className="portfolioMeta">
        <p>
          <strong>Problem:</strong> {item.problem}
        </p>
        <p>
          <strong>Solution:</strong> {item.solution}
        </p>
      </div>

      <div className="portfolioGlowLine" />
    </div>
  );
}