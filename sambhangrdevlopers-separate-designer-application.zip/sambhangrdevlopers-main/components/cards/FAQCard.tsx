import type { FAQItem } from "../data/faqs";

export default function FAQCard({ item }: { item: FAQItem }) {
  return (
    <div className="card faqCard premiumHover">
      <h3>{item.q}</h3>
      <p>{item.a}</p>
    </div>
  );
}