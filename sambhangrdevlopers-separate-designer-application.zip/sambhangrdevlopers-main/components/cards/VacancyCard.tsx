import type { VacancyItem } from "../data/vacancies";

export default function VacancyCard({ item }: { item: VacancyItem }) {
  const applyHref = item.applyHref || "/designer-application";
  const isExternal = applyHref.startsWith("http");

  return (
    <div className="card vacancyCard premiumHover">
      <div className="vacancyTop">
        <div>
          <span className="vacancyType">{item.type}</span>
          <h3>{item.title}</h3>
        </div>
        <span
          className={`vacancyStatus ${item.status
            .toLowerCase()
            .replace(/\s+/g, "-")}`}
        >
          {item.status}
        </span>
      </div>

      <p className="vacancyShort">{item.summary}</p>

      <div className="vacancyMetaGrid">
        <div className="vacancyMetaItem">
          <span>Location</span>
          <strong>{item.location}</strong>
        </div>
        <div className="vacancyMetaItem">
          <span>Experience</span>
          <strong>{item.experience}</strong>
        </div>
        <div className="vacancyMetaItem">
          <span>Mode</span>
          <strong>{item.mode}</strong>
        </div>
        <div className="vacancyMetaItem">
          <span>Department</span>
          <strong>{item.department}</strong>
        </div>
      </div>

      <div className="vacancySkills">
        {item.skills.map((skill) => (
          <span key={skill}>{skill}</span>
        ))}
      </div>

      <div className="vacancyFooter">
        <div className="vacancySalary">{item.salary}</div>
        <a
          href={applyHref}
          className="primaryBtn vacancyBtn"
          target={isExternal ? "_blank" : undefined}
          rel={isExternal ? "noopener noreferrer" : undefined}
        >
          Apply Now
        </a>
      </div>

      <div className="serviceGlowLine" />
    </div>
  );
}
