export default function FeatureCard({
  title,
  desc,
  icon = "✦",
}: {
  title: string;
  desc: string;
  icon?: string;
}) {
  return (
    <div className="card featureCard premiumHover">
      <div className="smallIcon">{icon}</div>
      <h3>{title}</h3>
      <p>{desc}</p>
      <div className="featureGlow" />
    </div>
  );
}