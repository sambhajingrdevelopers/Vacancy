export default function InfoCard({
  title,
  value,
}: {
  title: string;
  value: string;
}) {
  return (
    <div className="card infoCard premiumHover">
      <h3>{title}</h3>
      <p>{value}</p>
    </div>
  );
}