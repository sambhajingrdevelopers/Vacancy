import type { ServiceItem } from "../data/services";

export default function ServiceCard({
  item,
  status = "live",
}: {
  item: ServiceItem;
  status?: "live" | "assisted" | "soon";
}) {
  const label =
    status === "live"
      ? "Live Now"
      : status === "assisted"
      ? "Assisted Service"
      : "Coming Soon";

  return (
    <div className="card serviceCard premiumHover">
      <div className="serviceTop">
        <div className="iconBox">{item.icon}</div>
        <span className={`badge ${status}`}>{label}</span>
      </div>

      <h3>{item.title}</h3>
      <p>{item.desc}</p>

      <div className="serviceGlowLine" />
    </div>
  );
}
