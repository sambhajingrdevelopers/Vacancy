"use client";
import LoginOfferBanner from "@/components/auth/LoginOfferBanner";
import Link from "next/link";
import { FormEvent, Suspense, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

type LoginResponse = {
  success?: boolean;
  error?: string;
  message?: string;
  requiresTwoFactor?: boolean;
  userHint?: {
    email?: string;
  } | null;
};

async function readJson(response: Response): Promise<LoginResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as LoginResponse;
  } catch {
    return {
      success: false,
      error: `Server returned non-JSON response: ${text.slice(0, 300)}`,
    };
  }
}

function getError(data: LoginResponse, fallback: string) {
  if (typeof data.error === "string") return data.error;
  if (typeof data.message === "string") return data.message;
  return fallback;
}

function LoginPageInner() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const redirectTo = searchParams.get("next") || "/ai";

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [requiresTwoFactor, setRequiresTwoFactor] = useState(false);
  const [twoFactorCode, setTwoFactorCode] = useState("");
  const [recoveryCode, setRecoveryCode] = useState("");
  const [useRecoveryCode, setUseRecoveryCode] = useState(false);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [message, setMessage] = useState("");

  async function submitLogin(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      setLoading(true);
      setError("");
      setMessage("");

      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        cache: "no-store",
        body: JSON.stringify({
          email,
          password,
          twoFactorCode:
            requiresTwoFactor && !useRecoveryCode ? twoFactorCode : "",
          recoveryCode:
            requiresTwoFactor && useRecoveryCode ? recoveryCode : "",
        }),
      });

      const data = await readJson(response);

      if (data.requiresTwoFactor) {
        setRequiresTwoFactor(true);
        setMessage("Enter your authenticator app code to complete login.");
        return;
      }

      if (!response.ok || !data.success) {
        throw new Error(getError(data, "Login failed."));
      }

      setMessage(data.message || "Login successful.");
      router.push(redirectTo);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Login failed.");
    } finally {
      setLoading(false);
    }
  }

  function resetTwoFactorStep() {
    setRequiresTwoFactor(false);
    setTwoFactorCode("");
    setRecoveryCode("");
    setUseRecoveryCode(false);
    setMessage("");
    setError("");
  }

  return (
    <main className="loginPage">
      <style>{`
        .loginPage {
          min-height: 100vh;
          display: grid;
          place-items: center;
          padding: 24px;
          color: #f8fbff;
          background:
            radial-gradient(circle at top left, rgba(34,211,238,.16), transparent 30%),
            radial-gradient(circle at bottom right, rgba(168,85,247,.16), transparent 34%),
            #030712;
        }

        .loginCard {
          width: min(460px, 100%);
          border: 1px solid rgba(255,255,255,.10);
          background: rgba(255,255,255,.065);
          border-radius: 30px;
          padding: 28px;
          box-shadow: 0 24px 80px rgba(0,0,0,.30);
          backdrop-filter: blur(18px);
        }

        .loginLogo {
          width: 58px;
          height: 58px;
          display: grid;
          place-items: center;
          border-radius: 20px;
          color: #04111f;
          font-weight: 950;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        }

        .loginTitle {
          margin: 18px 0 0;
          font-size: 34px;
          line-height: 1.05;
          letter-spacing: -0.04em;
        }

        .loginText {
          margin: 12px 0 0;
          color: #b7c2d0;
          line-height: 1.7;
        }

        .loginForm {
          margin-top: 22px;
          display: grid;
          gap: 12px;
        }

        .loginLabel {
          color: #dffbff;
          font-size: 13px;
          font-weight: 900;
        }

        .loginInput {
          width: 100%;
          border: 1px solid rgba(255,255,255,.12);
          background: rgba(255,255,255,.07);
          color: #ffffff;
          border-radius: 16px;
          padding: 14px 15px;
          outline: none;
        }

        .loginInput::placeholder {
          color: rgba(255,255,255,.42);
        }

        .loginInput:disabled {
          opacity: .6;
          cursor: not-allowed;
        }

        .loginBtn {
          width: 100%;
          margin-top: 8px;
          border: 0;
          border-radius: 16px;
          padding: 15px 16px;
          cursor: pointer;
          color: #04111f;
          font-weight: 950;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        }

        .loginBtn:disabled {
          cursor: not-allowed;
          opacity: .55;
        }

        .ghostBtn {
          width: 100%;
          margin-top: 8px;
          border: 1px solid rgba(255,255,255,.12);
          border-radius: 16px;
          padding: 13px 16px;
          cursor: pointer;
          color: #dffbff;
          font-weight: 900;
          background: rgba(255,255,255,.06);
        }

        .loginAlertError,
        .loginAlertSuccess {
          margin-top: 14px;
          border-radius: 16px;
          padding: 13px;
          line-height: 1.6;
          white-space: pre-wrap;
        }

        .loginAlertError {
          color: #fecaca;
          background: rgba(239,68,68,.12);
          border: 1px solid rgba(239,68,68,.24);
        }

        .loginAlertSuccess {
          color: #bbf7d0;
          background: rgba(34,197,94,.12);
          border: 1px solid rgba(34,197,94,.22);
        }

        .loginLinks {
          margin-top: 18px;
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
          color: #9fb0c5;
          font-size: 14px;
        }

        .loginLinks a {
          color: #67e8f9;
          font-weight: 900;
          text-decoration: none;
        }

        .twoFactorBox {
          margin-top: 16px;
          padding: 14px;
          border-radius: 18px;
          background: rgba(34,211,238,.08);
          border: 1px solid rgba(34,211,238,.16);
        }

        .twoFactorBox strong {
          display: block;
          color: #67e8f9;
          margin-bottom: 6px;
        }

        .twoFactorBox p {
          margin: 0;
          color: #b7c2d0;
          line-height: 1.65;
          font-size: 14px;
        }
      `}</style>

      <section className="loginCard">
        <Link href="/" style={{ textDecoration: "none" }}>
          <div className="loginLogo">SD</div>
        </Link>

        <h1 className="loginTitle">
          {requiresTwoFactor ? "Verify 2FA Code" : "Login"}
        </h1>

        <p className="loginText">
          {requiresTwoFactor
            ? "Your account has two-factor authentication enabled. Enter your authenticator code to continue."
            : "Login to access AutoDev AI, templates, wallet, project preview and ZIP download."}
        </p>

        {requiresTwoFactor ? (
          <div className="twoFactorBox">
            <strong>Authenticator App Required</strong>
            <p>
              Open Google Authenticator, Microsoft Authenticator, or Authy and
              enter the 6-digit code for Sambhajingr Developers.
            </p>
          </div>
        ) : null}

        {error ? <div className="loginAlertError">{error}</div> : null}
        {message ? <div className="loginAlertSuccess">{message}</div> : null}

        <form className="loginForm" onSubmit={submitLogin}>
          <label className="loginLabel" htmlFor="email">
            Email
          </label>

          <input
            id="email"
            className="loginInput"
            type="email"
            value={email}
            onChange={(event) => setEmail(event.target.value)}
            placeholder="your@email.com"
            disabled={loading || requiresTwoFactor}
            required
          />

          <label className="loginLabel" htmlFor="password">
            Password
          </label>

          <input
            id="password"
            className="loginInput"
            type="password"
            value={password}
            onChange={(event) => setPassword(event.target.value)}
            placeholder="Enter password"
            disabled={loading || requiresTwoFactor}
            required
          />

          {requiresTwoFactor ? (
            <>
              {!useRecoveryCode ? (
                <>
                  <label className="loginLabel" htmlFor="twoFactorCode">
                    2FA Code
                  </label>

                  <input
                    id="twoFactorCode"
                    className="loginInput"
                    type="text"
                    inputMode="numeric"
                    maxLength={12}
                    value={twoFactorCode}
                    onChange={(event) => setTwoFactorCode(event.target.value)}
                    placeholder="Enter 6-digit code"
                    required
                  />
                </>
              ) : (
                <>
                  <label className="loginLabel" htmlFor="recoveryCode">
                    Backup Code
                  </label>

                  <input
                    id="recoveryCode"
                    className="loginInput"
                    type="text"
                    maxLength={20}
                    value={recoveryCode}
                    onChange={(event) => setRecoveryCode(event.target.value)}
                    placeholder="Example: A1B2-C3D4"
                    required
                  />
                </>
              )}

              <button
                type="button"
                className="ghostBtn"
                onClick={() => {
                  setUseRecoveryCode((current) => !current);
                  setTwoFactorCode("");
                  setRecoveryCode("");
                  setError("");
                  setMessage("");
                }}
              >
                {useRecoveryCode
                  ? "Use Authenticator Code"
                  : "Use Backup Code Instead"}
              </button>

              <button
                type="button"
                className="ghostBtn"
                onClick={resetTwoFactorStep}
              >
                Change Email / Password
              </button>
            </>
          ) : null}

          <button
            type="submit"
            className="loginBtn"
            disabled={
              loading ||
              !email.trim() ||
              !password.trim() ||
              (requiresTwoFactor &&
                !twoFactorCode.trim() &&
                !recoveryCode.trim())
            }
          >
            {loading
              ? "Please wait..."
              : requiresTwoFactor
              ? "Verify & Login"
              : "Login"}
          </button>
        </form>

        <div className="loginLinks">
          <span>New user?</span>
          <Link href="/register">Create account</Link>
          <span>•</span>
          <Link href="/">Back home</Link>
        </div>
      </section>
    </main>
  );
}

function LoginFallback() {
  return (
    <main
      style={{
        minHeight: "100vh",
        display: "grid",
        placeItems: "center",
        padding: 24,
        color: "#f8fbff",
        background: "#030712",
      }}
    >
      Loading login...
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense fallback={<LoginFallback />}>
      <LoginPageInner />
      <LoginOfferBanner />
    </Suspense>
  );
}
