import WebsiteRequirementChat from "@/components/ai/WebsiteRequirementChat";

export const dynamic = "force-dynamic";

export default function AIPage() {
  return <WebsiteRequirementChat />;
}
