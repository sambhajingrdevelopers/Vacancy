import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type PublishPayload = {
  projectId?: string;
  title?: string;
  category?: string;
  stack?: string;
  price?: number;
  description?: string;
  sellerName?: string;
  tags?: string[];
  features?: string[];
  status?: string;
};

type BackendPublishResponse = {
  success?: boolean;
  error?: string;
  template?: unknown;
};

function getPublishUrl() {
  if (process.env.CORE_AUTODEV_TEMPLATE_PUBLISH_URL) {
    return process.env.CORE_AUTODEV_TEMPLATE_PUBLISH_URL;
  }

  const generatorUrl = process.env.CORE_AUTODEV_PROJECT_GENERATOR_URL;

  if (!generatorUrl) {
    throw new Error("CORE_AUTODEV_PROJECT_GENERATOR_URL is missing.");
  }

  const origin = new URL(generatorUrl).origin;
  return `${origin}/api/public/templates/publish`;
}

function isPublishPayload(value: unknown): value is PublishPayload {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

export async function POST(request: NextRequest) {
  try {
    const rawBody = await request.json();

    if (!isPublishPayload(rawBody)) {
      return NextResponse.json(
        {
          success: false,
          error: "Invalid publish payload",
        },
        { status: 400 }
      );
    }

    const response = await fetch(getPublishUrl(), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(rawBody),
      cache: "no-store",
    });

    const text = await response.text();

    let data: BackendPublishResponse;

    try {
      data = JSON.parse(text) as BackendPublishResponse;
    } catch {
      return NextResponse.json(
        {
          success: false,
          error: "EC2 publish template API returned non-JSON response",
          backendStatus: response.status,
          backendText: text.slice(0, 800),
        },
        { status: 502 }
      );
    }

    if (!response.ok) {
      return NextResponse.json(
        {
          success: false,
          error: "EC2 publish template API failed",
          backendStatus: response.status,
          backendData: data,
        },
        { status: response.status }
      );
    }

    return NextResponse.json(data);
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : "Publish template route failed",
      },
      { status: 500 }
    );
  }
}
