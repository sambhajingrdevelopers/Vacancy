import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type BackendTemplate = {
  templateId: string;
  projectId?: string;
  title: string;
  category: string;
  description: string;
  stack?: string;
  price?: number;
  sellerName?: string;
  tags: string[];
  features?: string[];
  status?: string;
  previewUrl?: string;
  downloadUrl?: string;
  frontendPreviewUrl?: string;
  frontendDownloadUrl?: string;
  source?: string;
};

type BackendTemplatesResponse = {
  success?: boolean;
  templates?: unknown[];
  count?: number;
  error?: string;
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function asString(value: unknown, fallback = "") {
  return typeof value === "string" ? value : fallback;
}

function asNumber(value: unknown, fallback = 0) {
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

function asStringArray(value: unknown) {
  return Array.isArray(value)
    ? value.filter((item): item is string => typeof item === "string")
    : [];
}

function normalizeTemplate(value: unknown): BackendTemplate {
  const item = isRecord(value) ? value : {};

  const projectId = asString(item.projectId);
  const templateId =
    asString(item.templateId) ||
    projectId ||
    `template-${Date.now()}-${Math.random().toString(16).slice(2)}`;

  return {
    templateId,
    projectId,
    title: asString(item.title, "AI Generated Template"),
    category: asString(item.category, "Generated"),
    description: asString(
      item.description,
      "AI generated template with preview and ZIP download."
    ),
    stack: asString(item.stack, "Auto"),
    price: asNumber(item.price, 0),
    sellerName: asString(item.sellerName, "Sambhajingr Developers"),
    tags: asStringArray(item.tags),
    features: asStringArray(item.features),
    status: asString(item.status, "published"),
    previewUrl: asString(item.previewUrl),
    downloadUrl: asString(item.downloadUrl),
    source: "generated",
    frontendPreviewUrl: projectId
      ? `/api/generated-project-preview?projectId=${encodeURIComponent(projectId)}`
      : "",
    frontendDownloadUrl: projectId
      ? `/api/generated-project-download?projectId=${encodeURIComponent(projectId)}`
      : "",
  };
}

function getTemplatesUrl() {
  if (process.env.CORE_AUTODEV_TEMPLATES_URL) {
    return process.env.CORE_AUTODEV_TEMPLATES_URL;
  }

  const generatorUrl = process.env.CORE_AUTODEV_PROJECT_GENERATOR_URL;

  if (!generatorUrl) {
    throw new Error("CORE_AUTODEV_PROJECT_GENERATOR_URL is missing.");
  }

  const origin = new URL(generatorUrl).origin;
  return `${origin}/api/public/templates`;
}

export async function GET() {
  try {
    const response = await fetch(getTemplatesUrl(), {
      cache: "no-store",
    });

    const text = await response.text();

    let data: BackendTemplatesResponse;

    try {
      data = JSON.parse(text) as BackendTemplatesResponse;
    } catch {
      return NextResponse.json(
        {
          success: false,
          error: "EC2 templates API returned non-JSON response",
          backendStatus: response.status,
          backendText: text.slice(0, 800),
        },
        { status: 502 }
      );
    }

    if (!response.ok) {
      return NextResponse.json(
        {
          success: false,
          error: "EC2 templates API failed",
          backendStatus: response.status,
          backendData: data,
        },
        { status: response.status }
      );
    }

    const templates = Array.isArray(data.templates)
      ? data.templates.map(normalizeTemplate)
      : [];

    return NextResponse.json({
      success: true,
      templates,
      count: templates.length,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : "Templates route failed",
      },
      { status: 500 }
    );
  }
}
