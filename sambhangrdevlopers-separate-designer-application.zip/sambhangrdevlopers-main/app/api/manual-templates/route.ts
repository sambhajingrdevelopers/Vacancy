import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type TemplateItem = {
  templateId?: string;
  externalPreviewUrl?: string;
  liveProjectUrl?: string;
  frontendPreviewUrl?: string;
  previewUrl?: string;
  [key: string]: unknown;
};

function backendOrigin() {
  return (
    process.env.CORE_AUTODEV_BACKEND_ORIGIN || "http://3.110.30.122:8002"
  ).replace(/\/$/, "");
}

export async function GET() {
  try {
    const response = await fetch(
      `${backendOrigin()}/api/public/manual-templates`,
      { cache: "no-store" }
    );

    const text = await response.text();

    try {
      const data = JSON.parse(text) as {
        success?: boolean;
        templates?: TemplateItem[];
        [key: string]: unknown;
      };

      if (data.success && Array.isArray(data.templates)) {
        data.templates = data.templates.map((item) => {
          const templateId = String(item.templateId || "");
          const hasExternal = Boolean(
            item.externalPreviewUrl || item.liveProjectUrl
          );

          if (templateId && hasExternal) {
            return {
              ...item,
              frontendPreviewUrl: `/templates/live/${encodeURIComponent(
                templateId
              )}`,
              previewUrl: `/templates/live/${encodeURIComponent(templateId)}`,
            };
          }

          return item;
        });
      }

      return NextResponse.json(data, { status: response.status });
    } catch {
      return NextResponse.json(
        {
          success: false,
          error: `Manual templates backend returned non-JSON: ${text.slice(
            0,
            500
          )}`,
        },
        { status: 500 }
      );
    }
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Manual templates route failed.",
      },
      { status: 500 }
    );
  }
}
