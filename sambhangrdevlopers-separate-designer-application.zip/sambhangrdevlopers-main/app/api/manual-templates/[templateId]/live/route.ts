import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function backendOrigin() {
  return (
    process.env.CORE_AUTODEV_BACKEND_ORIGIN || "http://3.110.30.122:8002"
  ).replace(/\/$/, "");
}

export async function GET(
  _request: NextRequest,
  context: { params: Promise<{ templateId: string }> }
) {
  try {
    const { templateId } = await context.params;

    const response = await fetch(
      `${backendOrigin()}/api/public/manual-templates/${encodeURIComponent(
        templateId
      )}/live`,
      { cache: "no-store" }
    );

    const contentType = response.headers.get("content-type") || "text/html";
    const body = await response.arrayBuffer();

    return new NextResponse(body, {
      status: response.status,
      headers: {
        "Content-Type": contentType,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Live preview proxy failed.";

    return new NextResponse(
      `<!doctype html><html><body style="background:#020617;color:white;font-family:Arial;padding:30px"><h1>Preview failed</h1><p>${message}</p></body></html>`,
      {
        status: 500,
        headers: { "Content-Type": "text/html" },
      }
    );
  }
}
