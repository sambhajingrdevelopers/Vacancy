import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function getWalletBaseUrl() {
  return process.env.CORE_AUTODEV_WALLET_URL || "http://3.110.30.122/api/public/wallet";
}

async function readJsonSafely(response: Response) {
  const text = await response.text();

  try {
    return JSON.parse(text);
  } catch {
    return {
      success: false,
      error: `Wallet backend returned non-JSON. Status: ${response.status}`,
      detail: text.slice(0, 500),
    };
  }
}

export async function GET(request: NextRequest) {
  try {
    const userId =
      request.nextUrl.searchParams.get("userId") ||
      request.headers.get("x-user-id") ||
      "public-user";

    const action = request.nextUrl.searchParams.get("action") || "summary";

    let url = `${getWalletBaseUrl()}/summary?userId=${encodeURIComponent(userId)}`;

    if (action === "packs") {
      url = `${getWalletBaseUrl()}/packs`;
    }

    if (action === "rules") {
      url = `${getWalletBaseUrl()}/project-rules`;
    }

    if (action === "transactions") {
      url = `${getWalletBaseUrl()}/transactions?userId=${encodeURIComponent(userId)}`;
    }

    const response = await fetch(url, {
      cache: "no-store",
      headers: {
        "x-user-id": userId,
      },
    });

    const data = await readJsonSafely(response);

    return NextResponse.json(data, {
      status: response.ok ? 200 : response.status,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Wallet route failed.",
      },
      { status: 500 }
    );
  }
}
