import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const AUTH_COOKIE = "sambhajingr_auth";
const TOKEN_MESSAGE = "sambhajingr-developers-auth-v1";

function getLoginUser() {
  return process.env.WEBSITE_LOGIN_USER || "admin";
}

function getLoginPassword() {
  return process.env.WEBSITE_LOGIN_PASSWORD || "admin123";
}

function getAuthSecret() {
  return process.env.WEBSITE_AUTH_SECRET || "change-this-secret-now";
}

function base64UrlEncode(buffer: ArrayBuffer) {
  return Buffer.from(buffer)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

async function createAuthToken() {
  const secret = getAuthSecret();

  const key = await crypto.subtle.importKey(
    "raw",
    new TextEncoder().encode(secret),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );

  const signature = await crypto.subtle.sign(
    "HMAC",
    key,
    new TextEncoder().encode(TOKEN_MESSAGE)
  );

  return `v1.${base64UrlEncode(signature)}`;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const username = String(body?.username || "").trim();
    const password = String(body?.password || "").trim();

    if (!username || !password) {
      return NextResponse.json(
        { error: "Username aur password required hai." },
        { status: 400 }
      );
    }

    const validUsername = getLoginUser();
    const validPassword = getLoginPassword();

    if (username !== validUsername || password !== validPassword) {
      return NextResponse.json(
        { error: "Invalid username ya password." },
        { status: 401 }
      );
    }

    const token = await createAuthToken();

    const response = NextResponse.json({
      success: true,
      message: "Login successful.",
    });

    response.cookies.set({
      name: AUTH_COOKIE,
      value: token,
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
      path: "/",
      maxAge: 60 * 60 * 8,
    });

    return response;
  } catch (error) {
    console.error("Login error:", error);

    return NextResponse.json(
      { error: "Login failed. Please try again." },
      { status: 500 }
    );
  }
}
