import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type ChatMessage = {
  role: "user" | "assistant" | "system";
  content: string;
};

type AIBackendResponse = {
  reply?: string;
  answer?: string;
  response?: string;
  message?: string;
};

function fallbackReply(message: string) {
  return `Demo AI response: "${message}" ke liye Sambhangr Developers aapko website, mobile app, software, automation aur AI integration me help kar sakta hai. Real Python AI connect karne ke liye AI_BACKEND_URL environment variable set kijiye.`;
}

async function callPythonAIBackend(payload: {
  message: string;
  history: ChatMessage[];
  pageContext?: string;
}) {
  const backendUrl = process.env.AI_BACKEND_URL;

  if (!backendUrl) {
    return fallbackReply(payload.message);
  }

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 30000);

  try {
    const response = await fetch(backendUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: controller.signal,
      cache: "no-store",
    });

    if (!response.ok) {
      throw new Error(`Python AI backend error: ${response.status}`);
    }

    const data = (await response.json()) as AIBackendResponse | string;

    if (typeof data === "string") return data;

    return (
      data.reply ||
      data.answer ||
      data.response ||
      data.message ||
      fallbackReply(payload.message)
    );
  } finally {
    clearTimeout(timeout);
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const message = String(body?.message || "").trim();
    const history = Array.isArray(body?.history) ? body.history : [];
    const pageContext = String(body?.pageContext || "");

    if (!message) {
      return NextResponse.json({ error: "Message required" }, { status: 400 });
    }

    const reply = await callPythonAIBackend({
      message,
      history,
      pageContext,
    });

    return NextResponse.json({ reply });
  } catch (error) {
    console.error("AI API error", error);

    return NextResponse.json(
      {
        error:
          "AI backend se response nahi mila. Please backend URL check kijiye.",
      },
      { status: 500 }
    );
  }
}
