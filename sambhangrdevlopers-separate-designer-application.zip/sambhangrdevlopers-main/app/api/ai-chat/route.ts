export { POST, GET } from "../ai/route";
