import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type CreateOrderPayload = {
  userId?: string;
  purpose?: string;
  packageId?: string;
  amountInr?: number;
  tokens?: number;
  projectId?: string;
  templateId?: string;
  title?: string;
  notes?: Record<string, unknown>;
};

type BackendPaymentResponse = {
  success?: boolean;
  keyId?: string;
  order?: unknown;
  razorpayOrder?: unknown;
  error?: string;
  detail?: unknown;
};

function getCreateOrderUrl() {
  if (process.env.CORE_AUTODEV_PAYMENT_CREATE_ORDER_URL) {
    return process.env.CORE_AUTODEV_PAYMENT_CREATE_ORDER_URL;
  }

  const generatorUrl = process.env.CORE_AUTODEV_PROJECT_GENERATOR_URL;

  if (!generatorUrl) {
    throw new Error("CORE_AUTODEV_PROJECT_GENERATOR_URL is missing.");
  }

  const origin = new URL(generatorUrl).origin;
  return `${origin}/api/public/payments/create-order`;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function normalizePayload(value: unknown): CreateOrderPayload {
  const item = isRecord(value) ? value : {};

  return {
    userId: typeof item.userId === "string" ? item.userId : "public-user",
    purpose: typeof item.purpose === "string" ? item.purpose : "tokens",
    packageId: typeof item.packageId === "string" ? item.packageId : undefined,
    amountInr: typeof item.amountInr === "number" ? item.amountInr : undefined,
    tokens: typeof item.tokens === "number" ? item.tokens : undefined,
    projectId: typeof item.projectId === "string" ? item.projectId : undefined,
    templateId: typeof item.templateId === "string" ? item.templateId : undefined,
    title: typeof item.title === "string" ? item.title : "AutoDev AI Purchase",
    notes: isRecord(item.notes) ? item.notes : {},
  };
}

async function readJsonSafely(response: Response): Promise<BackendPaymentResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as BackendPaymentResponse;
  } catch {
    return {
      success: false,
      error: "Payment backend returned non-JSON response",
      detail: text.slice(0, 800),
    };
  }
}

export async function POST(request: NextRequest) {
  try {
    const rawBody = await request.json();
    const payload = normalizePayload(rawBody);

    const response = await fetch(getCreateOrderUrl(), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-user-id": payload.userId || "public-user",
      },
      body: JSON.stringify(payload),
      cache: "no-store",
    });

    const data = await readJsonSafely(response);

    return NextResponse.json(data, {
      status: response.ok ? 200 : response.status,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : "Create order route failed",
      },
      { status: 500 }
    );
  }
}
