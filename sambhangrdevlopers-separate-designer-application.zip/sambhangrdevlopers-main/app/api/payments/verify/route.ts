import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type VerifyPaymentPayload = {
  userId?: string;
  razorpay_order_id?: string;
  razorpay_payment_id?: string;
  razorpay_signature?: string;
};

type VerifyPaymentResponse = {
  success?: boolean;
  alreadyVerified?: boolean;
  wallet?: unknown;
  order?: unknown;
  error?: string;
  detail?: unknown;
};

function getVerifyUrl() {
  if (process.env.CORE_AUTODEV_PAYMENT_VERIFY_URL) {
    return process.env.CORE_AUTODEV_PAYMENT_VERIFY_URL;
  }

  const generatorUrl = process.env.CORE_AUTODEV_PROJECT_GENERATOR_URL;

  if (!generatorUrl) {
    throw new Error("CORE_AUTODEV_PROJECT_GENERATOR_URL is missing.");
  }

  const origin = new URL(generatorUrl).origin;
  return `${origin}/api/public/payments/verify`;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function normalizePayload(value: unknown): VerifyPaymentPayload {
  const item = isRecord(value) ? value : {};

  return {
    userId: typeof item.userId === "string" ? item.userId : "public-user",
    razorpay_order_id:
      typeof item.razorpay_order_id === "string"
        ? item.razorpay_order_id
        : "",
    razorpay_payment_id:
      typeof item.razorpay_payment_id === "string"
        ? item.razorpay_payment_id
        : "",
    razorpay_signature:
      typeof item.razorpay_signature === "string"
        ? item.razorpay_signature
        : "",
  };
}

async function readJsonSafely(response: Response): Promise<VerifyPaymentResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as VerifyPaymentResponse;
  } catch {
    return {
      success: false,
      error: "Payment verify backend returned non-JSON response",
      detail: text.slice(0, 800),
    };
  }
}

export async function POST(request: NextRequest) {
  try {
    const rawBody = await request.json();
    const payload = normalizePayload(rawBody);

    const response = await fetch(getVerifyUrl(), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-user-id": payload.userId || "public-user",
      },
      body: JSON.stringify(payload),
      cache: "no-store",
    });

    const data = await readJsonSafely(response);

    return NextResponse.json(data, {
      status: response.ok ? 200 : response.status,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : "Payment verify route failed",
      },
      { status: 500 }
    );
  }
}
