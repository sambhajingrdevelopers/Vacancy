import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type ApiData = {
  success?: boolean;
  error?: string;
  detail?: string;
  message?: string;
  [key: string]: unknown;
};

function getProjectZipBaseUrl() {
  const backendOrigin =
    process.env.CORE_AUTODEV_BACKEND_ORIGIN ||
    process.env.CORE_AUTODEV_AUTH_URL?.replace(/\/api\/public\/auth\/?$/, "") ||
    "http://3.110.30.122:8002";

  return `${backendOrigin.replace(/\/$/, "")}/api/public/project-zip`;
}

async function readJson(response: Response): Promise<ApiData> {
  const text = await response.text();

  try {
    return JSON.parse(text) as ApiData;
  } catch {
    return {
      success: false,
      error: `Backend returned non-JSON. Status: ${response.status}. Response: ${text.slice(
        0,
        500
      )}`,
    };
  }
}

function getError(data: ApiData, fallback: string) {
  if (typeof data.error === "string") return data.error;
  if (typeof data.detail === "string") return data.detail;
  if (typeof data.message === "string") return data.message;
  return fallback;
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("sambhajingr_session")?.value || "";

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: "Login required.",
        },
        { status: 401 }
      );
    }

    const body = await request.json();

    const response = await fetch(`${getProjectZipBaseUrl()}/verify`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-auth-token": token,
      },
      body: JSON.stringify({
        razorpay_order_id: body.razorpay_order_id || "",
        razorpay_payment_id: body.razorpay_payment_id || "",
        razorpay_signature: body.razorpay_signature || "",
      }),
      cache: "no-store",
    });

    const data = await readJson(response);

    if (!response.ok || !data.success) {
      return NextResponse.json(
        {
          success: false,
          error: getError(data, "Project ZIP payment verify failed."),
          backendStatus: response.status,
          backendData: data,
        },
        { status: response.status || 400 }
      );
    }

    return NextResponse.json(data, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Project ZIP verify route failed.",
      },
      { status: 500 }
    );
  }
}
