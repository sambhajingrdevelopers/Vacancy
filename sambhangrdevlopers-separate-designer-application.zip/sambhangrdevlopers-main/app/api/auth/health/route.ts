import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type BackendHealth = {
  status?: string;
  service?: string;
  detail?: string;
};

async function checkBackendHealth(authBaseUrl: string): Promise<BackendHealth> {
  try {
    const response = await fetch(`${authBaseUrl}/health`, {
      method: "GET",
      cache: "no-store",
    });

    const text = await response.text();

    try {
      return JSON.parse(text) as BackendHealth;
    } catch {
      return {
        status: "error",
        detail: `Backend returned non-JSON. Status: ${response.status}. Response: ${text.slice(
          0,
          300
        )}`,
      };
    }
  } catch (error) {
    return {
      status: "error",
      detail:
        error instanceof Error
          ? error.message
          : "Backend health check failed.",
    };
  }
}

export async function GET() {
  const authBaseUrl =
    process.env.CORE_AUTODEV_AUTH_URL ||
    "http://3.110.30.122/api/public/auth";

  const backend = await checkBackendHealth(authBaseUrl);

  return NextResponse.json({
    success: true,
    message: "Frontend auth route is working",
    version: "AUTH-FIX-2026-05-12",
    authBaseUrl,
    backend,
  });
}
