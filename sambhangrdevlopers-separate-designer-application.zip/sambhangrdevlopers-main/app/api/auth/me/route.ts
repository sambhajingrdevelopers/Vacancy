import { NextRequest, NextResponse } from "next/server";

type AuthData = {
  success?: boolean;
  error?: string;
  message?: string;
  detail?: string;
  user?: unknown;
  wallet?: unknown;
};

function getAuthBaseUrl() {
  return process.env.CORE_AUTODEV_AUTH_URL || "http://3.110.30.122/api/public/auth";
}

async function readJson(response: Response): Promise<AuthData> {
  const text = await response.text();

  try {
    return JSON.parse(text) as AuthData;
  } catch {
    return {
      success: false,
      error: `Backend returned non-JSON. Status: ${response.status}. Response: ${text.slice(
        0,
        500
      )}`,
    };
  }
}

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("sambhajingr_session")?.value || "";

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: "Login required.",
        },
        { status: 401 }
      );
    }

    const response = await fetch(`${getAuthBaseUrl()}/me`, {
      method: "GET",
      headers: {
        "x-auth-token": token,
      },
      cache: "no-store",
    });

    const data = await readJson(response);

    if (!response.ok || !data.success) {
      return NextResponse.json(
        {
          success: false,
          error: data.error || data.detail || data.message || "Session check failed.",
        },
        { status: response.status || 401 }
      );
    }

    return NextResponse.json(data, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Session server error.",
      },
      { status: 500 }
    );
  }
}
