import { NextRequest, NextResponse } from "next/server";

type AuthData = {
  success?: boolean;
  token?: string;
  error?: string;
  message?: string;
  detail?: string;
  user?: unknown;
  wallet?: unknown;
};

function getAuthBaseUrl() {
  return process.env.CORE_AUTODEV_AUTH_URL || "http://3.110.30.122/api/public/auth";
}

async function readJson(response: Response): Promise<AuthData> {
  const text = await response.text();

  try {
    return JSON.parse(text) as AuthData;
  } catch {
    return {
      success: false,
      error: `Backend returned non-JSON. Status: ${response.status}. Response: ${text.slice(
        0,
        500
      )}`,
    };
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const response = await fetch(`${getAuthBaseUrl()}/register`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
      cache: "no-store",
    });

    const data = await readJson(response);

    if (!response.ok || !data.success) {
      return NextResponse.json(
        {
          success: false,
          error: data.error || data.detail || data.message || "Registration failed.",
        },
        { status: response.status || 400 }
      );
    }

    const nextResponse = NextResponse.json(data, { status: 200 });

    if (data.token) {
      nextResponse.cookies.set("sambhajingr_session", data.token, {
        httpOnly: true,
        sameSite: "lax",
        secure: true,
        path: "/",
        maxAge: 60 * 60 * 24 * 7,
      });
    }

    return nextResponse;
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Registration server error.",
      },
      { status: 500 }
    );
  }
}
