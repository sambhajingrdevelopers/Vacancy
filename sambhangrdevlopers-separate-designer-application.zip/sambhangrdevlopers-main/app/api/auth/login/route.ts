import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type LoginApiData = {
  success?: boolean;
  token?: string;
  error?: string;
  detail?: string;
  message?: string;
  requiresTwoFactor?: boolean;
  user?: unknown;
  wallet?: unknown;
  twoFactor?: unknown;
  userHint?: unknown;
  [key: string]: unknown;
};

function getAuthBaseUrl() {
  return (
    process.env.CORE_AUTODEV_AUTH_URL ||
    "http://3.110.30.122:8002/api/public/auth"
  ).replace(/\/$/, "");
}

async function readJson(response: Response): Promise<LoginApiData> {
  const text = await response.text();

  try {
    return JSON.parse(text) as LoginApiData;
  } catch {
    return {
      success: false,
      error: `Backend returned non-JSON. Status: ${response.status}. Response: ${text.slice(
        0,
        500
      )}`,
    };
  }
}

function getError(data: LoginApiData, fallback: string) {
  if (typeof data.error === "string") return data.error;
  if (typeof data.detail === "string") return data.detail;
  if (typeof data.message === "string") return data.message;
  return fallback;
}

function setSessionCookie(response: NextResponse, token: string) {
  response.cookies.set({
    name: "sambhajingr_session",
    value: token,
    httpOnly: true,
    secure: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const backendResponse = await fetch(`${getAuthBaseUrl()}/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      cache: "no-store",
      body: JSON.stringify({
        email: body.email || "",
        password: body.password || "",
        twoFactorCode: body.twoFactorCode || "",
        recoveryCode: body.recoveryCode || "",
      }),
    });

    const data = await readJson(backendResponse);

    if (data.requiresTwoFactor) {
      return NextResponse.json(
        {
          success: false,
          requiresTwoFactor: true,
          message: data.message || "2FA code required.",
          userHint: data.userHint || null,
        },
        { status: 200 }
      );
    }

    if (!backendResponse.ok || !data.success) {
      return NextResponse.json(
        {
          success: false,
          error: getError(data, "Login failed."),
          backendStatus: backendResponse.status,
          backendData: data,
        },
        { status: backendResponse.status || 401 }
      );
    }

    if (!data.token || typeof data.token !== "string") {
      return NextResponse.json(
        {
          success: false,
          error: "Login token missing from backend response.",
          backendData: data,
        },
        { status: 502 }
      );
    }

    const response = NextResponse.json(
      {
        success: true,
        message: data.message || "Login successful.",
        user: data.user || null,
        wallet: data.wallet || null,
        twoFactor: data.twoFactor || null,
      },
      { status: 200 }
    );

    setSessionCookie(response, data.token);

    return response;
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Login route failed.",
      },
      { status: 500 }
    );
  }
}
