import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type ApiData = {
  success?: boolean;
  error?: string;
  detail?: string;
  message?: string;
  [key: string]: unknown;
};

function getTwoFactorBaseUrl() {
  const authBase =
    process.env.CORE_AUTODEV_AUTH_URL ||
    "http://3.110.30.122:8002/api/public/auth";

  return authBase.replace(/\/auth\/?$/, "/2fa").replace(/\/$/, "");
}

async function readJson(response: Response): Promise<ApiData> {
  const text = await response.text();

  try {
    return JSON.parse(text) as ApiData;
  } catch {
    return {
      success: false,
      error: `Backend returned non-JSON. Status: ${response.status}. Response: ${text.slice(
        0,
        500
      )}`,
    };
  }
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("sambhajingr_session")?.value || "";

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: "Login required.",
        },
        { status: 401 }
      );
    }

    const response = await fetch(`${getTwoFactorBaseUrl()}/setup`, {
      method: "POST",
      headers: {
        "x-auth-token": token,
      },
      cache: "no-store",
    });

    const data = await readJson(response);

    return NextResponse.json(data, {
      status: response.ok ? 200 : response.status,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : "2FA setup route failed.",
      },
      { status: 500 }
    );
  }
}
