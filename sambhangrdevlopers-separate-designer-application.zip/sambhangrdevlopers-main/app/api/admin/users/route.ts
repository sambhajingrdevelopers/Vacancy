import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type ApiData = {
  success?: boolean;
  error?: string;
  detail?: string;
  message?: string;
  [key: string]: unknown;
};

function getAdminBaseUrl() {
  const origin = (
    process.env.CORE_AUTODEV_BACKEND_ORIGIN || "http://3.110.30.122:8002"
  ).replace(/\/$/, "");

  return `${origin}/api/public/admin`;
}

async function readJson(response: Response): Promise<ApiData> {
  const text = await response.text();

  try {
    return JSON.parse(text) as ApiData;
  } catch {
    return {
      success: false,
      error: `Admin backend returned non-JSON. Status: ${response.status}. Response: ${text.slice(
        0,
        500
      )}`,
    };
  }
}

function getError(data: ApiData, fallback: string) {
  if (typeof data.error === "string") return data.error;
  if (typeof data.detail === "string") return data.detail;
  if (typeof data.message === "string") return data.message;
  return fallback;
}

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("sambhajingr_session")?.value || "";

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: "Login required.",
        },
        { status: 401 }
      );
    }

    const userId = request.nextUrl.searchParams.get("userId") || "";

    const url = userId
      ? `${getAdminBaseUrl()}/users/${encodeURIComponent(userId)}`
      : `${getAdminBaseUrl()}/users`;

    const response = await fetch(url, {
      method: "GET",
      headers: {
        "x-auth-token": token,
      },
      cache: "no-store",
    });

    const data = await readJson(response);

    if (!response.ok || !data.success) {
      return NextResponse.json(
        {
          success: false,
          error: getError(data, "Admin request failed."),
          backendStatus: response.status,
          backendData: data,
        },
        { status: response.status || 500 }
      );
    }

    return NextResponse.json(data, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Admin route failed.",
      },
      { status: 500 }
    );
  }
}
