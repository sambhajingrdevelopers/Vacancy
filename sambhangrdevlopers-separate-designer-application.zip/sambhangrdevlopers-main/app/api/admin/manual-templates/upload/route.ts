import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type ApiData = {
  success?: boolean;
  error?: string;
  detail?: unknown;
  message?: string;
  [key: string]: unknown;
};

function backendOrigin() {
  return (
    process.env.CORE_AUTODEV_BACKEND_ORIGIN || "http://3.110.30.122:8002"
  ).replace(/\/$/, "");
}

async function readJson(response: Response): Promise<ApiData> {
  const text = await response.text();

  try {
    return JSON.parse(text) as ApiData;
  } catch {
    return {
      success: false,
      error: `Backend returned non-JSON. Status: ${response.status}. Text: ${text.slice(
        0,
        500
      )}`,
    };
  }
}

function getError(data: ApiData, fallback: string) {
  if (typeof data.error === "string") return data.error;
  if (typeof data.detail === "string") return data.detail;
  if (typeof data.message === "string") return data.message;

  if (
    typeof data.detail === "object" &&
    data.detail !== null &&
    "message" in data.detail
  ) {
    const detail = data.detail as { message?: unknown };
    if (typeof detail.message === "string") return detail.message;
  }

  return fallback;
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("sambhajingr_session")?.value || "";

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: "Login required.",
        },
        { status: 401 }
      );
    }

    const formData = await request.formData();

    const response = await fetch(
      `${backendOrigin()}/api/public/admin/manual-templates/upload`,
      {
        method: "POST",
        headers: {
          "x-auth-token": token,
        },
        body: formData,
        cache: "no-store",
      }
    );

    const data = await readJson(response);

    if (!response.ok || !data.success) {
      return NextResponse.json(
        {
          success: false,
          error: getError(data, "Manual template upload failed."),
          backendStatus: response.status,
          backendData: data,
        },
        { status: response.status || 500 }
      );
    }

    return NextResponse.json(data, { status: 200 });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : "Manual template upload failed.",
      },
      { status: 500 }
    );
  }
}
