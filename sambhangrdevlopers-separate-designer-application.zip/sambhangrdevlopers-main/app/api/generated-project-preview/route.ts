import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function getGeneratorUrl() {
  return (
    process.env.CORE_AUTODEV_PROJECT_GENERATOR_URL ||
    "http://3.110.30.122:8002/api/public/generate-project"
  ).replace(/\/$/, "");
}

function getBackendOrigin() {
  return new URL(getGeneratorUrl()).origin;
}

function cleanProjectId(value: string) {
  return value
    .trim()
    .split("?")[0]
    .split("&")[0]
    .replace(/[^a-zA-Z0-9_-]/g, "");
}

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("sambhajingr_session")?.value || "";

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: "Login required to view this project preview.",
        },
        { status: 401 }
      );
    }

    const rawProjectId = request.nextUrl.searchParams.get("projectId") || "";
    const projectId = cleanProjectId(rawProjectId);

    if (!projectId) {
      return NextResponse.json(
        {
          success: false,
          error: "Project id missing.",
          rawProjectId,
        },
        { status: 400 }
      );
    }

    const backendPreviewUrl = `${getBackendOrigin()}/api/public/generated-projects/${encodeURIComponent(
      projectId
    )}/preview`;

    const response = await fetch(backendPreviewUrl, {
      cache: "no-store",
      headers: {
        "x-auth-token": token,
      },
    });

    const html = await response.text();

    if (!response.ok) {
      return NextResponse.json(
        {
          success: false,
          error: "Preview not found or access denied on EC2 backend.",
          backendStatus: response.status,
          backendPreviewUrl,
          backendText: html.slice(0, 1000),
        },
        { status: response.status }
      );
    }

    return new NextResponse(html, {
      status: 200,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store, no-cache, must-revalidate",
        "X-Project-Id": projectId,
      },
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error ? error.message : "Preview proxy route failed.",
      },
      { status: 500 }
    );
  }
}
