import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type ApiData = Record<string, unknown>;

function getGeneratorUrl() {
  return (
    process.env.CORE_AUTODEV_PROJECT_GENERATOR_URL ||
    "http://3.110.30.122:8002/api/public/generate-project"
  ).replace(/\/$/, "");
}

async function readJsonOrThrow(response: Response) {
  const text = await response.text();

  try {
    return JSON.parse(text) as ApiData;
  } catch {
    throw new Error(
      `EC2 project generator returned non-JSON response. Status: ${response.status}. Text: ${text.slice(
        0,
        500
      )}`
    );
  }
}

function cleanUserId(value: unknown) {
  return String(value || "")
    .trim()
    .replace(/[^a-zA-Z0-9_.@-]/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 160);
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("sambhajingr_session")?.value || "";

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: "Login required. Please login before generating a project.",
        },
        { status: 401 }
      );
    }

    const body = await request.json();
    const userId = cleanUserId(body.userId || request.headers.get("x-user-id"));

    const response = await fetch(getGeneratorUrl(), {
      method: "POST",
      cache: "no-store",
      headers: {
        "Content-Type": "application/json",
        "x-auth-token": token,
        "x-user-id": userId,
      },
      body: JSON.stringify({
        message: body.message || "",
        history: body.history || [],
        pageContext: body.pageContext || "",
        sessionId: body.sessionId || "frontend-session",
        userId,
        projectName: body.projectName || "",
        stack: body.stack || "",
      }),
    });

    const data = await readJsonOrThrow(response);

    return NextResponse.json(data, {
      status: response.ok ? 200 : response.status,
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Project generation failed.",
      },
      { status: 500 }
    );
  }
}
