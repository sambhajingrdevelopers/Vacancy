import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function getGeneratorUrl() {
  const url = process.env.CORE_AUTODEV_PROJECT_GENERATOR_URL;

  if (!url) {
    throw new Error("CORE_AUTODEV_PROJECT_GENERATOR_URL is missing.");
  }

  return url;
}

function getBackendOrigin() {
  return new URL(getGeneratorUrl()).origin;
}

type RouteContext = {
  params: Promise<{
    projectId: string;
  }>;
};

export async function GET(_request: Request, context: RouteContext) {
  try {
    const { projectId } = await context.params;

    if (!/^[a-zA-Z0-9_-]+$/.test(projectId)) {
      return NextResponse.json({ error: "Invalid project id" }, { status: 400 });
    }

    const backendPreviewUrl = `${getBackendOrigin()}/api/public/generated-projects/${encodeURIComponent(
      projectId
    )}/preview`;

    const response = await fetch(backendPreviewUrl, {
      cache: "no-store",
    });

    if (!response.ok) {
      return NextResponse.json(
        {
          error: "Preview not found on EC2 backend.",
          backendStatus: response.status,
          backendPreviewUrl,
        },
        { status: response.status }
      );
    }

    const html = await response.text();

    return new NextResponse(html, {
      status: 200,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Preview proxy route failed",
      },
      { status: 500 }
    );
  }
}
