
import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function getGeneratorUrl() {
  const url = process.env.CORE_AUTODEV_PROJECT_GENERATOR_URL;

  if (!url) {
    throw new Error("CORE_AUTODEV_PROJECT_GENERATOR_URL is missing.");
  }

  return url;
}

function getBackendOrigin() {
  return new URL(getGeneratorUrl()).origin;
}

type RouteContext = {
  params: Promise<{
    projectId: string;
  }>;
};

export async function GET(_request: Request, context: RouteContext) {
  try {
    const { projectId } = await context.params;

    if (!/^[a-zA-Z0-9_-]+$/.test(projectId)) {
      return NextResponse.json({ error: "Invalid project id" }, { status: 400 });
    }

    const backendDownloadUrl = `${getBackendOrigin()}/api/public/generated-projects/${encodeURIComponent(
      projectId
    )}/download`;

    const response = await fetch(backendDownloadUrl, {
      cache: "no-store",
    });

    if (!response.ok) {
      return NextResponse.json(
        {
          error: "Download ZIP not found on EC2 backend.",
          backendStatus: response.status,
          backendDownloadUrl,
        },
        { status: response.status }
      );
    }

    const fileBuffer = await response.arrayBuffer();

    return new NextResponse(fileBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="${projectId}.zip"`,
        "Cache-Control": "no-store",
      },
    });
  } catch (error) {
    return NextResponse.json(
      {
        error:
          error instanceof Error ? error.message : "Download proxy route failed",
      },
      { status: 500 }
    );
  }
}
