import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

type ChatMessage = {
  role?: string;
  content?: string;
};

type BackendChatResponse = {
  success?: boolean;
  reply?: string;
  message?: string;
  answer?: string;
  response?: string;
  assistant_reply?: string;
  suggested_autodev_goal?: string | null;
  live_actions?: unknown[];
  model?: string | null;
  token_cost?: number;
  wallet?: unknown;
  project?: string;
  sessionId?: string;
  detail?: unknown;
  error?: string;
  [key: string]: unknown;
};

type FrontendChatRequest = {
  message: string;
  history: ChatMessage[];
  sessionId: string;
  userId: string;
  pageContext?: string;
};

function getChatUrl() {
  const directUrl =
    process.env.CORE_AUTODEV_CHAT_URL || process.env.AI_BACKEND_URL;

  if (directUrl) return directUrl;

  const origin = (
    process.env.CORE_AUTODEV_BACKEND_ORIGIN || "http://3.110.30.122:8002"
  ).replace(/\/$/, "");

  return `${origin}/api/chat/send`;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function asString(value: unknown, fallback = "") {
  return typeof value === "string" ? value : fallback;
}

function cleanUserId(value: unknown) {
  return String(value || "")
    .trim()
    .replace(/[^a-zA-Z0-9_.@-]/g, "-")
    .replace(/-+/g, "-")
    .slice(0, 160);
}

function normalizeHistory(value: unknown): ChatMessage[] {
  if (!Array.isArray(value)) return [];

  return value
    .filter(isRecord)
    .map((item) => ({
      role: asString(item.role),
      content: asString(item.content),
    }))
    .filter((item) => item.role && item.content)
    .slice(-12);
}

function normalizeRequest(value: unknown): FrontendChatRequest {
  const body = isRecord(value) ? value : {};

  const sessionId =
    asString(body.sessionId) ||
    asString(body.project) ||
    `session-${Date.now()}`;

  const userId =
    cleanUserId(body.userId) ||
    cleanUserId(body.walletUserId) ||
    cleanUserId(body.sessionId) ||
    "public-user";

  return {
    message: asString(body.message).trim(),
    history: normalizeHistory(body.history),
    sessionId,
    userId,
    pageContext: asString(body.pageContext, "website-requirement-assistant"),
  };
}

async function readJsonSafely(response: Response): Promise<BackendChatResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as BackendChatResponse;
  } catch {
    return {
      success: false,
      error: `EC2 chat API returned non-JSON response. Status: ${response.status}.`,
      detail: text.slice(0, 1000),
    };
  }
}

function getErrorMessage(data: BackendChatResponse, fallback: string) {
  if (typeof data.error === "string") return data.error;
  if (typeof data.detail === "string") return data.detail;

  if (
    typeof data.detail === "object" &&
    data.detail !== null &&
    "message" in data.detail
  ) {
    const detail = data.detail as { message?: unknown };
    if (typeof detail.message === "string") return detail.message;
  }

  if (typeof data.message === "string" && data.success === false) {
    return data.message;
  }

  return fallback;
}

function extractReply(data: BackendChatResponse) {
  return String(
    data.reply ||
      data.assistant_reply ||
      data.answer ||
      data.response ||
      data.message ||
      ""
  ).trim();
}

export async function POST(request: NextRequest) {
  try {
    const token = request.cookies.get("sambhajingr_session")?.value || "";
    const rawBody = await request.json();
    const payload = normalizeRequest(rawBody);

    if (!payload.message) {
      return NextResponse.json(
        {
          success: false,
          error: "Message required.",
          reply: "Please type your requirement.",
          message: "Please type your requirement.",
          answer: "Please type your requirement.",
          assistant_reply: "Please type your requirement.",
        },
        { status: 400 }
      );
    }

    const project = `user-${payload.userId}-session-${payload.sessionId}`;

    const response = await fetch(getChatUrl(), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        ...(token ? { "x-auth-token": token } : {}),
        "x-user-id": payload.userId,
      },
      body: JSON.stringify({
        project,
        message: payload.message,
        history: payload.history,
        pageContext: payload.pageContext,
        sessionId: payload.sessionId,
        userId: payload.userId,
      }),
      cache: "no-store",
    });

    const data = await readJsonSafely(response);

    if (!response.ok || data.success === false) {
      const error = getErrorMessage(
        data,
        `EC2 chat failed with status ${response.status}`
      );

      return NextResponse.json(
        {
          success: false,
          error,
          reply: error,
          message: error,
          answer: error,
          assistant_reply: error,
          backendStatus: response.status,
          backendData: data,
          paymentRequired: response.status === 402,
        },
        { status: response.status || 500 }
      );
    }

    const reply = extractReply(data);

    const finalReply =
      reply ||
      "I received your message. Please describe what type of website, app, or software you want, and I will guide you.";

    return NextResponse.json({
      success: true,
      reply: finalReply,
      message: finalReply,
      answer: finalReply,
      assistant_reply: finalReply,
      suggested_autodev_goal: data.suggested_autodev_goal || null,
      model: data.model || null,
      token_cost: data.token_cost || 0,
      wallet: data.wallet || null,
      project: data.project || project,
      sessionId: data.sessionId || payload.sessionId,
      source: "ec2-wallet-secured-chat",
      backendData: data,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "AI route failed.";

    return NextResponse.json(
      {
        success: false,
        error: message,
        reply: message,
        message,
        answer: message,
        assistant_reply: message,
      },
      { status: 500 }
    );
  }
}

export async function GET() {
  return NextResponse.json({
    success: true,
    service: "frontend-ai-chat-proxy",
    target: getChatUrl(),
  });
}
