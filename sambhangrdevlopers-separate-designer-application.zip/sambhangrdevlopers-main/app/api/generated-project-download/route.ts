import { NextRequest, NextResponse } from "next/server";

export const dynamic = "force-dynamic";

function getGeneratorUrl() {
  return (
    process.env.CORE_AUTODEV_PROJECT_GENERATOR_URL ||
    "http://3.110.30.122:8002/api/public/generate-project"
  ).replace(/\/$/, "");
}

function getBackendOrigin() {
  return new URL(getGeneratorUrl()).origin;
}

function cleanProjectId(value: string) {
  return value
    .trim()
    .split("?")[0]
    .split("&")[0]
    .replace(/[^a-zA-Z0-9_-]/g, "");
}

async function readError(response: Response) {
  const text = await response.text();

  try {
    return JSON.parse(text) as Record<string, unknown>;
  } catch {
    return {
      success: false,
      error: text.slice(0, 1000) || `Backend failed with ${response.status}`,
    };
  }
}

function getBackendError(data: Record<string, unknown>) {
  if (typeof data.error === "string") return data.error;
  if (typeof data.detail === "string") return data.detail;

  if (
    data.detail &&
    typeof data.detail === "object" &&
    "message" in data.detail &&
    typeof (data.detail as { message?: unknown }).message === "string"
  ) {
    return (data.detail as { message: string }).message;
  }

  return "Download failed from backend.";
}

export async function GET(request: NextRequest) {
  try {
    const token = request.cookies.get("sambhajingr_session")?.value || "";

    if (!token) {
      return NextResponse.json(
        {
          success: false,
          error: "Login required to download this project.",
        },
        { status: 401 }
      );
    }

    const rawProjectId = request.nextUrl.searchParams.get("projectId") || "";
    const projectId = cleanProjectId(rawProjectId);

    if (!projectId) {
      return NextResponse.json(
        {
          success: false,
          error: "Project id missing.",
          rawProjectId,
        },
        { status: 400 }
      );
    }

    const backendDownloadUrl = `${getBackendOrigin()}/api/public/generated-projects/${encodeURIComponent(
      projectId
    )}/download`;

    const response = await fetch(backendDownloadUrl, {
      cache: "no-store",
      headers: {
        "x-auth-token": token,
      },
    });

    if (!response.ok) {
      const data = await readError(response);

      return NextResponse.json(
        {
          success: false,
          error: getBackendError(data),
          backendStatus: response.status,
          backendDownloadUrl,
          projectId,
          backendData: data,
        },
        { status: response.status }
      );
    }

    const arrayBuffer = await response.arrayBuffer();

    if (!arrayBuffer.byteLength) {
      return NextResponse.json(
        {
          success: false,
          error: "Backend returned empty ZIP file.",
          projectId,
        },
        { status: 502 }
      );
    }

    return new NextResponse(arrayBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/zip",
        "Content-Disposition": `attachment; filename="${projectId}.zip"`,
        "Cache-Control": "no-store",
        "X-Project-Id": projectId,
      },
    });
  } catch (error) {
    return NextResponse.json(
      {
        success: false,
        error:
          error instanceof Error
            ? error.message
            : "Generated project download route failed.",
      },
      { status: 500 }
    );
  }
}
