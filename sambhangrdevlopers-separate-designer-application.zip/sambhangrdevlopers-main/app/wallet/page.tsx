import WalletPageClient from "@/components/wallet/WalletPageClient";

export default function WalletPage() {
  return (
    <main
      style={{
        minHeight: "100dvh",
        padding: "80px 18px",
        background:
          "radial-gradient(circle at top left, rgba(103,232,249,0.14), transparent 30%), radial-gradient(circle at bottom right, rgba(192,132,252,0.14), transparent 34%), #030712",
      }}
    >
      <WalletPageClient />
    </main>
  );
}
