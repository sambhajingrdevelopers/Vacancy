import Link from "next/link";
import SiteHeader from "../components/layout/SiteHeader";
import SiteFooter from "../components/layout/SiteFooter";
import HeroSection from "../components/home/HeroSection";
import DeepServicesPreviewSection from "../components/home/DeepServicesPreviewSection";
import LiveServicesSection from "../components/home/LiveServicesSection";
import AssistedServicesSection from "../components/home/AssistedServicesSection";
import ComingSoonSection from "../components/home/ComingSoonSection";
import SolutionsSection from "../components/home/SolutionsSection";
import PortfolioSection from "../components/home/PortfolioSection";
import AboutSection from "../components/home/AboutSection";
import WhyChooseSection from "../components/home/WhyChooseSection";
import CTASection from "../components/home/CTASection";
import ContactSection from "../components/home/ContactSection";
import FAQSection from "../components/home/FAQSection";
import SectionContainer from "../components/layout/SectionContainer";
import SectionHeading from "../components/layout/SectionHeading";
import { company } from "../components/data/company";

export default function Page() {
  return (
    <div className="siteShell">
      <SiteHeader />

      <main className="mainWrap">
        <section className="homeIntroCard">
          <div className="homeIntroGlow" />

          <div className="homeIntroContent">
            <div className="homeIntroBadge">Premium Digital Presence</div>

            <div className="homeIntroGrid">
              <div className="homeIntroText">
                <h1>
                  {company.name} ko
                  <span className="homeIntroGradient">
                    {" "}
                    wow-feel, premium, futuristic
                  </span>{" "}
                  style me present karne ke liye refined homepage ready hai
                </h1>

                <p>
                  Is home page par premium brand positioning, hero presentation,
                  compact 3D services gateway, solutions, portfolio, trust
                  sections aur contact flow structured tareeke se dikhaya gaya
                  hai. Deep service details alag services page par rakhe gaye
                  hain, taaki home page heavy scroll na ho.
                </p>

                <div className="homeIntroTags">
                  {[
                    "Futuristic Visual Feel",
                    "Compact Home Flow",
                    "3D Services Preview",
                    "Scalable Architecture",
                  ].map((item) => (
                    <span key={item}>{item}</span>
                  ))}
                </div>

                <div className="homeIntroActions">
                  <Link href="/services" className="primaryBtn">
                    Explore Services
                  </Link>

                  <Link href="/#deep-services" className="secondaryBtn">
                    Service Preview
                  </Link>

                  <Link href="/careers" className="secondaryBtn">
                    Careers Page
                  </Link>

                  <Link href="/vacancies" className="secondaryBtn">
                    Open Vacancies
                  </Link>
                </div>
              </div>

              <div className="homeIntroPanelGrid">
                {[
                  {
                    title: "Brand Identity",
                    value: "High-end tech presentation",
                  },
                  {
                    title: "Core Direction",
                    value: "Web + App + Software + AI",
                  },
                  {
                    title: "Website Style",
                    value: "Glow, depth, premium glass UI",
                  },
                ].map((item) => (
                  <div className="homeIntroMiniCard" key={item.title}>
                    <div>{item.title}</div>
                    <strong>{item.value}</strong>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        <HeroSection />

        <DeepServicesPreviewSection />

        <SectionContainer>
          <div className="sectionBlock">
            <SectionHeading
              eyebrow="Careers & Hiring"
              title="Dedicated pages for careers and vacancies"
              description="Home par sirf hiring preview rakha gaya hai. Full career culture aur job openings alag pages par available hain."
            />

            <div className="grid twoCols">
              <div className="card premiumHover">
                <div className="eyebrow">Careers</div>

                <h2 style={{ margin: 0, fontSize: 32, lineHeight: 1.15 }}>
                  Work with a modern, growth-focused digital team
                </h2>

                <p style={{ marginTop: 14 }}>
                  Company culture, working style, growth environment aur hiring
                  direction dekhne ke liye dedicated careers page available hai.
                </p>

                <div
                  style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 10,
                    marginTop: 18,
                  }}
                >
                  <span className="vacancyType">Modern Tech Stack</span>
                  <span className="vacancyType">
                    Creative + Technical Culture
                  </span>
                  <span className="vacancyType">Growth Opportunities</span>
                </div>

                <div className="heroActions" style={{ marginTop: 22 }}>
                  <Link href="/careers" className="primaryBtn">
                    View Careers
                  </Link>
                </div>
              </div>

              <div className="card premiumHover">
                <div className="eyebrow">Vacancies</div>

                <h2 style={{ margin: 0, fontSize: 32, lineHeight: 1.15 }}>
                  Explore current job openings and apply
                </h2>

                <p style={{ marginTop: 14 }}>
                  Role details, experience, location, work mode, skills aur
                  apply flow ke saath open vacancies ke liye dedicated page
                  available hai.
                </p>

                <div
                  style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 10,
                    marginTop: 18,
                  }}
                >
                  <span className="vacancyType">Frontend Developer</span>
                  <span className="vacancyType">Backend Developer</span>
                  <span className="vacancyType">UI/UX Designer</span>
                </div>

                <div className="heroActions" style={{ marginTop: 22 }}>
                  <Link href="/vacancies" className="primaryBtn">
                    View Vacancies
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </SectionContainer>

        <div
          style={{
            height: 1,
            background:
              "linear-gradient(90deg, transparent, rgba(103,232,249,0.7), rgba(192,132,252,0.7), transparent)",
            opacity: 0.9,
          }}
        />

        <LiveServicesSection />
        <AssistedServicesSection />
        <ComingSoonSection />
        <SolutionsSection />
        <PortfolioSection />
        <AboutSection />
        <WhyChooseSection />
        <CTASection />
        <ContactSection />
        <FAQSection />
      </main>

      <SiteFooter />
    </div>
  );
}
