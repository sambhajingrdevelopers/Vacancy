import SiteHeader from "../../components/layout/SiteHeader";
import SiteFooter from "../../components/layout/SiteFooter";
import SectionContainer from "../../components/layout/SectionContainer";
import SectionHeading from "../../components/layout/SectionHeading";
import SecondaryButton from "../../components/layout/SecondaryButton";
import DesignerApplicationForm from "../../components/careers/DesignerApplicationForm";

export default function DesignerApplicationPage() {
  return (
    <div className="siteShell">
      <SiteHeader />

      <main className="mainWrap">
        <SectionContainer>
          <section className="glassCard premiumHover applicationHero">
            <div className="sectionBlock">
              <SectionHeading
                eyebrow="Designer Application"
                title="Apply for Creative Designer Vacancy"
                description="This is the separate application form page for Designer hiring. Candidate details can be submitted through WhatsApp or email, and this page can be connected to any custom job domain later."
              />

              <div className="heroActions">
                <SecondaryButton href="/vacancies">Back to Vacancies</SecondaryButton>
              </div>
            </div>
          </section>
        </SectionContainer>

        <SectionContainer>
          <div className="sectionBlock">
            <DesignerApplicationForm />
          </div>
        </SectionContainer>
      </main>

      <SiteFooter />
    </div>
  );
}
