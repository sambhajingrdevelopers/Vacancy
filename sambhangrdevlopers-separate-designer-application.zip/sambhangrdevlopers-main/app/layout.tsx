import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Sambhangr Developers",
  description: "Smart IT Solutions for Modern Business",
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <div className="site-bg">
          <div className="stars" />
          <div className="orb orb-cyan" />
          <div className="orb orb-purple" />
          <div className="orb orb-blue" />
          {children}
        </div>
      </body>
    </html>
  );
}
