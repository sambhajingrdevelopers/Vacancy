import Link from "next/link";
import SiteHeader from "../../components/layout/SiteHeader";
import SiteFooter from "../../components/layout/SiteFooter";
import { company } from "../../components/data/company";
import { servicePackages, services } from "../../components/data/services";

export const metadata = {
  title: "Services | Sambhajingr Developers",
  description:
    "Website development, app development, software, payment gateway, AI automation, admin dashboard and hosting domain setup services.",
};

export default function ServicesPage() {
  const enquiryMessage = [
    "Hello Sambhajingr Developers,",
    "",
    "I want to know about your services and project setup offers.",
    "Please contact me.",
  ].join("\n");

  const whatsappUrl = `https://wa.me/919637705868?text=${encodeURIComponent(
    enquiryMessage
  )}`;

  const emailUrl = `mailto:${company.email}?subject=${encodeURIComponent(
    "Service Enquiry - Sambhajingr Developers"
  )}&body=${encodeURIComponent(enquiryMessage)}`;

  return (
    <div className="siteShell">
      <SiteHeader />

      <main className="mainWrap">
        <style>{`
          .servicesHero {
            position: relative;
            overflow: hidden;
            border-radius: 36px;
            padding: 34px;
            border: 1px solid rgba(255,255,255,0.10);
            background:
              radial-gradient(circle at 10% 15%, rgba(103,232,249,0.18), transparent 28%),
              radial-gradient(circle at 90% 10%, rgba(251,191,36,0.14), transparent 24%),
              linear-gradient(180deg, rgba(255,255,255,0.075), rgba(255,255,255,0.03));
            box-shadow: 0 30px 100px rgba(0,0,0,0.34);
          }

          .servicesHeroGrid {
            display: grid;
            grid-template-columns: minmax(0, 1.2fr) minmax(280px, .8fr);
            gap: 24px;
            align-items: stretch;
          }

          .servicesHero h1 {
            margin: 12px 0 0;
            font-size: clamp(38px, 6vw, 76px);
            line-height: 0.98;
            letter-spacing: -0.055em;
          }

          .servicesHero h1 span {
            color: #67e8f9;
          }

          .servicesHero p {
            margin: 18px 0 0;
            color: #b7c2d0;
            line-height: 1.85;
            max-width: 860px;
          }

          .serviceHeroPanel {
            border-radius: 28px;
            padding: 20px;
            background: rgba(15,23,42,0.72);
            border: 1px solid rgba(255,255,255,0.10);
          }

          .serviceStatGrid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0,1fr));
            gap: 12px;
          }

          .serviceStat {
            border-radius: 20px;
            padding: 16px;
            background: rgba(255,255,255,0.055);
            border: 1px solid rgba(255,255,255,0.09);
          }

          .serviceStat strong {
            display: block;
            color: #67e8f9;
            font-size: 30px;
            line-height: 1;
          }

          .serviceStat span {
            display: block;
            margin-top: 8px;
            color: #b7c2d0;
            font-size: 13px;
            line-height: 1.45;
          }

          .servicePageActions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 26px;
          }

          .serviceSection {
            margin-top: 34px;
          }

          .serviceSectionHead {
            display: flex;
            justify-content: space-between;
            gap: 16px;
            align-items: end;
            margin-bottom: 18px;
          }

          .serviceSectionHead h2 {
            margin: 0;
            font-size: clamp(30px, 5vw, 52px);
            line-height: 1.06;
            letter-spacing: -0.04em;
          }

          .serviceSectionHead p {
            margin: 10px 0 0;
            color: #b7c2d0;
            line-height: 1.75;
            max-width: 720px;
          }

          .serviceGrid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 18px;
          }

          .serviceCard {
            display: flex;
            flex-direction: column;
            gap: 14px;
            min-height: 390px;
          }

          .serviceCard h3 {
            margin: 0;
            font-size: 26px;
            line-height: 1.12;
          }

          .serviceCard p {
            margin: 0;
            color: #b7c2d0;
            line-height: 1.7;
          }

          .serviceBadgeRow {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
          }

          .serviceMiniBadge {
            display: inline-flex;
            width: fit-content;
            padding: 7px 10px;
            border-radius: 999px;
            color: #dffbff;
            background: rgba(34,211,238,0.10);
            border: 1px solid rgba(34,211,238,0.18);
            font-size: 12px;
            font-weight: 900;
          }

          .serviceFeatureList {
            display: grid;
            gap: 8px;
            padding: 0;
            margin: 0;
            list-style: none;
          }

          .serviceFeatureList li {
            display: grid;
            grid-template-columns: 18px 1fr;
            gap: 8px;
            color: #dbeafe;
            line-height: 1.5;
            font-size: 14px;
          }

          .serviceFeatureList li::before {
            content: "✓";
            color: #67e8f9;
            font-weight: 950;
          }

          .serviceCardActions {
            margin-top: auto;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
          }

          .offerGrid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
            gap: 16px;
          }

          .offerCard {
            position: relative;
            overflow: hidden;
            display: flex;
            flex-direction: column;
            gap: 14px;
            border-radius: 28px;
            padding: 22px;
            background: rgba(15,23,42,0.72);
            border: 1px solid rgba(255,255,255,0.10);
            min-height: 380px;
          }

          .offerCard::before {
            content: "";
            position: absolute;
            inset: -35% -35% auto auto;
            width: 220px;
            height: 220px;
            border-radius: 999px;
            background: rgba(34,211,238,0.11);
            filter: blur(24px);
            pointer-events: none;
          }

          .offerCard > * {
            position: relative;
          }

          .offerCard h3 {
            margin: 0;
            font-size: 25px;
            line-height: 1.12;
          }

          .offerPrice {
            color: #67e8f9;
            font-size: 36px;
            font-weight: 950;
            letter-spacing: -0.04em;
          }

          .offerCard p {
            margin: 0;
            color: #b7c2d0;
            line-height: 1.7;
          }

          .deepServiceCTA {
            margin-top: 34px;
            border-radius: 32px;
            padding: 26px;
            background:
              radial-gradient(circle at 20% 20%, rgba(34,211,238,0.14), transparent 25%),
              rgba(255,255,255,0.055);
            border: 1px solid rgba(255,255,255,0.10);
            display: grid;
            grid-template-columns: minmax(0,1fr) auto;
            gap: 16px;
            align-items: center;
          }

          .deepServiceCTA h2 {
            margin: 0;
            font-size: clamp(28px, 5vw, 48px);
            line-height: 1.08;
          }

          .deepServiceCTA p {
            margin: 12px 0 0;
            color: #b7c2d0;
            line-height: 1.7;
          }

          @media (max-width: 860px) {
            .servicesHeroGrid,
            .deepServiceCTA {
              grid-template-columns: 1fr;
            }

            .serviceSectionHead {
              flex-direction: column;
              align-items: flex-start;
            }
          }

          @media (max-width: 620px) {
            .servicesHero {
              padding: 24px;
              border-radius: 28px;
            }

            .serviceCardActions,
            .servicePageActions {
              grid-template-columns: 1fr;
            }

            .serviceCardActions a,
            .servicePageActions a {
              width: 100%;
              justify-content: center;
            }
          }
        `}</style>

        <section className="servicesHero">
          <div className="servicesHeroGrid">
            <div>
              <div className="eyebrow">Deep Services</div>

              <h1>
                Digital services for <span>website, app, software, AI</span> and
                business launch
              </h1>

              <p>
                We help businesses move from idea to launch with professional
                planning, UI structure, development support, hosting/domain setup,
                payment gateway scope, AI features and custom project guidance.
              </p>

              <div className="servicePageActions">
                <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="primaryBtn">
                  WhatsApp Enquiry
                </a>

                <a href={emailUrl} className="secondaryBtn">
                  Email Enquiry
                </a>

                <Link href="/#contact" className="secondaryBtn">
                  Contact Section
                </Link>
              </div>
            </div>

            <aside className="serviceHeroPanel">
              <div className="serviceStatGrid">
                <div className="serviceStat">
                  <strong>8+</strong>
                  <span>Core service categories</span>
                </div>

                <div className="serviceStat">
                  <strong>4</strong>
                  <span>Launch offer levels</span>
                </div>

                <div className="serviceStat">
                  <strong>24/7</strong>
                  <span>Enquiry flow via WhatsApp</span>
                </div>

                <div className="serviceStat">
                  <strong>100%</strong>
                  <span>Business-focused planning</span>
                </div>
              </div>
            </aside>
          </div>
        </section>

        <section className="serviceSection">
          <div className="serviceSectionHead">
            <div>
              <div className="eyebrow">Services</div>
              <h2>Choose the service your project needs</h2>
              <p>
                Every service has a deep page with deliverables, process, features,
                tools and support details.
              </p>
            </div>
          </div>

          <div className="serviceGrid">
            {services.map((service) => (
              <article className="card premiumHover serviceCard" key={service.slug}>
                <div className="serviceBadgeRow">
                  <span className="serviceMiniBadge">{service.category}</span>
                  <span className="serviceMiniBadge">{service.badge}</span>
                </div>

                <h3>{service.title}</h3>

                <p>{service.summary}</p>

                <div className="serviceBadgeRow">
                  <span className="serviceMiniBadge">{service.priceLabel}</span>
                  <span className="serviceMiniBadge">{service.tools[0]}</span>
                </div>

                <ul className="serviceFeatureList">
                  {service.deliverables.slice(0, 4).map((item) => (
                    <li key={item}>{item}</li>
                  ))}
                </ul>

                <div className="serviceCardActions">
                  <Link href={`/services/${service.slug}`} className="primaryBtn">
                    View Details
                  </Link>

                  <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="secondaryBtn">
                    Enquiry
                  </a>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="serviceSection">
          <div className="serviceSectionHead">
            <div>
              <div className="eyebrow">Launch Offers</div>
              <h2>Website, hosting, domain and advanced setup offers</h2>
              <p>
                Simple projects can start from ₹4,799. Bigger and advanced
                projects are discussed with the team before final deal.
              </p>
            </div>
          </div>

          <div className="offerGrid">
            {servicePackages.map((offer) => (
              <article className="offerCard premiumHover" key={offer.name}>
                <span className="serviceMiniBadge">{offer.badge}</span>
                <h3>{offer.name}</h3>
                <div className="offerPrice">{offer.price}</div>
                <p>{offer.description}</p>

                <ul className="serviceFeatureList">
                  {offer.features.map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>

                <p>
                  <strong style={{ color: "#67e8f9" }}>Best for:</strong>{" "}
                  {offer.bestFor}
                </p>
              </article>
            ))}
          </div>
        </section>

        <section className="deepServiceCTA">
          <div>
            <div className="eyebrow">Need Custom Work?</div>
            <h2>Tell us your requirement. Team will guide and finalize the deal.</h2>
            <p>
              If your project includes payment gateway, AI, admin dashboard,
              automation, many pages, mobile app or software features, contact us
              and we will help you plan the right solution.
            </p>
          </div>

          <div className="servicePageActions" style={{ marginTop: 0 }}>
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="primaryBtn">
              WhatsApp Now
            </a>

            <Link href="/#contact" className="secondaryBtn">
              Contact Form
            </Link>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
