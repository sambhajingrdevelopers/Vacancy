import Link from "next/link";
import { notFound } from "next/navigation";
import SiteHeader from "../../../components/layout/SiteHeader";
import SiteFooter from "../../../components/layout/SiteFooter";
import { company } from "../../../components/data/company";
import {
  getServiceBySlug,
  servicePackages,
  services,
} from "../../../components/data/services";

export function generateStaticParams() {
  return services.map((service) => ({
    slug: service.slug,
  }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const service = getServiceBySlug(slug);

  if (!service) {
    return {
      title: "Service Not Found | Sambhajingr Developers",
    };
  }

  return {
    title: `${service.title} | Sambhajingr Developers`,
    description: service.summary,
  };
}

export default async function ServiceDetailPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const service = getServiceBySlug(slug);

  if (!service) {
    notFound();
  }

  const enquiryMessage = [
    "Hello Sambhajingr Developers,",
    "",
    `I am interested in your ${service.title} service.`,
    "Please share details and guide me.",
  ].join("\n");

  const whatsappUrl = `https://wa.me/919637705868?text=${encodeURIComponent(
    enquiryMessage
  )}`;

  const emailUrl = `mailto:${company.email}?subject=${encodeURIComponent(
    `${service.title} Enquiry`
  )}&body=${encodeURIComponent(enquiryMessage)}`;

  return (
    <div className="siteShell">
      <SiteHeader />

      <main className="mainWrap">
        <style>{`
          .detailHero {
            position: relative;
            overflow: hidden;
            border-radius: 36px;
            padding: 34px;
            border: 1px solid rgba(255,255,255,0.10);
            background:
              radial-gradient(circle at 12% 20%, rgba(103,232,249,0.17), transparent 28%),
              radial-gradient(circle at 90% 8%, rgba(192,132,252,0.13), transparent 24%),
              linear-gradient(180deg, rgba(255,255,255,0.075), rgba(255,255,255,0.03));
            box-shadow: 0 30px 100px rgba(0,0,0,0.34);
          }

          .detailHeroGrid {
            display: grid;
            grid-template-columns: minmax(0, 1.2fr) minmax(280px, .8fr);
            gap: 24px;
            align-items: stretch;
          }

          .detailHero h1 {
            margin: 12px 0 0;
            font-size: clamp(38px, 6vw, 76px);
            line-height: 0.98;
            letter-spacing: -0.055em;
          }

          .detailHero h1 span {
            color: #67e8f9;
          }

          .detailHero p {
            margin: 18px 0 0;
            color: #b7c2d0;
            line-height: 1.85;
            max-width: 860px;
          }

          .detailPanel {
            border-radius: 28px;
            padding: 20px;
            background: rgba(15,23,42,0.72);
            border: 1px solid rgba(255,255,255,0.10);
            display: grid;
            gap: 12px;
          }

          .detailPanelItem {
            border-radius: 18px;
            padding: 14px;
            background: rgba(255,255,255,0.055);
            border: 1px solid rgba(255,255,255,0.09);
          }

          .detailPanelItem span {
            display: block;
            color: #9fb0c5;
            font-size: 12px;
            text-transform: uppercase;
            letter-spacing: .08em;
          }

          .detailPanelItem strong {
            display: block;
            margin-top: 7px;
            color: #f8fbff;
            font-size: 18px;
          }

          .detailActions {
            display: flex;
            flex-wrap: wrap;
            gap: 12px;
            margin-top: 24px;
          }

          .detailSection {
            margin-top: 34px;
          }

          .detailGrid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 18px;
          }

          .detailCard {
            border-radius: 28px;
            padding: 22px;
            background: rgba(255,255,255,0.055);
            border: 1px solid rgba(255,255,255,0.10);
          }

          .detailCard h2,
          .detailCard h3 {
            margin: 0;
            font-size: 28px;
            line-height: 1.1;
          }

          .detailCard p {
            color: #b7c2d0;
            line-height: 1.75;
          }

          .detailList {
            display: grid;
            gap: 10px;
            padding: 0;
            margin: 16px 0 0;
            list-style: none;
          }

          .detailList li {
            display: grid;
            grid-template-columns: 22px 1fr;
            gap: 10px;
            color: #dbeafe;
            line-height: 1.55;
          }

          .detailList li::before {
            content: "✓";
            display: grid;
            place-items: center;
            width: 22px;
            height: 22px;
            border-radius: 8px;
            color: #04111f;
            background: linear-gradient(135deg, #67e8f9, #22d3ee);
            font-size: 12px;
            font-weight: 950;
          }

          .detailParagraphBlock {
            display: grid;
            gap: 14px;
          }

          .detailParagraphBlock p {
            margin: 0;
            color: #b7c2d0;
            line-height: 1.85;
            font-size: 16px;
          }

          .detailTagRow {
            display: flex;
            flex-wrap: wrap;
            gap: 9px;
            margin-top: 16px;
          }

          .detailTag {
            display: inline-flex;
            width: fit-content;
            padding: 8px 11px;
            border-radius: 999px;
            color: #dffbff;
            background: rgba(34,211,238,0.10);
            border: 1px solid rgba(34,211,238,0.18);
            font-size: 12px;
            font-weight: 900;
          }

          .packageGrid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 16px;
          }

          .packageCard {
            border-radius: 26px;
            padding: 20px;
            background: rgba(15,23,42,0.72);
            border: 1px solid rgba(255,255,255,0.10);
          }

          .packageCard h3 {
            margin: 10px 0 0;
            font-size: 23px;
            line-height: 1.1;
          }

          .packagePrice {
            margin-top: 12px;
            color: #67e8f9;
            font-size: 32px;
            font-weight: 950;
            letter-spacing: -0.04em;
          }

          .detailCTA {
            margin-top: 34px;
            border-radius: 32px;
            padding: 26px;
            background:
              radial-gradient(circle at 20% 20%, rgba(34,211,238,0.14), transparent 25%),
              rgba(255,255,255,0.055);
            border: 1px solid rgba(255,255,255,0.10);
            display: grid;
            grid-template-columns: minmax(0,1fr) auto;
            gap: 16px;
            align-items: center;
          }

          .detailCTA h2 {
            margin: 0;
            font-size: clamp(28px, 5vw, 48px);
            line-height: 1.08;
          }

          .detailCTA p {
            margin: 12px 0 0;
            color: #b7c2d0;
            line-height: 1.7;
          }

          @media (max-width: 860px) {
            .detailHeroGrid,
            .detailCTA {
              grid-template-columns: 1fr;
            }
          }

          @media (max-width: 620px) {
            .detailHero {
              padding: 24px;
              border-radius: 28px;
            }

            .detailActions a {
              width: 100%;
              justify-content: center;
            }
          }
        `}</style>

        <section className="detailHero">
          <div className="detailHeroGrid">
            <div>
              <div className="eyebrow">{service.category}</div>

              <h1>
                {service.title} <span>service</span>
              </h1>

              <p>{service.summary}</p>

              <div className="detailActions">
                <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="primaryBtn">
                  WhatsApp Enquiry
                </a>

                <a href={emailUrl} className="secondaryBtn">
                  Email Enquiry
                </a>

                <Link href="/services" className="secondaryBtn">
                  All Services
                </Link>
              </div>
            </div>

            <aside className="detailPanel">
              <div className="detailPanelItem">
                <span>Starting Scope</span>
                <strong>{service.priceLabel}</strong>
              </div>

              <div className="detailPanelItem">
                <span>Service Badge</span>
                <strong>{service.badge}</strong>
              </div>

              <div className="detailPanelItem">
                <span>Primary Tool</span>
                <strong>{service.tools[0]}</strong>
              </div>

              <div className="detailPanelItem">
                <span>Support</span>
                <strong>Planning + Launch Guidance</strong>
              </div>
            </aside>
          </div>
        </section>

        <section className="detailSection detailGrid">
          <article className="detailCard">
            <h2>Overview</h2>

            <div className="detailParagraphBlock" style={{ marginTop: 16 }}>
              {service.deepDescription.map((paragraph) => (
                <p key={paragraph}>{paragraph}</p>
              ))}
            </div>
          </article>

          <article className="detailCard">
            <h2>Tools & Technology</h2>

            <div className="detailTagRow">
              {service.tools.map((tool) => (
                <span className="detailTag" key={tool}>
                  {tool}
                </span>
              ))}
            </div>

            <p>
              Technology selection depends on your requirement, budget and future
              scaling plan. We guide the best setup before final development.
            </p>
          </article>
        </section>

        <section className="detailSection detailGrid">
          <article className="detailCard">
            <h2>Deliverables</h2>
            <ul className="detailList">
              {service.deliverables.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>

          <article className="detailCard">
            <h2>Process</h2>
            <ul className="detailList">
              {service.process.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>

          <article className="detailCard">
            <h2>Features</h2>
            <ul className="detailList">
              {service.features.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>

          <article className="detailCard">
            <h2>Support</h2>
            <ul className="detailList">
              {service.support.map((item) => (
                <li key={item}>{item}</li>
              ))}
            </ul>
          </article>
        </section>

        <section className="detailSection">
          <div className="eyebrow">Launch Packages</div>

          <h2
            style={{
              margin: "10px 0 18px",
              fontSize: "clamp(30px, 5vw, 52px)",
              lineHeight: 1.06,
              letterSpacing: "-0.04em",
            }}
          >
            Choose offer based on project size
          </h2>

          <div className="packageGrid">
            {servicePackages.map((offer) => (
              <article className="packageCard premiumHover" key={offer.name}>
                <span className="detailTag">{offer.badge}</span>

                <h3>{offer.name}</h3>

                <div className="packagePrice">{offer.price}</div>

                <p style={{ color: "#b7c2d0", lineHeight: 1.7 }}>
                  {offer.description}
                </p>

                <ul className="detailList">
                  {offer.features.slice(0, 4).map((feature) => (
                    <li key={feature}>{feature}</li>
                  ))}
                </ul>
              </article>
            ))}
          </div>
        </section>

        <section className="detailCTA">
          <div>
            <div className="eyebrow">Ready to Start?</div>
            <h2>Share your requirement and our team will guide you.</h2>
            <p>
              If your project is simple, we will suggest the basic offer. If your
              project is advanced, includes payment gateway, AI, dashboard or many
              functions, our team will discuss and finalize the proper deal.
            </p>
          </div>

          <div className="detailActions" style={{ marginTop: 0 }}>
            <a href={whatsappUrl} target="_blank" rel="noopener noreferrer" className="primaryBtn">
              WhatsApp Now
            </a>

            <Link href="/#contact" className="secondaryBtn">
              Contact Form
            </Link>
          </div>
        </section>
      </main>

      <SiteFooter />
    </div>
  );
}
