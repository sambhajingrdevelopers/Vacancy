import SiteHeader from "../../components/layout/SiteHeader";
import SiteFooter from "../../components/layout/SiteFooter";
import SectionContainer from "../../components/layout/SectionContainer";
import SectionHeading from "../../components/layout/SectionHeading";
import PrimaryButton from "../../components/layout/PrimaryButton";
import SecondaryButton from "../../components/layout/SecondaryButton";
import VacancyCard from "../../components/cards/VacancyCard";
import { designerApplicationUrl, vacancies } from "../../components/data/vacancies";

const processSteps = [
  {
    title: "Application Review",
    desc: "Candidate profile, experience, portfolio, and role fit will be reviewed.",
  },
  {
    title: "Initial Discussion",
    desc: "Short HR or team discussion to understand communication and work interest.",
  },
  {
    title: "Skill Evaluation",
    desc: "Designer candidates may be asked to share sample work or complete a small creative task.",
  },
  {
    title: "Final Decision",
    desc: "Selection, joining details, and next steps will be shared with the candidate.",
  },
];

export default function VacanciesPage() {
  return (
    <div className="siteShell">
      <SiteHeader />

      <main className="mainWrap">
        <SectionContainer>
          <section className="glassCard premiumHover">
            <div className="sectionBlock">
              <SectionHeading
                eyebrow="Vacancies"
                title="Current job openings and hiring opportunities"
                description="Designer vacancy and all job openings are shown with clear role details, required skills, work mode, experience, salary direction, and a direct application link."
              />

              <div className="heroActions">
                <PrimaryButton href={designerApplicationUrl}>
                  Apply for Designer
                </PrimaryButton>
                <SecondaryButton href="/careers">Back to Careers</SecondaryButton>
              </div>
            </div>
          </section>
        </SectionContainer>

        <SectionContainer>
          <div className="sectionBlock">
            <SectionHeading
              eyebrow="Open Roles"
              title="Available positions"
              description="Designer vacancy is highlighted first, and all roles are displayed in premium hiring cards so applicants can understand the requirement quickly."
            />

            <div className="grid twoCols">
              {vacancies.map((item) => (
                <VacancyCard key={item.title} item={item} />
              ))}
            </div>
          </div>
        </SectionContainer>

        <SectionContainer>
          <div className="sectionBlock">
            <SectionHeading
              eyebrow="Hiring Process"
              title="Simple and professional selection flow"
              description="The vacancy page stays clean. The application form is managed separately, so the form domain can be changed anytime without redesigning the vacancy page."
            />

            <div className="grid fourCols">
              {processSteps.map((step, index) => (
                <div key={step.title} className="card featureCard premiumHover">
                  <div className="smallIcon">{index + 1}</div>
                  <h3>{step.title}</h3>
                  <p>{step.desc}</p>
                  <div className="featureGlow" />
                </div>
              ))}
            </div>
          </div>
        </SectionContainer>

        <SectionContainer>
          <div className="ctaBox ctaPremium premiumHover">
            <div className="ctaGlow" />

            <div className="ctaContent">
              <div className="eyebrow">Apply Now</div>
              <h2>
                Found a role that fits your
                <span className="gradientText"> skills and ambition</span>?
              </h2>
              <p>
                Open the separate application form, fill candidate details, and
                send the ready application to HR through WhatsApp or email.
              </p>

              <div className="ctaMiniPoints">
                <span>Clean Vacancy Page</span>
                <span>Separate Application Form</span>
                <span>Easy Domain Change</span>
              </div>
            </div>

            <div className="ctaActions ctaActionsPremium">
              <PrimaryButton href={designerApplicationUrl}>Open Application Form</PrimaryButton>
              <SecondaryButton href="/careers">View Careers Page</SecondaryButton>
            </div>
          </div>
        </SectionContainer>
      </main>

      <SiteFooter />
    </div>
  );
}
