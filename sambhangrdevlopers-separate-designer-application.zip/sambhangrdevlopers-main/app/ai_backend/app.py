"""Example Python backend for the Sambhangr Developers homepage AI.

Run:
    cd ai_backend
    pip install -r requirements.txt
    uvicorn app:app --host 127.0.0.1 --port 8000 --reload

Then create `.env.local` in the Next.js root:
    AI_BACKEND_URL=http://127.0.0.1:8000/chat

Replace `ask_my_ai()` with your own Python AI function/import.
"""

from typing import Any

from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="Sambhangr Developers AI Backend")


class ChatRequest(BaseModel):
    message: str
    history: list[dict[str, Any]] = []
    pageContext: str | None = None


def ask_my_ai(message: str, history: list[dict[str, Any]]) -> str:
    """Connect your already-created Python AI here.

    Example:
        from my_ai_file import ask
        return ask(message, history=history)
    """
    return (
        "Namaste! Main Sambhangr Developers AI backend se reply de raha hoon. "
        f"Aapka question tha: {message}. "
        "Apni original Python AI function ko `ask_my_ai()` ke andar connect kar dijiye."
    )


@app.get("/health")
def health() -> dict[str, str]:
    return {"status": "ok"}


@app.post("/chat")
def chat(request: ChatRequest) -> dict[str, str]:
    reply = ask_my_ai(request.message, request.history)
    return {"reply": reply}