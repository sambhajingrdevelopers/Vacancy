"use client";

import Link from "next/link";
import { useParams } from "next/navigation";
import { useEffect, useMemo, useState } from "react";

type ManualTemplate = {
  templateId?: string;
  title?: string;
  externalPreviewUrl?: string;
  liveProjectUrl?: string;
  frontendPreviewUrl?: string;
  previewUrl?: string;
  zipPreviewUrl?: string;
  hasZip?: boolean;
};

type ManualTemplatesResponse = {
  success?: boolean;
  templates?: ManualTemplate[];
  error?: string;
};

function getParamValue(value: string | string[] | undefined) {
  if (Array.isArray(value)) return value[0] || "";
  return value || "";
}

function isOwnLivePreviewUrl(url: string) {
  return url.includes("/templates/live/");
}

function getPreviewSource(item: ManualTemplate | null, templateId: string) {
  if (!item) return "";

  const externalUrl = String(
    item.externalPreviewUrl || item.liveProjectUrl || ""
  ).trim();

  if (externalUrl) return externalUrl;

  const zipPreviewUrl = String(item.zipPreviewUrl || "").trim();

  if (zipPreviewUrl) return zipPreviewUrl;

  const previewUrl = String(item.frontendPreviewUrl || item.previewUrl || "").trim();

  if (previewUrl && !isOwnLivePreviewUrl(previewUrl)) return previewUrl;

  return `/api/manual-templates/${encodeURIComponent(templateId)}/live`;
}

export default function TemplateLivePreviewPage() {
  const params = useParams();
  const templateId = getParamValue(params?.templateId);

  const [template, setTemplate] = useState<ManualTemplate | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const previewSource = useMemo(
    () => getPreviewSource(template, templateId),
    [template, templateId]
  );

  useEffect(() => {
    async function loadTemplate() {
      try {
        setLoading(true);
        setError("");

        const response = await fetch("/api/manual-templates", {
          cache: "no-store",
        });

        const data = (await response.json()) as ManualTemplatesResponse;

        if (!response.ok || !data.success) {
          throw new Error(data.error || "Template preview load failed.");
        }

        const found = (data.templates || []).find(
          (item) => String(item.templateId || "") === templateId
        );

        if (!found) {
          throw new Error("Template not found.");
        }

        setTemplate(found);
      } catch (err) {
        setError(
          err instanceof Error ? err.message : "Template preview load failed."
        );
      } finally {
        setLoading(false);
      }
    }

    if (templateId) {
      void loadTemplate();
    }
  }, [templateId]);

  return (
    <main
      style={{
        minHeight: "100vh",
        background: "#020617",
        color: "white",
        display: "grid",
        gridTemplateRows: "auto 1fr",
      }}
    >
      <header
        style={{
          minHeight: 58,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 12,
          padding: "10px 14px",
          background: "rgba(2,6,23,0.94)",
          borderBottom: "1px solid rgba(255,255,255,0.12)",
          position: "sticky",
          top: 0,
          zIndex: 10,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            minWidth: 0,
          }}
        >
          <img
            src="/globe.svg"
            alt="Sambhajingr Developers"
            style={{
              width: 38,
              height: 38,
              borderRadius: 12,
              objectFit: "contain",
              background: "rgba(255,255,255,0.06)",
            }}
          />

          <div style={{ minWidth: 0 }}>
            <strong
              style={{
                display: "block",
                lineHeight: 1.1,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
                maxWidth: 220,
              }}
            >
              Sambhajingr Developers
            </strong>

            <small style={{ color: "#67e8f9" }}>
              Secure Live Preview
            </small>
          </div>
        </div>

        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          {previewSource ? (
            <a
              href={previewSource}
              target="_blank"
              rel="noopener noreferrer"
              style={{
                color: "#dffbff",
                background: "rgba(255,255,255,0.08)",
                border: "1px solid rgba(255,255,255,0.14)",
                padding: "10px 12px",
                borderRadius: 12,
                textDecoration: "none",
                fontWeight: 900,
                whiteSpace: "nowrap",
              }}
            >
              Open
            </a>
          ) : null}

          <Link
            href="/templates"
            style={{
              color: "#04111f",
              background: "linear-gradient(135deg,#67e8f9,#22d3ee,#60a5fa)",
              padding: "10px 12px",
              borderRadius: 12,
              textDecoration: "none",
              fontWeight: 900,
              whiteSpace: "nowrap",
            }}
          >
            Back
          </Link>
        </div>
      </header>

      {loading ? (
        <section
          style={{
            display: "grid",
            placeItems: "center",
            padding: 24,
            color: "#b7c2d0",
          }}
        >
          Loading secure preview...
        </section>
      ) : error ? (
        <section
          style={{
            display: "grid",
            placeItems: "center",
            padding: 24,
          }}
        >
          <div
            style={{
              maxWidth: 720,
              borderRadius: 24,
              padding: 24,
              background: "rgba(239,68,68,0.12)",
              border: "1px solid rgba(239,68,68,0.24)",
              color: "#fecaca",
              lineHeight: 1.7,
            }}
          >
            {error}
          </div>
        </section>
      ) : previewSource ? (
        <iframe
          key={previewSource}
          title={template?.title || "Template Live Preview"}
          src={previewSource}
          allow="clipboard-read; clipboard-write; fullscreen; payment; geolocation; camera; microphone"
          referrerPolicy="no-referrer-when-downgrade"
          style={{
            width: "100%",
            height: "calc(100vh - 59px)",
            border: 0,
            background: "white",
          }}
        />
      ) : (
        <section
          style={{
            display: "grid",
            placeItems: "center",
            padding: 24,
            color: "#b7c2d0",
          }}
        >
          Preview link not available.
        </section>
      )}
    </main>
  );
}
