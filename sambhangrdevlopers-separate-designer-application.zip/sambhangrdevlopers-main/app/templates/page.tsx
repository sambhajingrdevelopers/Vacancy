import SiteHeader from "../../components/layout/SiteHeader";
import SiteFooter from "../../components/layout/SiteFooter";
import TemplateMarketplace from "../../components/templates/TemplateMarketplace";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Templates | Sambhajingr Developers",
  description:
    "Explore ready website, app and AI generated templates by Sambhajingr Developers.",
};

export default function TemplatesPage() {
  return (
    <div className="siteShell">
      <SiteHeader />

      <main className="mainWrap">
        <TemplateMarketplace />
      </main>

      <SiteFooter />
    </div>
  );
}
