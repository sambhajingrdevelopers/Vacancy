"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";

type WalletSummary = {
  plan?: string;
  planTier?: string;
  model?: string;
  tokensRemaining?: number;
  projectPassesRemaining?: number;
  projectsGeneratedCount?: number;
  messagesRemaining?: number;
};

type AdminUser = {
  userId?: string;
  name?: string;
  email?: string;
  role?: string;
  status?: string;
  createdAt?: string;
  updatedAt?: string;
  lastLoginAt?: string | null;
  profile?: {
    phone?: string;
    company?: string;
    city?: string;
  };
  wallet?: WalletSummary;
};

type UsersResponse = {
  success?: boolean;
  users?: AdminUser[];
  count?: number;
  error?: string;
};

export default function AdminPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");

  async function loadUsers() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/admin/users", {
        cache: "no-store",
      });

      const data = (await response.json()) as UsersResponse;

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Admin users load failed.");
      }

      setUsers(Array.isArray(data.users) ? data.users : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Admin users load failed.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadUsers();
  }, []);

  const filteredUsers = useMemo(() => {
    const q = search.trim().toLowerCase();

    if (!q) return users;

    return users.filter((user) => {
      const text = [
        user.userId,
        user.name,
        user.email,
        user.role,
        user.status,
        user.profile?.phone,
        user.profile?.company,
        user.profile?.city,
        user.wallet?.plan,
        user.wallet?.planTier,
        user.wallet?.model,
      ]
        .join(" ")
        .toLowerCase();

      return text.includes(q);
    });
  }, [users, search]);

  return (
    <main className="adminShell">
      <style>{`
        .adminShell {
          min-height: 100vh;
          padding: 24px;
          color: #f8fbff;
          background:
            radial-gradient(circle at 10% 20%, rgba(34, 211, 238, 0.16), transparent 25%),
            radial-gradient(circle at 90% 20%, rgba(192, 132, 252, 0.12), transparent 24%),
            #020617;
        }

        .adminTop {
          display: flex;
          justify-content: space-between;
          gap: 16px;
          align-items: center;
          max-width: 1180px;
          margin: 0 auto 22px;
        }

        .adminTitle h1 {
          margin: 0;
          font-size: clamp(32px, 5vw, 58px);
          line-height: 1.05;
          letter-spacing: -0.04em;
        }

        .adminTitle p {
          margin: 12px 0 0;
          color: #9fb0c5;
          line-height: 1.7;
        }

        .adminActions {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
        }

        .adminBtn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          min-height: 44px;
          border-radius: 14px;
          padding: 10px 14px;
          text-decoration: none;
          font-weight: 900;
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
          border: 0;
          cursor: pointer;
        }

        .adminBtnSecondary {
          color: #dffbff;
          background: rgba(255,255,255,0.07);
          border: 1px solid rgba(255,255,255,0.12);
        }

        .adminPanel {
          max-width: 1180px;
          margin: 0 auto;
          border-radius: 28px;
          padding: 20px;
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.10);
          box-shadow: 0 28px 90px rgba(0,0,0,0.32);
        }

        .adminSearch {
          width: 100%;
          border: 1px solid rgba(255,255,255,0.12);
          background: rgba(255,255,255,0.06);
          color: white;
          border-radius: 18px;
          padding: 14px 16px;
          outline: none;
          margin-bottom: 18px;
        }

        .adminSearch::placeholder {
          color: rgba(255,255,255,0.46);
        }

        .adminStats {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
          gap: 12px;
          margin-bottom: 18px;
        }

        .adminStat {
          border-radius: 18px;
          padding: 16px;
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.09);
        }

        .adminStat strong {
          display: block;
          font-size: 26px;
          color: #67e8f9;
        }

        .adminStat span {
          display: block;
          margin-top: 4px;
          color: #9fb0c5;
          font-size: 13px;
        }

        .adminUserGrid {
          display: grid;
          gap: 14px;
        }

        .adminUserCard {
          border-radius: 22px;
          padding: 18px;
          background: rgba(15,23,42,0.7);
          border: 1px solid rgba(255,255,255,0.10);
        }

        .adminUserHead {
          display: flex;
          justify-content: space-between;
          gap: 12px;
          align-items: flex-start;
        }

        .adminUserHead h2 {
          margin: 0;
          font-size: 22px;
        }

        .adminUserHead p {
          margin: 6px 0 0;
          color: #9fb0c5;
          word-break: break-all;
        }

        .adminBadge {
          display: inline-flex;
          width: fit-content;
          padding: 7px 10px;
          border-radius: 999px;
          font-size: 12px;
          font-weight: 900;
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee);
          white-space: nowrap;
        }

        .adminDetailGrid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
          gap: 10px;
          margin-top: 14px;
        }

        .adminDetail {
          padding: 12px;
          border-radius: 16px;
          background: rgba(255,255,255,0.05);
          border: 1px solid rgba(255,255,255,0.08);
        }

        .adminDetail span {
          display: block;
          color: #9fb0c5;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: .08em;
        }

        .adminDetail strong {
          display: block;
          margin-top: 6px;
          color: #f8fbff;
          word-break: break-word;
        }

        .adminError {
          max-width: 1180px;
          margin: 20px auto;
          padding: 16px;
          border-radius: 18px;
          color: #fecaca;
          background: rgba(239,68,68,0.12);
          border: 1px solid rgba(239,68,68,0.24);
        }

        @media (max-width: 720px) {
          .adminShell {
            padding: 16px;
          }

          .adminTop,
          .adminUserHead {
            flex-direction: column;
          }

          .adminActions,
          .adminBtn {
            width: 100%;
          }
        }
      `}</style>

      <div className="adminTop">
        <div className="adminTitle">
          <h1>Admin Control Panel</h1>
          <p>
            View user profiles, wallet details, project passes, generated project
            count, and account status from one secure dashboard.
          </p>
        </div>

        <div className="adminActions">
          <button className="adminBtn" type="button" onClick={() => void loadUsers()}>
            Refresh
          </button>

          <Link className="adminBtn adminBtnSecondary" href="/">
            Back Home
          </Link>
        </div>
      </div>

      {error ? <div className="adminError">{error}</div> : null}

      <section className="adminPanel">
        <input
          className="adminSearch"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          placeholder="Search users by name, email, phone, role, city, plan..."
        />

        <div className="adminStats">
          <div className="adminStat">
            <strong>{users.length}</strong>
            <span>Total Users</span>
          </div>

          <div className="adminStat">
            <strong>
              {users.filter((user) => user.role === "admin").length}
            </strong>
            <span>Admins</span>
          </div>

          <div className="adminStat">
            <strong>
              {users.filter((user) => user.status === "active").length}
            </strong>
            <span>Active Users</span>
          </div>

          <div className="adminStat">
            <strong>{filteredUsers.length}</strong>
            <span>Visible Results</span>
          </div>
        </div>

        {loading ? (
          <div className="adminUserCard">Loading users...</div>
        ) : null}

        {!loading && !filteredUsers.length ? (
          <div className="adminUserCard">No users found.</div>
        ) : null}

        <div className="adminUserGrid">
          {filteredUsers.map((user) => (
            <article className="adminUserCard" key={user.userId}>
              <div className="adminUserHead">
                <div>
                  <h2>{user.name || "Unnamed User"}</h2>
                  <p>{user.email || "No email"}</p>
                </div>

                <span className="adminBadge">
                  {(user.role || "user").toUpperCase()}
                </span>
              </div>

              <div className="adminDetailGrid">
                <div className="adminDetail">
                  <span>User ID</span>
                  <strong>{user.userId || "-"}</strong>
                </div>

                <div className="adminDetail">
                  <span>Status</span>
                  <strong>{user.status || "active"}</strong>
                </div>

                <div className="adminDetail">
                  <span>Phone</span>
                  <strong>{user.profile?.phone || "-"}</strong>
                </div>

                <div className="adminDetail">
                  <span>Company</span>
                  <strong>{user.profile?.company || "-"}</strong>
                </div>

                <div className="adminDetail">
                  <span>City</span>
                  <strong>{user.profile?.city || "-"}</strong>
                </div>

                <div className="adminDetail">
                  <span>Plan</span>
                  <strong>
                    {user.wallet?.planTier || user.wallet?.plan || "free"}
                  </strong>
                </div>

                <div className="adminDetail">
                  <span>Model</span>
                  <strong>{user.wallet?.model || "-"}</strong>
                </div>

                <div className="adminDetail">
                  <span>Messages</span>
                  <strong>{user.wallet?.messagesRemaining ?? 0}</strong>
                </div>

                <div className="adminDetail">
                  <span>Project Passes</span>
                  <strong>{user.wallet?.projectPassesRemaining ?? 0}</strong>
                </div>

                <div className="adminDetail">
                  <span>Tokens</span>
                  <strong>{user.wallet?.tokensRemaining ?? 0}</strong>
                </div>

                <div className="adminDetail">
                  <span>Generated Projects</span>
                  <strong>{user.wallet?.projectsGeneratedCount ?? 0}</strong>
                </div>

                <div className="adminDetail">
                  <span>Created</span>
                  <strong>{user.createdAt || "-"}</strong>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>
    </main>
  );
}
