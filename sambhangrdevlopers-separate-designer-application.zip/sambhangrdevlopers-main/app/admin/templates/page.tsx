"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useState } from "react";

type UserProfile = {
  userId?: string;
  name?: string;
  email?: string;
  role?: string;
};

type AuthMeResponse = {
  success?: boolean;
  user?: UserProfile;
  error?: string;
};

type ManualTemplate = {
  templateId?: string;
  projectId?: string;
  title?: string;
  category?: string;
  description?: string;
  stack?: string;
  model?: string;
  zipPriceInr?: number;
  passPriceInr?: number;
  frontendPreviewUrl?: string;
  frontendDownloadUrl?: string;
  previewUrl?: string;
  downloadUrl?: string;
  livePreviewUrl?: string;
  zipPreviewUrl?: string;
  externalPreviewUrl?: string;
  liveProjectUrl?: string;
  hasZip?: boolean;
  createdAt?: string;
};

type ManualTemplatesResponse = {
  success?: boolean;
  templates?: ManualTemplate[];
  error?: string;
};

const ADMIN_EMAILS = [
  "kafarepradip806@gmail.com",
  "hello@sambhajingrdevelopers.com",
];

const tierOptions = ["Free", "Starter", "Premium", "Advanced", "Enterprise"];

const tierPrices: Record<string, number> = {
  Free: 0,
  Starter: 75,
  Premium: 249,
  Advanced: 625,
  Enterprise: 1250,
};

const tierModels: Record<string, string> = {
  Free: "gpt-4.1-mini",
  Starter: "gpt-5-mini",
  Premium: "gpt-5.4-mini",
  Advanced: "gpt-5",
  Enterprise: "gpt-5.5",
};

function isAdminUser(user: UserProfile | null) {
  if (!user) return false;

  const role = String(user.role || "").toLowerCase();
  const email = String(user.email || "").toLowerCase();

  return role === "admin" || ADMIN_EMAILS.includes(email);
}

export default function AdminTemplatesPage() {
  const [authLoading, setAuthLoading] = useState(true);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [authError, setAuthError] = useState("");

  const [title, setTitle] = useState("");
  const [category, setCategory] = useState("Premium");
  const [price, setPrice] = useState(249);
  const [description, setDescription] = useState("");
  const [stack, setStack] = useState("HTML/CSS/JS");
  const [model, setModel] = useState("gpt-5.4-mini");
  const [tags, setTags] = useState("Business,Template,Premium");
  const [externalPreviewUrl, setExternalPreviewUrl] = useState("");
  const [zipFile, setZipFile] = useState<File | null>(null);

  const [templates, setTemplates] = useState<ManualTemplate[]>([]);
  const [loading, setLoading] = useState(false);
  const [loadingList, setLoadingList] = useState(true);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  const isAdmin = useMemo(() => isAdminUser(user), [user]);

  function updateTier(nextTier: string) {
    setCategory(nextTier);
    setPrice(tierPrices[nextTier] ?? 249);
    setModel(tierModels[nextTier] || "gpt-5.4-mini");

    if (nextTier === "Free") {
      setTags("Free,Student,Template,Source Code");
    } else {
      setTags(`${nextTier},Template,Premium`);
    }
  }

  async function loadAuth() {
    try {
      setAuthLoading(true);
      setAuthError("");

      const response = await fetch("/api/auth/me", {
        cache: "no-store",
        credentials: "include",
      });

      const data = (await response.json()) as AuthMeResponse;

      if (!response.ok || !data.success || !data.user) {
        throw new Error(data.error || "Login required.");
      }

      setUser(data.user);
    } catch (err) {
      setUser(null);
      setAuthError(err instanceof Error ? err.message : "Login required.");
    } finally {
      setAuthLoading(false);
    }
  }

  async function loadTemplates() {
    try {
      setLoadingList(true);
      setError("");

      const response = await fetch("/api/manual-templates", {
        cache: "no-store",
      });

      const data = (await response.json()) as ManualTemplatesResponse;

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Manual templates load failed.");
      }

      setTemplates(Array.isArray(data.templates) ? data.templates : []);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Manual templates load failed.");
    } finally {
      setLoadingList(false);
    }
  }

  useEffect(() => {
    void loadAuth();
  }, []);

  useEffect(() => {
    if (!authLoading && isAdmin) {
      void loadTemplates();
    }
  }, [authLoading, isAdmin]);

  async function submitForm(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      setLoading(true);
      setError("");
      setMessage("");

      if (!isAdmin) {
        throw new Error("Only admin can upload templates.");
      }

      if (!title.trim()) {
        throw new Error("Template title is required.");
      }

      if (!zipFile && !externalPreviewUrl.trim()) {
        throw new Error("Please upload ZIP or add original website/live project link.");
      }

      if (
        externalPreviewUrl.trim() &&
        !externalPreviewUrl.trim().startsWith("http://") &&
        !externalPreviewUrl.trim().startsWith("https://")
      ) {
        throw new Error("Original website link must start with http:// or https://");
      }

      const formData = new FormData();

      formData.append("title", title.trim());
      formData.append("category", category);
      formData.append("price", String(price));
      formData.append("description", description.trim() || `${title} template.`);
      formData.append("stack", stack.trim() || "HTML/CSS/JS");
      formData.append("model", model.trim() || tierModels[category] || "gpt-5.4-mini");
      formData.append("passPriceInr", "0");
      formData.append("tags", tags.trim() || `${category},Template`);
      formData.append("externalPreviewUrl", externalPreviewUrl.trim());
      formData.append("liveProjectUrl", externalPreviewUrl.trim());

      if (zipFile) {
        formData.append("zipFile", zipFile);
      }

      const response = await fetch("/api/admin/manual-templates/upload", {
        method: "POST",
        body: formData,
        credentials: "include",
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || data.detail || "Template upload failed.");
      }

      setMessage("Template uploaded and published successfully.");
      setTitle("");
      setDescription("");
      setExternalPreviewUrl("");
      setZipFile(null);

      const fileInput = document.getElementById("zipFile") as HTMLInputElement | null;
      if (fileInput) fileInput.value = "";

      await loadTemplates();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Template upload failed.");
    } finally {
      setLoading(false);
    }
  }

  if (authLoading) {
    return (
      <main className="manualTemplateAdmin">
        <style>{`
          .manualTemplateAdmin {
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 24px;
            color: #f8fbff;
            background:
              radial-gradient(circle at 10% 20%, rgba(34, 211, 238, 0.16), transparent 25%),
              radial-gradient(circle at 90% 20%, rgba(192, 132, 252, 0.12), transparent 24%),
              #020617;
          }

          .accessCard {
            width: min(680px, 100%);
            border-radius: 28px;
            padding: 24px;
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.10);
            box-shadow: 0 28px 90px rgba(0,0,0,0.32);
            text-align: center;
          }

          .accessCard h1 {
            margin: 0;
            font-size: clamp(30px, 5vw, 52px);
            line-height: 1.05;
          }

          .accessCard p {
            color: #9fb0c5;
            line-height: 1.7;
          }
        `}</style>

        <section className="accessCard">
          <h1>Checking admin access...</h1>
          <p>Please wait.</p>
        </section>
      </main>
    );
  }

  if (!isAdmin) {
    return (
      <main className="manualTemplateAdmin">
        <style>{`
          .manualTemplateAdmin {
            min-height: 100vh;
            display: grid;
            place-items: center;
            padding: 24px;
            color: #f8fbff;
            background:
              radial-gradient(circle at 10% 20%, rgba(34, 211, 238, 0.16), transparent 25%),
              radial-gradient(circle at 90% 20%, rgba(192, 132, 252, 0.12), transparent 24%),
              #020617;
          }

          .accessCard {
            width: min(760px, 100%);
            border-radius: 28px;
            padding: 24px;
            background: rgba(255,255,255,0.06);
            border: 1px solid rgba(255,255,255,0.10);
            box-shadow: 0 28px 90px rgba(0,0,0,0.32);
            text-align: center;
          }

          .accessBadge {
            display: inline-flex;
            width: fit-content;
            padding: 8px 12px;
            border-radius: 999px;
            color: #fecaca;
            background: rgba(239,68,68,0.12);
            border: 1px solid rgba(239,68,68,0.24);
            font-size: 12px;
            font-weight: 950;
            text-transform: uppercase;
            letter-spacing: .08em;
          }

          .accessCard h1 {
            margin: 14px 0 0;
            font-size: clamp(32px, 5vw, 58px);
            line-height: 1.05;
            letter-spacing: -0.04em;
          }

          .accessCard p {
            color: #9fb0c5;
            line-height: 1.7;
            margin: 14px auto 0;
            max-width: 620px;
          }

          .accessActions {
            display: flex;
            flex-wrap: wrap;
            justify-content: center;
            gap: 10px;
            margin-top: 22px;
          }

          .accessBtn {
            min-height: 44px;
            border: 0;
            border-radius: 14px;
            padding: 10px 14px;
            cursor: pointer;
            text-decoration: none;
            font-weight: 900;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            color: #04111f;
            background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
          }

          .accessBtnSecondary {
            color: #dffbff;
            background: rgba(255,255,255,0.07);
            border: 1px solid rgba(255,255,255,0.12);
          }
        `}</style>

        <section className="accessCard">
          <div className="accessBadge">Admin access required</div>

          <h1>Only Sambhajingr Developers admin can upload templates.</h1>

          <p>
            Common users can see published templates on the public marketplace,
            but they cannot upload ZIP files, external links, prices or categories.
            {authError ? ` ${authError}` : ""}
          </p>

          <div className="accessActions">
            <Link className="accessBtn" href="/templates">
              Open Public Templates
            </Link>

            <Link className="accessBtn accessBtnSecondary" href="/login">
              Login as Admin
            </Link>
          </div>
        </section>
      </main>
    );
  }

  return (
    <main className="manualTemplateAdmin">
      <style>{`
        .manualTemplateAdmin {
          min-height: 100vh;
          padding: 24px;
          color: #f8fbff;
          background:
            radial-gradient(circle at 10% 20%, rgba(34, 211, 238, 0.16), transparent 25%),
            radial-gradient(circle at 90% 20%, rgba(192, 132, 252, 0.12), transparent 24%),
            #020617;
        }

        .manualTop {
          max-width: 1180px;
          margin: 0 auto 22px;
          display: flex;
          justify-content: space-between;
          gap: 16px;
          align-items: center;
        }

        .manualTop h1 {
          margin: 0;
          font-size: clamp(32px, 5vw, 58px);
          letter-spacing: -0.04em;
          line-height: 1.05;
        }

        .manualTop p {
          color: #9fb0c5;
          line-height: 1.7;
          margin: 12px 0 0;
        }

        .manualActions {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
        }

        .manualBtn {
          min-height: 44px;
          border: 0;
          border-radius: 14px;
          padding: 10px 14px;
          cursor: pointer;
          text-decoration: none;
          font-weight: 900;
          display: inline-flex;
          align-items: center;
          justify-content: center;
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        }

        .manualBtn:disabled {
          opacity: .55;
          cursor: not-allowed;
        }

        .manualBtnSecondary {
          color: #dffbff;
          background: rgba(255,255,255,0.07);
          border: 1px solid rgba(255,255,255,0.12);
        }

        .manualGrid {
          max-width: 1180px;
          margin: 0 auto;
          display: grid;
          grid-template-columns: minmax(0, 0.9fr) minmax(0, 1.1fr);
          gap: 20px;
          align-items: start;
        }

        .manualCard {
          border-radius: 28px;
          padding: 20px;
          background: rgba(255,255,255,0.06);
          border: 1px solid rgba(255,255,255,0.10);
          box-shadow: 0 28px 90px rgba(0,0,0,0.32);
        }

        .manualCard h2 {
          margin: 0 0 14px;
          font-size: 26px;
        }

        .adminIdentity {
          margin-bottom: 14px;
          padding: 12px;
          border-radius: 16px;
          color: #bbf7d0;
          background: rgba(34,197,94,0.12);
          border: 1px solid rgba(34,197,94,0.22);
          line-height: 1.6;
          word-break: break-all;
        }

        .manualForm {
          display: grid;
          gap: 12px;
        }

        .manualForm input,
        .manualForm select,
        .manualForm textarea {
          width: 100%;
          border: 1px solid rgba(255,255,255,0.12);
          background: rgba(15,23,42,0.86);
          color: white;
          border-radius: 16px;
          padding: 14px 16px;
          outline: none;
        }

        .manualForm input[type="file"] {
          cursor: pointer;
        }

        .manualForm textarea {
          min-height: 110px;
          resize: vertical;
        }

        .manualHint {
          color: #9fb0c5;
          line-height: 1.6;
          font-size: 14px;
          padding: 12px;
          border-radius: 16px;
          background: rgba(34, 211, 238, 0.08);
          border: 1px solid rgba(34, 211, 238, 0.16);
        }

        .manualHint strong {
          color: #67e8f9;
        }

        .manualError,
        .manualSuccess {
          padding: 14px;
          border-radius: 16px;
          line-height: 1.6;
          margin-bottom: 12px;
        }

        .manualError {
          color: #fecaca;
          background: rgba(239,68,68,0.12);
          border: 1px solid rgba(239,68,68,0.24);
        }

        .manualSuccess {
          color: #bbf7d0;
          background: rgba(34,197,94,0.12);
          border: 1px solid rgba(34,197,94,0.22);
        }

        .templateList {
          display: grid;
          gap: 14px;
        }

        .templateItem {
          border-radius: 22px;
          padding: 16px;
          background: rgba(15,23,42,0.7);
          border: 1px solid rgba(255,255,255,0.10);
        }

        .templateItem h3 {
          margin: 0;
          font-size: 22px;
        }

        .templateItem p {
          color: #9fb0c5;
          line-height: 1.6;
        }

        .tagRow {
          display: flex;
          flex-wrap: wrap;
          gap: 8px;
          margin: 12px 0;
        }

        .tagRow span {
          padding: 7px 10px;
          border-radius: 999px;
          color: #dffbff;
          background: rgba(255,255,255,0.07);
          border: 1px solid rgba(255,255,255,0.10);
          font-size: 12px;
          font-weight: 800;
        }

        .templateLinks {
          display: flex;
          flex-wrap: wrap;
          gap: 10px;
        }

        .templateLinkText {
          color: #67e8f9;
          font-weight: 900;
          word-break: break-all;
        }

        @media (max-width: 860px) {
          .manualTop,
          .manualGrid {
            grid-template-columns: 1fr;
            flex-direction: column;
          }

          .manualActions,
          .manualBtn {
            width: 100%;
          }

          .manualTemplateAdmin {
            padding: 16px;
          }
        }
      `}</style>

      <div className="manualTop">
        <div>
          <h1>Admin Template Upload</h1>
          <p>
            Only admin can upload ZIP, original project URL, category and price.
            Published templates will appear on public marketplace for common users.
          </p>
        </div>

        <div className="manualActions">
          <button className="manualBtn" type="button" onClick={() => void loadTemplates()}>
            Refresh
          </button>

          <Link className="manualBtn manualBtnSecondary" href="/templates">
            Open Public Templates
          </Link>

          <Link className="manualBtn manualBtnSecondary" href="/admin">
            Admin Panel
          </Link>
        </div>
      </div>

      <div className="manualGrid">
        <section className="manualCard">
          <h2>Upload / Publish Template</h2>

          <div className="adminIdentity">
            Admin verified: <strong>{user?.name || user?.email}</strong>
          </div>

          {error ? <div className="manualError">{error}</div> : null}
          {message ? <div className="manualSuccess">{message}</div> : null}

          <form className="manualForm" onSubmit={submitForm}>
            <input
              value={title}
              onChange={(event) => setTitle(event.target.value)}
              placeholder="Template title"
            />

            <select
              value={category}
              onChange={(event) => updateTier(event.target.value)}
            >
              {tierOptions.map((tier) => (
                <option key={tier} value={tier}>
                  {tier}
                </option>
              ))}
            </select>

            <input
              value={price}
              onChange={(event) => setPrice(Number(event.target.value))}
              placeholder="ZIP price"
              type="number"
              min={0}
            />

            <input
              value={model}
              onChange={(event) => setModel(event.target.value)}
              placeholder="Model"
            />

            <input
              value={stack}
              onChange={(event) => setStack(event.target.value)}
              placeholder="Stack e.g. HTML/CSS/Next.js"
            />

            <input
              value={tags}
              onChange={(event) => setTags(event.target.value)}
              placeholder="Tags comma separated"
            />

            <textarea
              value={description}
              onChange={(event) => setDescription(event.target.value)}
              placeholder="Template description"
            />

            <input
              value={externalPreviewUrl}
              onChange={(event) => setExternalPreviewUrl(event.target.value)}
              placeholder="Original website link e.g. https://project-name.vercel.app"
            />

            <input
              id="zipFile"
              type="file"
              accept=".zip,application/zip"
              onChange={(event) => setZipFile(event.target.files?.[0] || null)}
            />

            <div className="manualHint">
              <strong>Free category:</strong> users can preview and download ZIP free.
              <br />
              <strong>Paid categories:</strong> users see preview free, but ZIP stays payment locked.
              <br />
              Common users never see this upload form.
            </div>

            <button className="manualBtn" type="submit" disabled={loading}>
              {loading ? "Uploading..." : "Upload & Publish Template"}
            </button>
          </form>
        </section>

        <section className="manualCard">
          <h2>Published Templates</h2>

          {loadingList ? <div className="templateItem">Loading templates...</div> : null}

          {!loadingList && !templates.length ? (
            <div className="templateItem">No manual templates uploaded yet.</div>
          ) : null}

          <div className="templateList">
            {templates.map((item) => {
              const isFree =
                (item.category || "").toLowerCase() === "free" ||
                Number(item.zipPriceInr || 0) <= 0;

              return (
                <article className="templateItem" key={item.templateId}>
                  <h3>{item.title}</h3>

                  <p>{item.description}</p>

                  <div className="tagRow">
                    <span>{item.category || "Premium"}</span>
                    <span>{isFree ? "Free ZIP" : `ZIP ₹${item.zipPriceInr || 0}`}</span>
                    <span>{item.model || "-"}</span>
                    <span>{item.stack || "-"}</span>
                    <span>{item.hasZip ? "ZIP Uploaded" : "No ZIP"}</span>
                    <span>
                      {item.externalPreviewUrl || item.liveProjectUrl
                        ? "Live Link Added"
                        : "No Live Link"}
                    </span>
                  </div>

                  {item.frontendPreviewUrl || item.previewUrl ? (
                    <p>
                      Public preview:{" "}
                      <a
                        href={item.frontendPreviewUrl || item.previewUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="templateLinkText"
                      >
                        {item.frontendPreviewUrl || item.previewUrl}
                      </a>
                    </p>
                  ) : null}

                  <div className="templateLinks">
                    {item.frontendPreviewUrl || item.previewUrl ? (
                      <a
                        className="manualBtn"
                        href={item.frontendPreviewUrl || item.previewUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        Live Preview
                      </a>
                    ) : null}

                    {item.zipPreviewUrl ? (
                      <a
                        className="manualBtn manualBtnSecondary"
                        href={item.zipPreviewUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        ZIP HTML Preview
                      </a>
                    ) : null}

                    {item.frontendDownloadUrl || item.downloadUrl ? (
                      <a
                        className="manualBtn manualBtnSecondary"
                        href={item.frontendDownloadUrl || item.downloadUrl}
                        target="_blank"
                        rel="noopener noreferrer"
                      >
                        {isFree ? "Free Source ZIP" : "Download Route"}
                      </a>
                    ) : null}
                  </div>
                </article>
              );
            })}
          </div>
        </section>
      </div>
    </main>
  );
}
