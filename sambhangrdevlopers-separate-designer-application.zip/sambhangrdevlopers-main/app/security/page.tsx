"use client";

import Link from "next/link";
import { FormEvent, useEffect, useMemo, useState } from "react";

type TwoFactorStatus = {
  enabled?: boolean;
  enabledAt?: string | null;
  lastVerifiedAt?: string | null;
  backupCodesRemaining?: number;
};

type TwoFactorApiResponse = {
  success?: boolean;
  error?: string;
  detail?: string;
  message?: string;
  secret?: string;
  otpauthUrl?: string;
  issuer?: string;
  accountName?: string;
  twoFactor?: TwoFactorStatus;
  backupCodes?: string[];
  important?: string;
};

function getError(data: TwoFactorApiResponse, fallback: string) {
  if (typeof data.error === "string") return data.error;
  if (typeof data.detail === "string") return data.detail;
  if (typeof data.message === "string") return data.message;
  return fallback;
}

async function readJson(response: Response): Promise<TwoFactorApiResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as TwoFactorApiResponse;
  } catch {
    return {
      success: false,
      error: `Server returned non-JSON response: ${text.slice(0, 300)}`,
    };
  }
}

export default function SecurityPage() {
  const [loading, setLoading] = useState(true);
  const [setupLoading, setSetupLoading] = useState(false);
  const [enableLoading, setEnableLoading] = useState(false);
  const [disableLoading, setDisableLoading] = useState(false);

  const [twoFactor, setTwoFactor] = useState<TwoFactorStatus | null>(null);
  const [secret, setSecret] = useState("");
  const [otpauthUrl, setOtpauthUrl] = useState("");
  const [code, setCode] = useState("");
  const [disableCode, setDisableCode] = useState("");
  const [recoveryCode, setRecoveryCode] = useState("");
  const [backupCodes, setBackupCodes] = useState<string[]>([]);

  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  const qrUrl = useMemo(() => {
    if (!otpauthUrl) return "";

    return `https://api.qrserver.com/v1/create-qr-code/?size=240x240&data=${encodeURIComponent(
      otpauthUrl
    )}`;
  }, [otpauthUrl]);

  async function loadStatus() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/2fa/status", {
        cache: "no-store",
      });

      const data = await readJson(response);

      if (!response.ok || !data.success) {
        throw new Error(getError(data, "2FA status failed."));
      }

      setTwoFactor(data.twoFactor || null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "2FA status failed.");
      setTwoFactor(null);
    } finally {
      setLoading(false);
    }
  }

  async function startSetup() {
    try {
      setSetupLoading(true);
      setError("");
      setSuccess("");
      setBackupCodes([]);
      setCode("");

      const response = await fetch("/api/2fa/setup", {
        method: "POST",
        cache: "no-store",
      });

      const data = await readJson(response);

      if (!response.ok || !data.success) {
        throw new Error(getError(data, "2FA setup failed."));
      }

      setSecret(data.secret || "");
      setOtpauthUrl(data.otpauthUrl || "");
      setTwoFactor(data.twoFactor || null);
      setSuccess("2FA setup started. Scan the QR code and enter the 6-digit code.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "2FA setup failed.");
    } finally {
      setSetupLoading(false);
    }
  }

  async function enableTwoFactor(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      setEnableLoading(true);
      setError("");
      setSuccess("");

      const response = await fetch("/api/2fa/enable", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        cache: "no-store",
        body: JSON.stringify({
          code,
        }),
      });

      const data = await readJson(response);

      if (!response.ok || !data.success) {
        throw new Error(getError(data, "2FA enable failed."));
      }

      setTwoFactor(data.twoFactor || null);
      setBackupCodes(Array.isArray(data.backupCodes) ? data.backupCodes : []);
      setSecret("");
      setOtpauthUrl("");
      setCode("");
      setSuccess(
        data.message ||
          "2FA enabled successfully. Save your backup codes now."
      );
    } catch (err) {
      setError(err instanceof Error ? err.message : "2FA enable failed.");
    } finally {
      setEnableLoading(false);
    }
  }

  async function disableTwoFactor(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      setDisableLoading(true);
      setError("");
      setSuccess("");

      const response = await fetch("/api/2fa/disable", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        cache: "no-store",
        body: JSON.stringify({
          code: disableCode,
          recoveryCode,
        }),
      });

      const data = await readJson(response);

      if (!response.ok || !data.success) {
        throw new Error(getError(data, "2FA disable failed."));
      }

      setTwoFactor(data.twoFactor || null);
      setDisableCode("");
      setRecoveryCode("");
      setBackupCodes([]);
      setSuccess(data.message || "2FA disabled successfully.");
    } catch (err) {
      setError(err instanceof Error ? err.message : "2FA disable failed.");
    } finally {
      setDisableLoading(false);
    }
  }

  useEffect(() => {
    void loadStatus();
  }, []);

  return (
    <main className="securityPage">
      <style>{`
        .securityPage {
          min-height: 100vh;
          padding: 34px 18px;
          color: #f8fbff;
          background:
            radial-gradient(circle at top left, rgba(34,211,238,.16), transparent 30%),
            radial-gradient(circle at bottom right, rgba(168,85,247,.16), transparent 34%),
            #030712;
        }

        .securityWrap {
          width: min(980px, 100%);
          margin: 0 auto;
        }

        .securityHero {
          border: 1px solid rgba(255,255,255,.10);
          background: rgba(255,255,255,.06);
          border-radius: 30px;
          padding: 28px;
          box-shadow: 0 24px 80px rgba(0,0,0,.26);
        }

        .securityBadge {
          display: inline-flex;
          padding: 8px 12px;
          border-radius: 999px;
          color: #04111f;
          font-weight: 950;
          background: linear-gradient(135deg, #67e8f9, #60a5fa);
        }

        .securityTitle {
          margin: 16px 0 0;
          font-size: clamp(32px, 5vw, 58px);
          line-height: 1.04;
          letter-spacing: -0.04em;
        }

        .securityText {
          margin-top: 14px;
          color: #b7c2d0;
          line-height: 1.8;
          max-width: 780px;
        }

        .securityGrid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 18px;
          margin-top: 22px;
        }

        .securityCard {
          border: 1px solid rgba(255,255,255,.10);
          background: rgba(255,255,255,.055);
          border-radius: 24px;
          padding: 20px;
        }

        .securityCard h2 {
          margin: 0;
          font-size: 22px;
        }

        .securityCard p {
          color: #b7c2d0;
          line-height: 1.7;
        }

        .statusPill {
          display: inline-flex;
          align-items: center;
          margin-top: 12px;
          padding: 8px 11px;
          border-radius: 999px;
          font-weight: 900;
          font-size: 13px;
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee);
        }

        .statusPill.off {
          color: #fecaca;
          background: rgba(239,68,68,.12);
          border: 1px solid rgba(239,68,68,.24);
        }

        .securityInput {
          width: 100%;
          border: 1px solid rgba(255,255,255,.12);
          background: rgba(255,255,255,.07);
          color: #ffffff;
          border-radius: 16px;
          padding: 14px 15px;
          outline: none;
          margin-top: 12px;
        }

        .securityInput::placeholder {
          color: rgba(255,255,255,.45);
        }

        .securityBtn {
          width: 100%;
          margin-top: 12px;
          border: 0;
          border-radius: 16px;
          padding: 14px 16px;
          cursor: pointer;
          color: #04111f;
          font-weight: 950;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        }

        .securityBtn:disabled {
          cursor: not-allowed;
          opacity: .55;
        }

        .secondarySecurityBtn {
          display: inline-flex;
          align-items: center;
          justify-content: center;
          text-decoration: none;
          color: #dffbff;
          border: 1px solid rgba(255,255,255,.12);
          background: rgba(255,255,255,.07);
          border-radius: 16px;
          padding: 13px 16px;
          font-weight: 900;
          margin-top: 12px;
        }

        .dangerBtn {
          background: linear-gradient(135deg, #fb7185, #f97316);
        }

        .qrBox {
          display: grid;
          place-items: center;
          background: #ffffff;
          border-radius: 22px;
          padding: 18px;
          width: fit-content;
          margin-top: 16px;
        }

        .secretBox {
          margin-top: 14px;
          padding: 12px;
          border-radius: 16px;
          color: #67e8f9;
          background: rgba(34,211,238,.10);
          border: 1px solid rgba(34,211,238,.18);
          word-break: break-all;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
        }

        .backupGrid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(130px, 1fr));
          gap: 10px;
          margin-top: 14px;
        }

        .backupCode {
          padding: 10px;
          border-radius: 12px;
          background: rgba(255,255,255,.08);
          border: 1px solid rgba(255,255,255,.12);
          color: #f8fbff;
          font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace;
          text-align: center;
        }

        .alertError,
        .alertSuccess {
          margin-top: 18px;
          border-radius: 18px;
          padding: 14px;
          line-height: 1.7;
          white-space: pre-wrap;
        }

        .alertError {
          color: #fecaca;
          background: rgba(239,68,68,.12);
          border: 1px solid rgba(239,68,68,.24);
        }

        .alertSuccess {
          color: #bbf7d0;
          background: rgba(34,197,94,.12);
          border: 1px solid rgba(34,197,94,.22);
        }

        .topLinks {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
          margin-top: 20px;
        }
      `}</style>

      <div className="securityWrap">
        <section className="securityHero">
          <span className="securityBadge">Security</span>

          <h1 className="securityTitle">Two-Factor Authentication</h1>

          <p className="securityText">
            Protect your account with an authenticator app like Google
            Authenticator, Microsoft Authenticator, or Authy. After enabling
            2FA, login will require your password plus a 6-digit authenticator
            code.
          </p>

          <div className="topLinks">
            <Link href="/profile" className="secondarySecurityBtn">
              Back to Profile
            </Link>

            <Link href="/ai" className="secondarySecurityBtn">
              Open AutoDev AI
            </Link>

            <Link href="/wallet" className="secondarySecurityBtn">
              Open Wallet
            </Link>
          </div>
        </section>

        {error ? <div className="alertError">{error}</div> : null}
        {success ? <div className="alertSuccess">{success}</div> : null}

        <section className="securityGrid">
          <div className="securityCard">
            <h2>Current Status</h2>

            {loading ? (
              <p>Checking security status...</p>
            ) : (
              <>
                <span className={`statusPill ${twoFactor?.enabled ? "" : "off"}`}>
                  {twoFactor?.enabled ? "2FA Enabled" : "2FA Disabled"}
                </span>

                <p>
                  Backup codes remaining:{" "}
                  <strong>{twoFactor?.backupCodesRemaining || 0}</strong>
                </p>

                {twoFactor?.enabledAt ? (
                  <p>Enabled at: {twoFactor.enabledAt}</p>
                ) : null}

                {twoFactor?.lastVerifiedAt ? (
                  <p>Last verified: {twoFactor.lastVerifiedAt}</p>
                ) : null}

                <button
                  type="button"
                  className="securityBtn"
                  onClick={() => void loadStatus()}
                  disabled={loading}
                >
                  Refresh Status
                </button>
              </>
            )}
          </div>

          <div className="securityCard">
            <h2>Enable 2FA</h2>

            <p>
              Click setup, scan the QR code in your authenticator app, then
              enter the 6-digit code to enable 2FA.
            </p>

            <button
              type="button"
              className="securityBtn"
              onClick={() => void startSetup()}
              disabled={setupLoading || Boolean(twoFactor?.enabled)}
            >
              {setupLoading ? "Starting Setup..." : "Start 2FA Setup"}
            </button>

            {qrUrl ? (
              <>
                <div className="qrBox">
                  <img src={qrUrl} alt="2FA QR code" width={240} height={240} />
                </div>

                <div className="secretBox">
                  Setup Key:
                  <br />
                  {secret}
                </div>

                <form onSubmit={enableTwoFactor}>
                  <input
                    className="securityInput"
                    value={code}
                    onChange={(event) => setCode(event.target.value)}
                    placeholder="Enter 6-digit code"
                    inputMode="numeric"
                    maxLength={12}
                  />

                  <button
                    type="submit"
                    className="securityBtn"
                    disabled={enableLoading || !code.trim()}
                  >
                    {enableLoading ? "Enabling..." : "Enable 2FA"}
                  </button>
                </form>
              </>
            ) : null}
          </div>

          <div className="securityCard">
            <h2>Disable 2FA</h2>

            <p>
              To disable 2FA, enter your authenticator code or one unused backup
              code.
            </p>

            <form onSubmit={disableTwoFactor}>
              <input
                className="securityInput"
                value={disableCode}
                onChange={(event) => setDisableCode(event.target.value)}
                placeholder="Authenticator code"
                inputMode="numeric"
                maxLength={12}
              />

              <input
                className="securityInput"
                value={recoveryCode}
                onChange={(event) => setRecoveryCode(event.target.value)}
                placeholder="Or backup code"
                maxLength={20}
              />

              <button
                type="submit"
                className="securityBtn dangerBtn"
                disabled={
                  disableLoading ||
                  !twoFactor?.enabled ||
                  (!disableCode.trim() && !recoveryCode.trim())
                }
              >
                {disableLoading ? "Disabling..." : "Disable 2FA"}
              </button>
            </form>
          </div>
        </section>

        {backupCodes.length ? (
          <section className="securityCard" style={{ marginTop: 18 }}>
            <h2>Save Backup Codes Now</h2>

            <p>
              These backup codes are shown only once. Save them in a safe place.
              Each code can be used one time if your authenticator app is not
              available.
            </p>

            <div className="backupGrid">
              {backupCodes.map((item) => (
                <div key={item} className="backupCode">
                  {item}
                </div>
              ))}
            </div>
          </section>
        ) : null}
      </div>
    </main>
  );
}
