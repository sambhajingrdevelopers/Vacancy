import SiteHeader from "../../components/layout/SiteHeader";
import SiteFooter from "../../components/layout/SiteFooter";
import SectionContainer from "../../components/layout/SectionContainer";
import SectionHeading from "../../components/layout/SectionHeading";
import PrimaryButton from "../../components/layout/PrimaryButton";
import SecondaryButton from "../../components/layout/SecondaryButton";
import FeatureCard from "../../components/cards/FeatureCard";

const cultureItems = [
  {
    title: "Modern Tech Stack",
    desc: "Next.js, scalable systems, modern UI architecture aur future-ready workflows ke saath kaam.",
    icon: "✦",
  },
  {
    title: "Creative + Technical Culture",
    desc: "Design aur engineering dono ko equal importance ke saath premium output focus.",
    icon: "◈",
  },
  {
    title: "Growth Environment",
    desc: "Learning mindset, practical problem solving aur real business projects par kaam karne ka mauka.",
    icon: "◎",
  },
  {
    title: "Flexible Direction",
    desc: "Remote-friendly aur delivery-focused work style jahan quality aur ownership important hai.",
    icon: "✶",
  },
];

const benefits = [
  "Modern Projects",
  "Learning Opportunities",
  "Growth-Focused Team",
  "Creative Work Culture",
  "Remote-Friendly Direction",
  "High-Quality Build Standards",
];

export default function CareersPage() {
  return (
    <div className="siteShell">
      <SiteHeader />

      <main className="mainWrap">
        <SectionContainer>
          <section className="glassCard premiumHover careersWrap">
            <div className="careersGlow" />

            <div className="careersContent">
              <SectionHeading
                eyebrow="Careers"
                title="Work with a modern, growth-focused digital team"
                description="Sambhangr Developers me career ka focus sirf job dena nahi, balki high-quality digital products, premium design systems aur scalable technology solutions ke saath long-term growth create karna hai."
              />

              <div className="careersPoints">
                {benefits.map((item) => (
                  <span key={item}>{item}</span>
                ))}
              </div>

              <div className="heroActions" style={{ marginTop: 24 }}>
                <PrimaryButton href="/vacancies">See Vacancies</PrimaryButton>
                <SecondaryButton href="/#contact">Contact HR</SecondaryButton>
              </div>
            </div>

            <div className="careersSideCard">
              <div className="careersMiniLabel">Hiring Focus</div>
              <div className="careersMiniTitle">
                Designer Vacancy Open
              </div>
              <p>
                Creative Designer hiring is open for website UI, app screens, social media posts, banners, branding, and premium client visuals. The application form opens on a separate dedicated page.
              </p>
              <SecondaryButton href="/designer-application">
                Apply for Designer
              </SecondaryButton>
            </div>
          </section>
        </SectionContainer>

        <SectionContainer>
          <div className="sectionBlock">
            <SectionHeading
              eyebrow="Work Culture"
              title="Why people would want to join"
              description="Career page me sirf openings nahi, balki company ke working environment aur value system bhi clear dikhna chahiye."
            />

            <div className="grid fourCols">
              {cultureItems.map((item) => (
                <FeatureCard
                  key={item.title}
                  title={item.title}
                  desc={item.desc}
                  icon={item.icon}
                />
              ))}
            </div>
          </div>
        </SectionContainer>

        <SectionContainer>
          <div className="ctaBox ctaPremium premiumHover">
            <div className="ctaGlow" />

            <div className="ctaContent">
              <div className="eyebrow">Join Us</div>
              <h2>
                Build high-quality products with a
                <span className="gradientText"> premium digital team</span>
              </h2>
              <p>
                Agar tumhe design, development, systems aur modern digital
                experiences me kaam karna pasand hai, to open roles dekhkar
                apply karo.
              </p>

              <div className="ctaMiniPoints">
                <span>Growth-Oriented</span>
                <span>Modern Stack</span>
                <span>Real Product Work</span>
              </div>
            </div>

            <div className="ctaActions ctaActionsPremium">
              <PrimaryButton href="/vacancies">View Vacancies</PrimaryButton>
              <SecondaryButton href="/#contact">Talk to Us</SecondaryButton>
            </div>
          </div>
        </SectionContainer>
      </main>

      <SiteFooter />
    </div>
  );
}
