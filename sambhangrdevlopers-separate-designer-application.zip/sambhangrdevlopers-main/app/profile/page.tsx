"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

type UserProfile = {
  userId?: string;
  name?: string;
  email?: string;
  role?: string;
  status?: string;
  profile?: {
    phone?: string;
    company?: string;
    city?: string;
  };
  createdAt?: string;
  updatedAt?: string;
  lastLoginAt?: string | null;
};

type WalletSummary = {
  userId?: string;
  plan?: string;
  model?: string;
  modelTier?: string;
  messagesRemaining?: number;
  projectPassesRemaining?: number;
  zipUnlocked?: boolean;
  creditsTotal?: number;
  creditsUsed?: number;
  creditsRemaining?: number;
  tokensTotal?: number;
  tokensUsed?: number;
  tokensRemaining?: number;
  freeProjectsUsed?: number;
  projectsGeneratedCount?: number;
};

type TwoFactorStatus = {
  enabled?: boolean;
  enabledAt?: string | null;
  lastVerifiedAt?: string | null;
  backupCodesRemaining?: number;
};

type AuthMeResponse = {
  success?: boolean;
  user?: UserProfile;
  wallet?: WalletSummary;
  twoFactor?: TwoFactorStatus;
  error?: string;
  detail?: string;
  message?: string;
};

async function readJson(response: Response): Promise<AuthMeResponse> {
  const text = await response.text();

  try {
    return JSON.parse(text) as AuthMeResponse;
  } catch {
    return {
      success: false,
      error: `Server returned non-JSON response: ${text.slice(0, 300)}`,
    };
  }
}

function getError(data: AuthMeResponse, fallback: string) {
  if (typeof data.error === "string") return data.error;
  if (typeof data.detail === "string") return data.detail;
  if (typeof data.message === "string") return data.message;
  return fallback;
}

function getPlanName(plan?: string) {
  const value = String(plan || "free").toLowerCase();

  if (value === "starter") return "Starter";
  if (value === "premium") return "Premium";
  if (value === "advanced") return "Advanced";
  if (value === "enterprise") return "Enterprise";
  if (value === "admin") return "Admin";

  return "Free";
}

function formatValue(value: unknown) {
  if (value === undefined || value === null || value === "") return "Not added";
  return String(value);
}

export default function ProfilePage() {
  const router = useRouter();

  const [loading, setLoading] = useState(true);
  const [logoutLoading, setLogoutLoading] = useState(false);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [wallet, setWallet] = useState<WalletSummary | null>(null);
  const [twoFactor, setTwoFactor] = useState<TwoFactorStatus | null>(null);
  const [error, setError] = useState("");

  async function loadProfile() {
    try {
      setLoading(true);
      setError("");

      const response = await fetch("/api/auth/me", {
        cache: "no-store",
      });

      const data = await readJson(response);

      if (!response.ok || !data.success || !data.user?.userId) {
        throw new Error(getError(data, "Login required."));
      }

      setUser(data.user);
      setWallet(data.wallet || null);
      setTwoFactor(data.twoFactor || null);

      if (typeof window !== "undefined" && data.user.userId) {
        window.localStorage.setItem("sambhajingr_wallet_user_id", data.user.userId);
      }
    } catch (err) {
      setUser(null);
      setWallet(null);
      setTwoFactor(null);
      setError(err instanceof Error ? err.message : "Profile load failed.");
    } finally {
      setLoading(false);
    }
  }

  async function logout() {
    try {
      setLogoutLoading(true);
      setError("");

      await fetch("/api/auth/logout", {
        method: "POST",
        cache: "no-store",
      });

      if (typeof window !== "undefined") {
        window.localStorage.removeItem("sambhajingr_wallet_user_id");
      }

      router.push("/login");
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Logout failed.");
    } finally {
      setLogoutLoading(false);
    }
  }

  useEffect(() => {
    void loadProfile();
  }, []);

  return (
    <main className="profilePage">
      <style>{`
        .profilePage {
          min-height: 100vh;
          padding: 34px 18px;
          color: #f8fbff;
          background:
            radial-gradient(circle at top left, rgba(34,211,238,.16), transparent 30%),
            radial-gradient(circle at bottom right, rgba(168,85,247,.16), transparent 34%),
            #030712;
        }

        .profileWrap {
          width: min(1100px, 100%);
          margin: 0 auto;
        }

        .profileHero {
          border: 1px solid rgba(255,255,255,.10);
          background: rgba(255,255,255,.06);
          border-radius: 32px;
          padding: 30px;
          box-shadow: 0 24px 80px rgba(0,0,0,.28);
          backdrop-filter: blur(18px);
        }

        .profileTop {
          display: flex;
          align-items: flex-start;
          justify-content: space-between;
          gap: 18px;
          flex-wrap: wrap;
        }

        .profileAvatar {
          width: 76px;
          height: 76px;
          border-radius: 24px;
          display: grid;
          place-items: center;
          color: #04111f;
          font-weight: 950;
          font-size: 28px;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa, #c084fc);
          box-shadow: 0 20px 55px rgba(34,211,238,.20);
        }

        .profileTitle {
          margin: 18px 0 0;
          font-size: clamp(32px, 5vw, 58px);
          line-height: 1.04;
          letter-spacing: -0.04em;
        }

        .profileText {
          margin: 12px 0 0;
          color: #b7c2d0;
          line-height: 1.8;
          max-width: 760px;
        }

        .profileBadge {
          display: inline-flex;
          align-items: center;
          width: fit-content;
          padding: 8px 12px;
          border-radius: 999px;
          color: #04111f;
          font-weight: 950;
          background: linear-gradient(135deg, #67e8f9, #60a5fa);
        }

        .profileActions {
          display: flex;
          flex-wrap: wrap;
          gap: 12px;
          margin-top: 22px;
        }

        .profileBtn {
          display: inline-flex;
          justify-content: center;
          align-items: center;
          min-height: 46px;
          border-radius: 16px;
          padding: 12px 16px;
          text-decoration: none;
          cursor: pointer;
          font-weight: 950;
          color: #04111f;
          border: 0;
          background: linear-gradient(135deg, #67e8f9, #22d3ee, #60a5fa);
        }

        .profileBtnSecondary {
          color: #dffbff;
          background: rgba(255,255,255,.07);
          border: 1px solid rgba(255,255,255,.12);
        }

        .profileBtnDanger {
          color: #fecaca;
          background: rgba(239,68,68,.12);
          border: 1px solid rgba(239,68,68,.24);
        }

        .profileBtn:disabled {
          opacity: .55;
          cursor: not-allowed;
        }

        .profileGrid {
          display: grid;
          grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
          gap: 18px;
          margin-top: 22px;
        }

        .profileCard {
          border: 1px solid rgba(255,255,255,.10);
          background: rgba(255,255,255,.055);
          border-radius: 24px;
          padding: 20px;
        }

        .profileCard h2 {
          margin: 0;
          font-size: 22px;
        }

        .profileCard p {
          color: #b7c2d0;
          line-height: 1.7;
        }

        .infoList {
          display: grid;
          gap: 12px;
          margin-top: 16px;
        }

        .infoItem {
          padding: 12px;
          border-radius: 16px;
          background: rgba(255,255,255,.055);
          border: 1px solid rgba(255,255,255,.08);
        }

        .infoItem span {
          display: block;
          color: #8ea0b8;
          font-size: 12px;
          font-weight: 850;
          text-transform: uppercase;
          letter-spacing: .08em;
        }

        .infoItem strong {
          display: block;
          margin-top: 6px;
          color: #f8fbff;
          line-height: 1.45;
          word-break: break-all;
        }

        .statusPill {
          display: inline-flex;
          align-items: center;
          margin-top: 12px;
          padding: 8px 11px;
          border-radius: 999px;
          font-weight: 900;
          font-size: 13px;
          color: #04111f;
          background: linear-gradient(135deg, #67e8f9, #22d3ee);
        }

        .statusPill.off {
          color: #fecaca;
          background: rgba(239,68,68,.12);
          border: 1px solid rgba(239,68,68,.24);
        }

        .alertError {
          margin-top: 18px;
          border-radius: 18px;
          padding: 14px;
          color: #fecaca;
          background: rgba(239,68,68,.12);
          border: 1px solid rgba(239,68,68,.24);
          line-height: 1.7;
          white-space: pre-wrap;
        }

        .loadingBox {
          border: 1px solid rgba(255,255,255,.10);
          background: rgba(255,255,255,.06);
          border-radius: 24px;
          padding: 22px;
          color: #b7c2d0;
          line-height: 1.7;
        }

        @media (max-width: 700px) {
          .profileHero {
            padding: 24px 18px;
          }

          .profileActions {
            display: grid;
          }

          .profileBtn {
            width: 100%;
          }
        }
      `}</style>

      <div className="profileWrap">
        {loading ? (
          <div className="loadingBox">Loading profile...</div>
        ) : error && !user ? (
          <section className="profileHero">
            <span className="profileBadge">Profile</span>
            <h1 className="profileTitle">Login Required</h1>
            <p className="profileText">{error}</p>

            <div className="profileActions">
              <Link href="/login" className="profileBtn">
                Login
              </Link>

              <Link href="/register" className="profileBtn profileBtnSecondary">
                Register
              </Link>

              <Link href="/" className="profileBtn profileBtnSecondary">
                Back Home
              </Link>
            </div>
          </section>
        ) : (
          <>
            <section className="profileHero">
              <div className="profileTop">
                <div>
                  <div className="profileAvatar">
                    {(user?.name || user?.email || "U").slice(0, 1).toUpperCase()}
                  </div>

                  <h1 className="profileTitle">{user?.name || "User Profile"}</h1>

                  <p className="profileText">
                    Manage your account, wallet, AutoDev AI access, project templates,
                    and security settings from one place.
                  </p>
                </div>

                <span className="profileBadge">
                  {getPlanName(wallet?.plan)} Plan
                </span>
              </div>

              {error ? <div className="alertError">{error}</div> : null}

              <div className="profileActions">
                <Link href="/security" className="profileBtn">
                  Security / Enable 2FA
                </Link>

                <Link href="/wallet" className="profileBtn profileBtnSecondary">
                  Wallet
                </Link>

                <Link href="/ai" className="profileBtn profileBtnSecondary">
                  AutoDev AI
                </Link>

                <Link href="/templates" className="profileBtn profileBtnSecondary">
                  Templates
                </Link>

                <button
                  type="button"
                  className="profileBtn profileBtnDanger"
                  onClick={() => void logout()}
                  disabled={logoutLoading}
                >
                  {logoutLoading ? "Logging out..." : "Logout"}
                </button>
              </div>
            </section>

            <section className="profileGrid">
              <div className="profileCard">
                <h2>Account Details</h2>

                <div className="infoList">
                  <div className="infoItem">
                    <span>Name</span>
                    <strong>{formatValue(user?.name)}</strong>
                  </div>

                  <div className="infoItem">
                    <span>Email</span>
                    <strong>{formatValue(user?.email)}</strong>
                  </div>

                  <div className="infoItem">
                    <span>User ID</span>
                    <strong>{formatValue(user?.userId)}</strong>
                  </div>

                  <div className="infoItem">
                    <span>Role</span>
                    <strong>{formatValue(user?.role || "user")}</strong>
                  </div>

                  <div className="infoItem">
                    <span>Status</span>
                    <strong>{formatValue(user?.status || "active")}</strong>
                  </div>
                </div>
              </div>

              <div className="profileCard">
                <h2>Wallet Summary</h2>

                <div className="infoList">
                  <div className="infoItem">
                    <span>Plan</span>
                    <strong>{getPlanName(wallet?.plan)}</strong>
                  </div>

                  <div className="infoItem">
                    <span>Model</span>
                    <strong>{formatValue(wallet?.model || "gpt-4.1-mini")}</strong>
                  </div>

                  <div className="infoItem">
                    <span>Messages Remaining</span>
                    <strong>{formatValue(wallet?.messagesRemaining ?? 0)}</strong>
                  </div>

                  <div className="infoItem">
                    <span>Project Passes Remaining</span>
                    <strong>{formatValue(wallet?.projectPassesRemaining ?? 0)}</strong>
                  </div>

                  <div className="infoItem">
                    <span>Credits / Tokens Remaining</span>
                    <strong>
                      {formatValue(wallet?.tokensRemaining ?? wallet?.creditsRemaining ?? 0)}
                    </strong>
                  </div>
                </div>
              </div>

              <div className="profileCard">
                <h2>Security</h2>

                <span className={`statusPill ${twoFactor?.enabled ? "" : "off"}`}>
                  {twoFactor?.enabled ? "2FA Enabled" : "2FA Disabled"}
                </span>

                <p>
                  Two-factor authentication protects your account using an
                  authenticator app code during login.
                </p>

                <div className="infoList">
                  <div className="infoItem">
                    <span>Backup Codes Remaining</span>
                    <strong>{formatValue(twoFactor?.backupCodesRemaining ?? 0)}</strong>
                  </div>

                  <div className="infoItem">
                    <span>Enabled At</span>
                    <strong>{formatValue(twoFactor?.enabledAt)}</strong>
                  </div>

                  <div className="infoItem">
                    <span>Last Verified</span>
                    <strong>{formatValue(twoFactor?.lastVerifiedAt)}</strong>
                  </div>
                </div>

                <div className="profileActions">
                  <Link href="/security" className="profileBtn">
                    Open Security Settings
                  </Link>
                </div>
              </div>

              <div className="profileCard">
                <h2>Quick Actions</h2>

                <p>
                  Continue your work with AI project generation, templates, wallet
                  recharge, and secure project downloads.
                </p>

                <div className="profileActions">
                  <Link href="/ai" className="profileBtn">
                    Generate Project
                  </Link>

                  <Link href="/templates" className="profileBtn profileBtnSecondary">
                    Browse Templates
                  </Link>

                  <Link href="/wallet" className="profileBtn profileBtnSecondary">
                    Buy Project Pass
                  </Link>

                  <button
                    type="button"
                    className="profileBtn profileBtnSecondary"
                    onClick={() => void loadProfile()}
                  >
                    Refresh Profile
                  </button>
                </div>
              </div>
            </section>
          </>
        )}
      </div>
    </main>
  );
}
