import { NextRequest, NextResponse } from "next/server";

const PROTECTED_PAGE_PREFIXES = [
  "/profile",
  "/wallet",
  "/ai",
  "/templates",
  "/dashboard",
  "/admin",
];

function isStaticOrSystemPath(pathname: string) {
  return (
    pathname.startsWith("/_next/") ||
    pathname.startsWith("/favicon") ||
    pathname.startsWith("/robots.txt") ||
    pathname.startsWith("/sitemap.xml") ||
    pathname.startsWith("/manifest") ||
    pathname.match(/\.(png|jpg|jpeg|gif|webp|svg|ico|css|js|map|txt|xml)$/)
  );
}

function isPublicPage(pathname: string) {
  return (
    pathname === "/" ||
    pathname === "/login" ||
    pathname === "/register" ||
    pathname === "/about" ||
    pathname === "/contact" ||
    pathname === "/services" ||
    pathname === "/solutions" ||
    pathname === "/portfolio" ||
    pathname === "/careers" ||
    pathname === "/vacancies"
  );
}

function isProtectedPage(pathname: string) {
  return PROTECTED_PAGE_PREFIXES.some(
    (prefix) => pathname === prefix || pathname.startsWith(`${prefix}/`)
  );
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Never block API routes.
  // If API routes are redirected, login/register receives HTML instead of JSON.
  if (pathname.startsWith("/api/")) {
    return NextResponse.next();
  }

  // Always allow static/internal files.
  if (isStaticOrSystemPath(pathname)) {
    return NextResponse.next();
  }

  // Public pages must always open.
  if (isPublicPage(pathname)) {
    return NextResponse.next();
  }

  // Protect only private pages.
  if (isProtectedPage(pathname)) {
    const sessionToken = request.cookies.get("sambhajingr_session")?.value;

    if (!sessionToken) {
      const loginUrl = new URL("/login", request.url);
      loginUrl.searchParams.set("next", pathname);
      return NextResponse.redirect(loginUrl);
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico).*)"],
};
